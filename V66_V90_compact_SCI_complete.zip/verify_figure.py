from pathlib import Path
import csv,json,hashlib
import numpy as np
from PIL import Image
import fitz

ROOT=Path(__file__).resolve().parent
provenance=json.loads((ROOT/'source_verification.json').read_text())
for f in provenance['sources']:
 assert hashlib.sha256((ROOT/f['local_file']).read_bytes()).hexdigest()==f['sha256']
regions=json.loads((ROOT/'roi_manifest.json').read_text())['regions']
windows={r['tile_id']:r for r in csv.DictReader((ROOT/'sources/spatial_manifest.csv').open(encoding='utf-8-sig'))}
pal=np.array([[0,0,0],[215,131,140],[117,190,216],[230,170,117]],np.uint8)
for r in regions:
 t=r['period'];x,y,w,h=[r[k] for k in ['x','y','width','height']]
 old=windows[r['archived_tile_id']]
 assert old['split']=='test' and all(r[k]==int(old[k]) for k in ['x','y','width','height'])
 raw=np.array(Image.open(ROOT/f'sources/RGB/{t}_RGB.png').convert('RGB'))[y:y+h,x:x+w]
 folder=ROOT/'crops'/f'{r["roi_id"]}_{t}_{r["archived_tile_id"]}'
 assert np.array_equal(raw,np.array(Image.open(folder/'original_RGB.png')))
 for m in ['reference','V66','V90']:
  full=np.array(Image.open(ROOT/f'sources/{m}/{t}_classes.png'));c=full[y:y+h,x:x+w]
  assert np.array_equal(c,np.array(Image.open(folder/f'{m}_classes.png')))
  expected=raw.copy();use=(c>0)&(c<4);expected[use]=np.rint(.15*raw[use]+.85*pal[c[use]]).astype(np.uint8)
  ignored=c==255;expected[ignored]=np.rint(.15*raw[ignored]+.85*np.array([167,174,180])).astype(np.uint8)
  assert np.array_equal(expected,np.array(Image.open(folder/f'{m}_RGB_overlay.png')))
values=json.loads((ROOT/'source_comparison.json').read_text())
rows=list(csv.DictReader((ROOT/'radial_metrics.csv').open(encoding='utf-8-sig')))
assert len(rows)==24
for row in rows:
 r=next(q for q in values['classes'] if q['class_en']==row['Root_class'])
 prefix='V66' if row['Workflow']=='V66 U-Net' else 'V90'
 assert float(row['Score_percent'])==100*r[prefix+'_'+row['Metric']]
doc=fitz.open(ROOT/'V66_V90_compact_SCI.pdf');assert len(doc)==1
page=doc[0];spans=[s for b in page.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()]
assert all(s['color']==0 for s in spans)
assert all(s['font'] in ['TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'] for s in spans)
assert min(s['size'] for s in spans)>=7.99
assert all(page.rect.contains(fitz.Rect(s['bbox'])) for s in spans)
assert abs(page.rect.width/72*25.4-190.5)<.01 and abs(page.rect.height/72*25.4-201)<.01
image_checks={}
for ext in ['jpg','png','tiff']:
 im=Image.open(ROOT/f'V66_V90_compact_SCI.{ext}')
 assert im.width==4500 and abs(im.height-201/25.4*600)<1
 assert all(abs(float(d)-600)<.1 for d in im.info['dpi'])
 image_checks[ext]={'size':im.size,'dpi':[float(d) for d in im.info['dpi']]}
for r in regions:
 im=Image.open(ROOT/f'marked_source_RGB/{r["period"]}_RGB_with_{r["roi_id"]}.jpg');assert im.size==(2541,1108)
report={'source_maps_verified_by_sha256':len(provenance['sources']),'exact_original_RGB_crops':True,'exact_label_crops':True,'exact_alpha_overlay_pixels':True,'no_label_dilation_or_smoothing':True,'archived_window_coordinates_match':True,'radial_values_match_prior_table':len(rows),'fonts':sorted(set(s['font'] for s in spans)),'all_text_black':True,'min_font_pt':min(s['size'] for s in spans),'max_font_pt':max(s['size'] for s in spans),'all_PDF_text_within_page':True,'figure_mm':[190.5,201],'images':image_checks,'source_commit':provenance['source_commit'],'source_comparison_sha256':hashlib.sha256((ROOT/'source_comparison.json').read_bytes()).hexdigest()}
(ROOT/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
