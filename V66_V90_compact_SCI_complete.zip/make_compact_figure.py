"""Compose exact archived RGB examples and pooled radial metrics as a compact SCI figure."""
from pathlib import Path
import argparse,json,hashlib,csv
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,patheffects
from matplotlib.patches import Rectangle,Patch
from matplotlib.text import Text

HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output-dir',type=Path,default=HERE)
p.add_argument('--fonts-dir',type=Path,help='Optional directory containing Times New Roman.ttf and Times New Roman Bold.ttf.')
a=p.parse_args();OUT=a.output_dir.resolve();OUT.mkdir(parents=True,exist_ok=True)
if a.fonts_dir:
 for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(a.fonts_dir/n))
for weight in ['normal','bold']:font_manager.findfont(font_manager.FontProperties(family='Times New Roman',weight=weight),fallback_to_default=False)
plt.rcParams.update({'font.family':'Times New Roman','font.size':8,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'svg.fonttype':'none','axes.unicode_minus':False,'axes.linewidth':.5})
W,H=190.5,201
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
PAL=np.array([[0,0,0],[215,131,140],[117,190,216],[230,170,117]],np.uint8)
ALPHA=.85
regions=json.loads((HERE/'roi_manifest.json').read_text())['regions']
source=json.loads((HERE/'source_comparison.json').read_text())
def txt(x,y,s,size=8,ha='left',weight='normal',rotation=0):
 return fig.text(x/W,1-y/H,s,ha=ha,va='center',fontsize=size,weight=weight,rotation=rotation,color='black')
def add_axes(x,y,w,h):
 ax=fig.add_axes([x/W,1-(y+h)/H,w/W,h/H]);ax.set_xticks([]);ax.set_yticks([])
 for spine in ax.spines.values():spine.set_linewidth(.4);spine.set_color('#697176')
 return ax
def overlay(rgb,c):
 assert c.shape==rgb.shape[:2] and set(np.unique(c)).issubset({0,1,2,3,255})
 im=rgb.copy();use=(c>0)&(c<4);im[use]=np.rint((1-ALPHA)*rgb[use]+ALPHA*PAL[c[use]]).astype(np.uint8)
 ignored=c==255;im[ignored]=np.rint((1-ALPHA)*rgb[ignored]+ALPHA*np.array([167,174,180])).astype(np.uint8)
 return im
def box(ax,r,lw=1):
 q=Rectangle((r['x']-.5,r['y']-.5),r['width'],r['height'],fc='none',ec='#E8BC3E',lw=lw)
 q.set_path_effects([patheffects.Stroke(linewidth=lw+1,foreground='black'),patheffects.Normal()]);ax.add_patch(q)
 ax.text(r['x']+r['width']/2,r['y']-26,r['roi_id'],ha='center',va='bottom',fontsize=8,color='black',bbox=dict(fc='white',ec='none',pad=.5))
def scale(ax):
 line,=ax.plot([12,76],[244,244],color='white',lw=1.45,solid_capstyle='butt')
 line.set_path_effects([patheffects.Stroke(linewidth=2.2,foreground='black'),patheffects.Normal()])
 ax.text(44,232,'64 px',ha='center',va='bottom',fontsize=8,color='black',bbox=dict(fc='white',ec='none',pad=.4))

txt(5,5.5,'a',11,weight='bold');txt(13,5.5,'Representative local comparisons',10,weight='bold')
CW,GAP,LEFT=32.5,2,13
for j,s in enumerate(['Source RGB','RGB crop','Reference','V66 U-Net','V90 reviewed']):txt(LEFT+j*(CW+GAP)+CW/2,14,s,8.5,ha='center',weight='bold')
details=[];marked=OUT/'marked_source_RGB';marked.mkdir(exist_ok=True)
for i,r in enumerate(regions):
 t=r['period'];x,y,w,h=[r[k] for k in ['x','y','width','height']]
 rgb=np.array(Image.open(HERE/'sources/RGB'/f'{t}_RGB.png').convert('RGB'))
 labels={m:np.array(Image.open(HERE/f'sources/{m}/{t}_classes.png')) for m in ['reference','V66','V90']}
 assert rgb.shape==(1108,2541,3) and all(c.shape==rgb.shape[:2] for c in labels.values())
 assert w==h==256 and x+w<=2541 and y+h<=1108
 yy=20+i*38;context_h=CW*1108/2541;context_top=yy+(CW-context_h)/2
 ax=add_axes(LEFT,context_top,CW,context_h);ax.imshow(rgb,interpolation='nearest');box(ax,r,.85)
 txt(LEFT+CW/2,yy+3.3,f'{t} / {r["roi_id"]}',8.5,ha='center',weight='bold')
 txt(LEFT+CW/2,yy+CW-3,r['archived_tile_id'],8,ha='center')
 crop=rgb[y:y+h,x:x+w].copy();local={m:c[y:y+h,x:x+w].copy() for m,c in labels.items()}
 arrays=[crop]+[overlay(crop,local[m]) for m in ['reference','V66','V90']]
 for j,im in enumerate(arrays,1):
  ax=add_axes(LEFT+j*(CW+GAP),yy,CW,CW);ax.imshow(im,interpolation='nearest');ax.set_xlim(-.5,255.5);ax.set_ylim(255.5,-.5)
  if j==1:scale(ax)
 folder=OUT/'crops'/f'{r["roi_id"]}_{t}_{r["archived_tile_id"]}';folder.mkdir(parents=True,exist_ok=True)
 Image.fromarray(crop).save(folder/'original_RGB.png')
 for m,c in local.items():
  Image.fromarray(c).save(folder/f'{m}_classes.png');Image.fromarray(overlay(crop,c)).save(folder/f'{m}_RGB_overlay.png')
 details.append({'region':r,'reference_counts':{str(k):int((local['reference']==k).sum()) for k in [0,1,2,3,255]},'prediction_difference_pixels':int((local['V66']!=local['V90']).sum()),'RGB_crop_sha256':hashlib.sha256(crop.tobytes()).hexdigest()})
 # Export the complete archived RGB field with just its locator annotation.
 f=plt.figure(figsize=(2541/300,1108/300));a2=f.add_axes([0,0,1,1]);a2.imshow(rgb,interpolation='nearest');a2.set_axis_off();box(a2,r,2)
 f.savefig(marked/f'{t}_RGB_with_{r["roi_id"]}.jpg',dpi=300,facecolor='white',pil_kwargs={'quality':98,'subsampling':0});plt.close(f)

handles=[Patch(fc=PAL[k]/255,ec='none',label=n) for k,n in [(2,'Newly observed'),(3,'Extending'),(1,'Persistent')]]+[Patch(fc='#A7AEB4',ec='none',label='Ignored reference')]
fig.legend(handles=handles,loc='center',bbox_to_anchor=(.525,1-96.5/H),ncol=4,frameon=False,fontsize=8.5,handlelength=1.2,columnspacing=1.5)
txt(5,106,'b',11,weight='bold');txt(13,106,'Temporal-class reference agreement (%)',10,weight='bold')

METRICS=['Precision','Recall','Dice','IoU'];COLORS=['#75BED8','#E6AA75','#D7838C'];STARTS=[-48,72,192]
R0,SPAN=56,40;csvrows=[]
for cx,prefix,model,title in [(48.6,'V66','V66 U-Net','V66 U-Net'),(141.9,'V90','V90 reviewed','V90 reviewed')]:
 txt(cx,115,title,10,ha='center',weight='bold')
 # A common radius and baseline preserve the previous radial plot's exact scale.
 ax=fig.add_axes([(cx-43)/W,1-188/H,86/W,70/H],projection='polar')
 ax.set_theta_zero_location('N');ax.set_theta_direction(-1);ax.set_ylim(0,140);ax.set_axis_off()
 theta=np.linspace(0,2*np.pi,721)
 for rr in [R0,R0+SPAN/2,R0+SPAN]:ax.plot(theta,np.full_like(theta,rr),color='#D2D8DB',lw=.5,ls='-' if rr==R0 else (0,(2,2)),zorder=0)
 for ci,r in enumerate(source['classes']):
  for mi,metric in enumerate(METRICS):
   deg=STARTS[ci]+12+24*mi;angle=np.deg2rad(deg);value=100*r[prefix+'_'+metric];height=SPAN*value/100
   ax.bar(angle,SPAN,width=np.deg2rad(22.8),bottom=R0,color=COLORS[ci],alpha=.15,ec='white',lw=.5,zorder=1)
   ax.bar(angle,height,width=np.deg2rad(22.8),bottom=R0,color=COLORS[ci],alpha=.98,ec='white',lw=.5,zorder=2)
   aa=deg%360;rot=90-aa;ha='left'
   if 180<aa<360:rot+=180;ha='right'
   ax.text(angle,107,metric,rotation=rot,rotation_mode='anchor',ha=ha,va='center',fontsize=8,zorder=5)
   rot=-aa
   if 90<aa<270:rot+=180
   ax.text(angle,R0+height+4.6,f'{value:.1f}',rotation=rot,rotation_mode='anchor',ha='center',va='center',fontsize=8,zorder=5,bbox=dict(fc='white',ec='none',alpha=.9,pad=.05))
   csvrows.append({'Workflow':model,'Root_class':r['class_en'],'Metric':metric,'Score_percent':value})
 for score in [0,50,100]:ax.text(np.deg2rad(70),R0+SPAN*score/100,str(score),ha='center',va='center',fontsize=8,zorder=6,bbox=dict(fc='white',ec='none',pad=.05))
 # Small Cartesian inset, identical physical size and scale in both workflows.
 iw,ih=19,16.5;center_y=153
 inset=fig.add_axes([(cx+2-iw/2)/W,1-(center_y+ih/2)/H,iw/W,ih/H],facecolor='white')
 vals=[100*r[prefix+'_Dice'] for r in source['classes']]
 inset.bar(range(3),vals,color=COLORS,width=.66,ec='white',lw=.4)
 for i,value in enumerate(vals):inset.text(i,value+3,f'{value:.1f}',ha='center',va='bottom',fontsize=8)
 inset.set(xlim=(-.6,2.6),ylim=(0,125));inset.set_xticks([0,1,2],['N','E','P']);inset.set_yticks([0,50,100]);inset.tick_params(labelsize=8,width=.5,length=1.5,pad=1)
 inset.spines[['top','right']].set_visible(False)
 for side in ['left','bottom']:inset.spines[side].set_color('black');inset.spines[side].set_linewidth(.5)
 inset.set_title('Dice (%)',fontsize=8,pad=1,fontweight='bold')
 txt(cx,190.5,f'Macro Dice = {100*source["summaries"][model]["macro"]["Dice"]:.2f}%',8.5,ha='center')
txt(98.5,198,'Radial metrics: T2–T4 pooled. Center: Dice; N, newly observed; E, extending; P, persistent.',8,ha='center')
for obj in fig.findobj(match=Text):obj.set_color('black');obj.set_fontfamily('Times New Roman')
stem='V66_V90_compact_SCI'
for ext in ['png','pdf']:fig.savefig(OUT/f'{stem}.{ext}',dpi=600,facecolor='white')
fig.savefig(OUT/f'{stem}.tiff',dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
Image.open(OUT/f'{stem}.png').convert('RGB').save(OUT/f'{stem}.jpg','JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
with (OUT/'radial_metrics.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(csvrows[0]));writer.writeheader();writer.writerows(csvrows)
(OUT/'render_metadata.json').write_text(json.dumps({'figure_mm':[W,H],'local_examples':details,'source_RGB':'Archived registered RGB; no new registration.','overlay_alpha':ALPHA,'codes':{'0':'Uncolored/background','1':'Persistent #D7838C','2':'Newly observed #75BED8','3':'Extending #E6AA75','255':'Ignored reference #A7AEB4'},'data_processing':'Exact matched crops and alpha overlays only; no dilation, smoothing, relabeling, inference or training.','radial_metrics':'Unchanged pooled values from the prior verified comparison table, not metrics of the two local crops.','radial_scale':'Scores 0–100% map linearly to bar length above radius 56, with full 100% at radius 96.','insets':'Exact pooled class Dice values, no error bars or artificial replicates.','identity_scope':'Colors show temporal class, not root-instance ownership.','V90_scope':'Final learned/structured/manually reviewed workflow.'},indent=2))
print('Created compact 190.5 × 201 mm composite with two exact local examples and unchanged radial metrics.')
