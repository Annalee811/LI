"""Verify V35 identity, unchanged crops/geometry/background, fonts and exports."""
from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
import fitz
ROOT=Path(__file__).resolve().parent
source=json.loads((ROOT/'source_provenance.json').read_text());fig=json.loads((ROOT/'figure_manifest.json').read_text())
full_checks=0
for r in source['records']:
 a=np.array(Image.open(ROOT/r['source_crop_file']))
 assert hashlib.sha256(a.tobytes()).hexdigest()==r['crop_array_sha256']
 assert a.shape[:2]==(320,420)
 p=Path(r['source_file'])
 if p.exists():
  assert hashlib.sha256(p.read_bytes()).hexdigest()==r['source_sha256'];full_checks+=1
  assert np.array_equal(a,np.array(Image.open(p))[788:1108,500:920])
assert not fig['full_field_panels'] and fig['same_ROI_all_four_periods']
assert len(fig['records'])==4 and {tuple(r['ROI_xyxy']) for r in fig['records']}=={(500,788,920,1108)}
for record in fig['records']:
 t=record['period'];rgb=np.array(Image.open(ROOT/f'source_crops/{t}_RGB.png').convert('RGB'))
 for rec in record['models']:
  mask=np.array(Image.open(ROOT/f'source_crops/{t}_{rec["model"]}.png'))
  assert set(np.unique(mask)).issubset({0,255})
  expected=rgb.copy();expected[mask>0]=[88,168,150]
  out=np.array(Image.open(ROOT/rec['file']))
  assert np.array_equal(out,expected) and np.array_equal(out[mask==0],rgb[mask==0])
  assert hashlib.sha256(out.tobytes()).hexdigest()==rec['overlay_array_sha256']
stem='V35_three_models_T1-T4_local_RGB_SCI'
with fitz.open(ROOT/(stem+'.pdf')) as doc:
 assert len(doc)==1
 fonts={r[3].split('+')[-1] for r in doc[0].get_fonts()}
 assert fonts=={'TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'}
 spans=[s for b in doc[0].get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
 assert all(s['color']==0 for s in spans)
 assert min(s['size'] for s in spans)>=8.49
 for s in spans:
  r=fitz.Rect(s['bbox']);assert r.x0>=0 and r.y0>=0 and r.x1<=doc[0].rect.width and r.y1<=doc[0].rect.height
 sizes=[min(s['size'] for s in spans),max(s['size'] for s in spans)]
exports={}
for ext in ['png','jpg','tiff']:
 with Image.open(ROOT/(stem+'.'+ext)) as im:
  assert im.width==4500 and abs(im.height-round(166/25.4*600))<=1
  assert im.convert('RGB').getpixel((0,0))==(255,255,255)
  exports[ext]={'pixels':list(im.size),'dpi':[float(d) for d in im.info.get('dpi',(0,0))]}
report={'version':'V35 binary segmentation, not V66/V90 temporal labels','source_files_verified':16,'full_source_hash_checks_in_current_workspace':full_checks,'same_field_four_periods':True,'ROI_xyxy':[500,788,920,1108],'crop_pixels':[420,320],'panels':16,'full_field_panels':False,'binary_masks_unchanged':True,'background_RGB_unchanged':True,'overlays_verified':12,'font_faces':sorted(fonts),'text_black':True,'font_range_pt':sizes,'all_text_within_page':True,'exports':exports,'no_training_registration_or_inference':True}
(ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
