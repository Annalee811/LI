"""SCI-style V35 original-RGB and three-model local overlays across T1--T4."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,patheffects
from matplotlib.patches import Patch
import fitz
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);args=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(args.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':9,'text.color':'black','pdf.fonttype':42,'svg.fonttype':'none'})
meta=json.loads((ROOT/'source_provenance.json').read_text())
for r in meta['records']:
 a=np.array(Image.open(ROOT/r['source_crop_file']));assert hashlib.sha256(a.tobytes()).hexdigest()==r['crop_array_sha256']
MODELS={'unet':'U-Net','deeplab':'DeepLabV3+','segformer':'SegFormer-B0'}
COLOR='#58A896';RGB_COLOR=np.array([88,168,150],np.uint8)
W,H=190.5,166
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
def txt(x,y,s,size=9,ha='left',bold=False):
 return fig.text(x/W,1-y/H,s,ha=ha,va='center',fontsize=size,fontweight='bold' if bold else 'normal',color='black')
txt(W/2,5.8,'V35 · Same-field local root segmentation',11.5,'center',True)
LEFT,CW,GAP=13.5,41.5,2;PH=CW*320/420
for j,name in enumerate(['Original RGB']+list(MODELS.values())):
 x=LEFT+j*(CW+GAP)+CW/2
 txt(x,14,name,10,'center',True)
 if j:fig.add_artist(plt.Line2D([(x-6)/W,(x+6)/W],[1-17/H]*2,transform=fig.transFigure,color=COLOR,lw=1.2,solid_capstyle='round'))
outdir=ROOT/'overlays';outdir.mkdir(exist_ok=True);records=[]
for i,t in enumerate(['T1','T2','T3','T4']):
 yy=21+i*(PH+2)
 txt(6,yy+PH/2,t,10,'center',True)
 rgb=np.array(Image.open(ROOT/f'source_crops/{t}_RGB.png').convert('RGB'));assert rgb.shape==(320,420,3)
 images=[rgb];period_records=[]
 for key in MODELS:
  mask=np.array(Image.open(ROOT/f'source_crops/{t}_{key}.png'))>0
  out=rgb.copy();out[mask]=RGB_COLOR
  assert np.array_equal(out[~mask],rgb[~mask])
  file='overlays/'+t+'_'+key+'_on_original_RGB.png';Image.fromarray(out).save(ROOT/file)
  images.append(out)
  period_records.append({'model':key,'foreground_pixels':int(mask.sum()),'file':file,'overlay_array_sha256':hashlib.sha256(out.tobytes()).hexdigest(),'background_unchanged':True})
 for j,im in enumerate(images):
  ax=fig.add_axes([(LEFT+j*(CW+GAP))/W,1-(yy+PH)/H,CW/W,PH/H])
  ax.imshow(im,interpolation='nearest');ax.set(xlim=(-.5,419.5),ylim=(319.5,-.5));ax.set_xticks([]);ax.set_yticks([])
  for s in ax.spines.values():s.set_visible(False)
  if j==0:
   line,=ax.plot([16,116],[304,304],color='white',lw=1.6,solid_capstyle='butt')
   line.set_path_effects([patheffects.Stroke(linewidth=2.5,foreground='black'),patheffects.Normal()])
   ax.text(66,286,'100 px',fontsize=8.5,ha='center',va='bottom',color='black',bbox={'fc':'white','ec':'none','pad':.5})
 records.append({'period':t,'ROI_xyxy':meta['ROI_xyxy'],'original_RGB_array_sha256':hashlib.sha256(rgb.tobytes()).hexdigest(),'models':period_records})
fig.legend(handles=[Patch(fc=COLOR,ec='none',label='Predicted root')],loc='center',bbox_to_anchor=(.53,1-160/H),frameon=False,fontsize=9,handlelength=1.3)
stem='V35_three_models_T1-T4_local_RGB_SCI'
for ext in ['png','pdf']:fig.savefig(ROOT/(stem+'.'+ext),dpi=600,facecolor='white')
fig.savefig(ROOT/(stem+'.tiff'),dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)
Image.open(ROOT/(stem+'.png')).convert('RGB').save(ROOT/(stem+'.jpg'),'JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
with fitz.open(ROOT/(stem+'.pdf')) as doc:doc[0].get_pixmap(matrix=fitz.Matrix(1.7,1.7),alpha=False).save(ROOT/'preview.png')
(ROOT/'figure_manifest.json').write_text(json.dumps({'figure_mm':[W,H],'raster_dpi':600,'layout':'4 periods × [Original RGB,U-Net,DeepLabV3+,SegFormer-B0]','font':'Black Times New Roman, regular/bold, 8.5–11.5 pt','source_version':'V35 binary segmentation','foreground_color':COLOR,'foreground_color_scope':'Binary predicted root for all three models; not temporal root categories or root-instance identities.','full_field_panels':False,'same_ROI_all_four_periods':True,'ROI_xyxy':meta['ROI_xyxy'],'records':records,'scale_bar':'100 source pixels; no physical calibration assumed','no_training_registration_or_new_inference':True},indent=2)+'\n')
print('Created 4×4 V35 local RGB comparison using exact archived binary predictions.')
