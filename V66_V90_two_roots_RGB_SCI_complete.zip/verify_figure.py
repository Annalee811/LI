from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
import fitz
R=Path(__file__).resolve().parent;d=json.loads((R/'data_manifest.json').read_text());f=json.loads((R/'figure_manifest.json').read_text());z=np.load(R/'figure_inputs.npz');a={k:z[k] for k in z.files}
assert d['no_V17_or_V18_inputs'] and f['no_V17_or_V18_inputs']
for k,rec in d['arrays'].items():assert hashlib.sha256(a[k].tobytes()).hexdigest()==rec['array_sha256']
for q in json.loads((R/'figure_source_checks.json').read_text())['checks']:
 assert hashlib.sha256(Path(q['local_file']).read_bytes()).hexdigest()==q['sha256']
assert json.loads((R/'decoder_replay_verification.json').read_text())['all_final_maps_match_archived_V90']
rgb=a['RGB'];sel=a['selected_domain'];assert rgb.shape==(180,240,3)
assert np.array_equal(sel,np.isin(a['V90_axis_owner'],[271,192])&(a['V90']>0))
def col(s):return np.array([int(s[i:i+2],16) for i in [1,3,5]],np.uint8)
expected=[rgb.copy()]
for name in ['V66','V90']:
 im=rgb.copy()
 for c,color in f['temporal_class_colors'].items():im[sel&(a[name]==int(c))]=col(color)
 im[sel&(a[name]==255)]=col('#808890');expected.append(im)
im=rgb.copy()
for i,color in f['axis_ID_colors'].items():im[sel&(a['V90_axis_owner']==int(i))]=col(color)
expected.append(im)
for rec,ex in zip(f['panels'],expected):
 im=np.array(Image.open(R/rec['file']));assert np.array_equal(im,ex) and np.array_equal(im[~sel],rgb[~sel]);assert hashlib.sha256(im.tobytes()).hexdigest()==rec['array_sha256']
assert int(((a['V66']!=a['V90'])&sel).sum())==484
assert np.all(a['V66'][sel&(a['V90_axis_owner']==271)]==2) and np.all(a['V90'][sel&(a['V90_axis_owner']==271)]==2)
assert set(np.unique(a['V66'][sel&(a['V90_axis_owner']==192)]))=={1,2}
assert set(np.unique(a['V90'][sel&(a['V90_axis_owner']==192)]))=={1,3}
with fitz.open(R/(f['stem']+'.pdf')) as doc:
 assert len(doc)==1;page=doc[0];fonts={q[3].split('+')[-1] for q in page.get_fonts()};assert fonts=={'TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'}
 spans=[s for b in page.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
 for s in spans:
  assert s['color']==0
  box=fitz.Rect(s['bbox']);assert box.x0>=0 and box.y0>=0 and box.x1<=page.rect.width and box.y1<=page.rect.height
 txt=page.get_text();assert all(k in txt for k in ['V66','V90','R1','R2','Persistent (P)','New (N)','Extension (E)'])
exports={}
for e in ['jpg','png','tiff']:
 with Image.open(R/(f['stem']+'.'+e)) as im:
  assert abs(im.width-round(210/25.4*600))<=1 and abs(im.height-round(76/25.4*600))<=1
  exports[e]={'pixels':list(im.size),'dpi':[float(v) for v in im.info.get('dpi',[])]}
report={'V66_V90_archived_class_maps_verified':True,'no_V17_or_V18_inputs':True,'exact_V90_structural_replay_maps_verified_all_four_dates':True,'two_V90_candidate_axes':[271,192],'same_ROI_all_panels':[957,312,1197,492],'period':'T3','selected_pixel_changes':484,'R1_unchanged_new':448,'R2_V66_counts':{'persistent':332,'new':484},'R2_V90_counts':{'persistent':434,'extension':382},'RGB_outside_selected_roots_unchanged':True,'independent_biological_identity_validated':False,'V66_instance_owner_map_invented':False,'fonts':sorted(fonts),'all_text_black_within_page':True,'exports':exports,'new_training':False,'ConvLSTM_GAT_forward_rerun':False}
(R/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
