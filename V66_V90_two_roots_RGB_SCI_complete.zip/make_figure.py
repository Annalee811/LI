"""Real V66 versus V90 temporal segments and two V90 candidate axes on original RGB."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,patheffects
from matplotlib.patches import Patch
from matplotlib.text import Text
import fitz
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);arg=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(arg.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':10,'text.color':'black','pdf.fonttype':42,'svg.fonttype':'none'})
d=json.loads((R/'data_manifest.json').read_text());z=np.load(R/'figure_inputs.npz');a={k:z[k] for k in z.files}
for k,rec in d['arrays'].items():assert hashlib.sha256(a[k].tobytes()).hexdigest()==rec['array_sha256']
rgb=a['RGB'];sel=a['selected_domain'];ids=d['selected_V90_candidate_IDs'];CL={1:'#3F75C4',2:'#E69F35',3:'#B64E8B'};AX={ids[0]:'#00A6A0',ids[1]:'#D2674F'}
def color(s):return np.array([int(s[i:i+2],16) for i in [1,3,5]],np.uint8)
views=[rgb.copy()]
for version in ['V66','V90']:
 im=rgb.copy()
 for code,c in CL.items():im[sel&(a[version]==code)]=color(c)
 im[sel&(a[version]==255)]=color('#808890');views.append(im)
axes_im=rgb.copy()
for ai,c in AX.items():axes_im[sel&(a['V90_axis_owner']==ai)]=color(c)
views.append(axes_im)
records=[];names=['Original_RGB_crop','V66_two_roots_segments','V90_two_roots_segments','V90_two_candidate_axes']
for name,im in zip(names,views):
 assert np.array_equal(im[~sel],rgb[~sel]);Image.fromarray(im).save(R/(name+'.png'));records.append({'file':name+'.png','array_sha256':hashlib.sha256(im.tobytes()).hexdigest()})
W,H=210,76;LEFT,CW,GAP=7,47.5,2;PH=CW*180/240
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
def txt(x,y,s,size=10,bold=False,ha='left'):
 fig.text(x/W,1-y/H,s,ha=ha,va='center',fontsize=size,fontweight='bold' if bold else 'normal',color='black')
axs=[]
for j,(im,title) in enumerate(zip(views,['A  Original RGB','B  V66','C  V90','D  V90 root axes'])):
 x=LEFT+j*(CW+GAP);txt(x+CW/2,7.5,title,11,True,'center')
 aa=fig.add_axes([x/W,1-(15+PH)/H,CW/W,PH/H]);aa.imshow(im,interpolation='nearest');aa.axis('off');axs.append(aa)
def label(ax,txt,mask,xytext,target):
 pts=np.argwhere(mask);q=pts[np.argmin(((pts-np.array(target[::-1]))**2).sum(1))]
 ax.annotate(txt,xy=(q[1],q[0]),xytext=xytext,textcoords='data',ha='center',va='center',fontsize=9.5,fontweight='bold',color='black',bbox={'fc':'white','ec':'none','alpha':.95,'pad':1.2},arrowprops={'arrowstyle':'-','color':'black','lw':.7},zorder=9)
label(axs[2],'N',sel&(a['V90']==2),(183,62),(190,96))
label(axs[2],'P',sel&(a['V90']==1),(35,58),(71,48))
label(axs[2],'E',sel&(a['V90']==3),(42,146),(88,144))
label(axs[3],'R1',sel&(a['V90_axis_owner']==ids[0]),(183,62),(190,96))
label(axs[3],'R2',sel&(a['V90_axis_owner']==ids[1]),(48,115),(111,112))
line,=axs[0].plot([12,62],[166,166],color='white',lw=1.8,solid_capstyle='butt');line.set_path_effects([patheffects.Stroke(linewidth=2.7,foreground='black'),patheffects.Normal()])
axs[0].text(37,154,'50 px',fontsize=9,ha='center',va='bottom',color='black',bbox={'fc':'white','ec':'none','pad':.5})
for j,s in [(1,'Original U-Net'),(2,'Refined workflow'),(3,'Candidate IDs')]:txt(LEFT+j*(CW+GAP)+CW/2,57,s,9,True,'center')
leg=fig.legend(handles=[Patch(fc=CL[c],ec='none',label=n) for c,n in [(1,'Persistent (P)'),(2,'New (N)'),(3,'Extension (E)')]],loc='center',bbox_to_anchor=(.52,1-67/H),ncol=3,frameon=False,fontsize=9.5,handlelength=1.1,columnspacing=2)
for q in leg.get_texts():q.set_fontweight('bold')
for q in fig.findobj(match=Text):q.set_fontfamily('Times New Roman');q.set_color('black')
stem='V66_V90_two_roots_axis_and_segment_refinement_RGB_SCI'
for ext in ['png','pdf']:fig.savefig(R/(stem+'.'+ext),dpi=600,facecolor='white')
fig.savefig(R/(stem+'.tiff'),dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
with Image.open(R/(stem+'.png')) as im:im.convert('RGB').save(R/(stem+'.jpg'),'JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
(R/'figure_manifest.json').write_text(json.dumps({'stem':stem,'figure_mm':[W,H],'dpi':600,'panels':records,'temporal_class_colors':{str(k):v for k,v in CL.items()},'axis_ID_colors':{str(k):v for k,v in AX.items()},'display_IDs':d['display_IDs'],'same_ROI':d['ROI_xyxy'],'period':d['period'],'selected_roots_only':2,'source_versions':d['source_versions'],'V66_V90_class_maps':'Exact hash-verified archived labels, with no manual class changes','ownership_panel':'V90 decoder ownership only; no V66 instance ownership is fabricated','class_unknown_pixels':d['V90_class_unknown_pixels'],'no_V17_or_V18_inputs':True,'photographic_background_unchanged':True,'font':'Black Times New Roman; bold legend, headers and labels'},indent=2)+'\n')
with fitz.open(R/(stem+'.pdf')) as doc:doc[0].get_pixmap(matrix=fitz.Matrix(2.3,2.3),alpha=False).save(R/'preview.png')
print('Created four-panel TRUE V66/V90 two-root comparison, with three temporal classes and V90 scalar ownership.')
