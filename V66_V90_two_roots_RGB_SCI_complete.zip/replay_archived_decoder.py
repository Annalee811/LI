"""Replay only released V90 structural/review steps from exact archived neural outputs.
No training or ConvLSTM/GAT forward pass is run; all final maps must match archive.
"""
from pathlib import Path
import os,shutil,subprocess,json,sys
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;src=R/'source_V90';assets=src/'assets';w=R/'V90_decoder_replay';w.mkdir(exist_ok=True)
for p in assets.iterdir():
 if p.name.startswith('expected') or p.name in ['review_support.png','review_annotation.json']:continue
 dest=w/p.name
 if p.is_dir():shutil.copytree(p,dest,dirs_exist_ok=True)
 else:shutil.copy2(p,dest)
shutil.copy2(assets/'expected_joint_features.npz',w/'joint/joint_inference.npz')
shutil.copy2(assets/'expected_pair_logits.npy',w/'joint/joint_pair_logits.npy')
(w/'analysis-scripts').mkdir(exist_ok=True)
shutil.copy2('/workspace/LI/analysis-scripts/dataset_identity.py',w/'analysis-scripts/dataset_identity.py')
shutil.copytree('/workspace/LI/dataset/current',w/'dataset/current',dirs_exist_ok=True)
env=os.environ.copy();env['ROOT_REPRO_WORK']=str(w)
for name in ['decode.py','branch_review.py','axis_consistency.py','junction_consistency.py']:
 print('REPLAY',name,flush=True);subprocess.run([sys.executable,str(src/'core'/name)],env=env,check=True)
 if name=='branch_review.py':shutil.copytree(w/'branch/candidate_full',w/'branch/full',dirs_exist_ok=True)
review=json.loads((assets/'review_annotation.json').read_text());mask=np.array(Image.open(assets/'review_support.png'))>0;dest=w/'reviewed/full';dest.mkdir(parents=True,exist_ok=True);rows=[]
for t in ['T1','T2','T3','T4']:
 pred=np.array(Image.open(w/f'junction/full/{t}_classes.png'));before=pred.copy()
 if t==review['period']:
  take=mask&(pred>0);assert int(take.sum())==review['foreground_pixels'];pred[take]=review['class_code']
 assert np.array_equal(pred>0,before>0)
 expected=np.array(Image.open(assets/f'expected/{t}_classes.png'));diff=int((pred!=expected).sum());rows.append({'period':t,'different_pixels':diff});assert diff==0,(t,diff)
 Image.fromarray(pred).save(dest/f'{t}_classes.png')
report={'archived_neural_features_and_pair_logits_used':True,'ConvLSTM_GAT_forward_rerun':False,'new_training':False,'structural_and_review_steps_replayed':True,'all_final_maps_match_archived_V90':True,'rows':rows}
(R/'decoder_replay_verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
