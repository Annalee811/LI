"""Crop only true V66/V90 outputs and two V90 decoded candidate axes."""
from pathlib import Path
import json,hashlib,pickle,sys
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;S=Path('/workspace/work/V66_V90_same_field_SCI_20261113');W=R/'V90_decoder_replay'
sys.path.insert(0,'/workspace/LI/analysis-scripts');from dataset_identity import require_active_position
require_active_position('0353-2-B3')
assert json.loads((R/'decoder_replay_verification.json').read_text())['all_final_maps_match_archived_V90']
q=json.loads((R/'candidate_two_root_regions.json').read_text())[0];t=q['period'];box=q['ROI_xyxy'];x,y,xx,yy=box;sl=np.s_[y:yy,x:xx];ids=[q['new_axis'],q['established_axis']]
verify=json.loads((S/'source_verification.json').read_text());checks=[]
for kind in ['RGB','V66','V90']:
 rel=f'sources/{kind}/{t}_'+('RGB.png' if kind=='RGB' else 'classes.png');rec=next(r for r in verify['checks'] if r['file']==rel);p=S/rel
 assert hashlib.sha256(p.read_bytes()).hexdigest()==rec['sha256'];checks.append(dict(rec,local_file=str(p)))
rgb=np.array(Image.open(S/f'sources/RGB/{t}_RGB.png').convert('RGB'));p66=np.array(Image.open(S/f'sources/V66/{t}_classes.png'));p90=np.array(Image.open(S/f'sources/V90/{t}_classes.png'))
assert np.array_equal(p66>0,p90>0)
owner=np.load(W/f'junction/ownership/{t}_axis_owner.npz')['axis'];selected=np.isin(owner[sl],ids)&(p90[sl]>0)
a={'RGB':rgb[sl].copy(),'V66':p66[sl].copy(),'V90':p90[sl].copy(),'V90_axis_owner':owner[sl].copy(),'selected_domain':selected}
np.savez_compressed(R/'figure_inputs.npz',**a)
with (W/'axis/root_axis_snapshots.pkl').open('rb') as f:snap=pickle.load(f)
np.savez_compressed(R/'selected_V90_paths.npz',**{f'axis_{i}':snap[t]['points'][i] for i in ids})
states=[next(s for s in snap[t]['states'] if s['axis']==i) for i in ids]
counts=[]
for i in ids:
 mask=selected&(owner[sl]==i)
 counts.append({'axis':i,'V66':{str(int(c)):int(n) for c,n in zip(*np.unique(p66[sl][mask],return_counts=True))},'V90':{str(int(c)):int(n) for c,n in zip(*np.unique(p90[sl][mask],return_counts=True))}})
d={'position':'0353-2-B3','period':t,'ROI_xyxy':box,'selected_V90_candidate_IDs':ids,'display_IDs':{'R1':ids[0],'R2':ids[1]},'source_repository':'Annalee811/Temporal-segmentation-model','source_commit':'4615bcbd37442a3b11e5ad4533242df95f237fb6','source_versions':{'before':'03_temporal_V66: archived U-Net temporal output','after':'04_ConvLSTM_GAT_V90: archived learned/structural/manually reviewed result'},'candidate_states':states,'per_axis_class_counts':counts,'V90_owner_reconstruction':'Released structural/review decoder replayed from exact archived neural arrays and logits; all four final class maps match archive at every pixel. No new training or ConvLSTM/GAT forward.','V66_ownership':'No comparable V66 instance-owner map is supplied. V66 and V90 classes are compared on the same two V90 candidate masks; no V66 identity labels are invented.','identity_scope':'V90 scalar raster ownership, not independently established biological parent/lateral identity. Contact alone does not establish parentage.','selection':'One qualitative illustration; candidate ROI chosen by crossing angle and both persistent/extension support. Changed-pixel counts were not used to rank examples.','arrays':{k:{'shape':list(v.shape),'array_sha256':hashlib.sha256(v.tobytes()).hexdigest()} for k,v in a.items()},'binary_foreground_same_before_after':True,'V90_class_unknown_pixels':int((a['V90'][selected]==255).sum()),'no_V17_or_V18_inputs':True}
(R/'data_manifest.json').write_text(json.dumps(d,indent=2)+'\n');(R/'figure_source_checks.json').write_text(json.dumps({'checks':checks,'decoder_replay':json.loads((R/'decoder_replay_verification.json').read_text())},indent=2)+'\n')
print(json.dumps({'period':t,'ROI':box,'two_roots':ids,'counts':counts,'states':states},indent=2))
