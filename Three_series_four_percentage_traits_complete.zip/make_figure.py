"""Replot four unchanged percentage means with a larger, single-axis SCI layout."""
from pathlib import Path
import argparse,csv,json,hashlib,sys
import numpy as np
from PIL import Image
from openpyxl import load_workbook,Workbook
from openpyxl.styles import Font,Alignment
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.text import Text

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'provenance/analysis-scripts'))
from dataset_identity import require_active_position
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);args=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(args.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':10,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'svg.fonttype':'none','axes.linewidth':.8,'axes.unicode_minus':False})
source=ROOT/'sources/All_microtube_root_traits.xlsx'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='ea74bf1853766e51fa3b30546d6893032e57e50ea991514c2735182a6fdb0e52'
w=load_workbook(source,data_only=True)
def read(name):
 it=w[name].values;h=next(it);return h,[dict(zip(h,row)) for row in it]
head,summary=read('Full_precision');raw_head,raw=read('All_72_cells')
for r in raw:require_active_position(r['Observation_unit'])
specs=[('Persistent','Persistent_share_current_pct_mean','#C9697A','s','-'),('New','New_share_current_pct_mean','#459FC4','^','-'),('Extension','Extension_share_current_pct_mean','#DCA050','D','-'),('E / Lprev','Extension_relative_previous_pct_mean','#8066AE','v','--')]
previous=json.loads((ROOT/'previous_five_metric_lines.json').read_text())
valid=lambda v:isinstance(v,(int,float)) and not isinstance(v,bool) and np.isfinite(v)
W,H=190.5,100
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white');handles=[];lines=[];data=[];layout=[]
for i,(material,left) in enumerate(zip(['0353','A017','Q1'],[16,76,136])):
 ax=fig.add_axes([left/W,1-70/H,49.5/W,56/H]);ax.set(xlim=(.85,4.15),ylim=(0,100))
 ax.set_xticks([1,2,3,4],['T1','T2','T3','T4']);ax.set_yticks([0,25,50,75,100])
 ax.tick_params(axis='both',labelsize=10,length=3,width=.8,pad=3,color='black',labelcolor='black')
 ax.spines[['top','right']].set_visible(False)
 for side in ['left','bottom']:ax.spines[side].set_color('black');ax.spines[side].set_linewidth(.8)
 ax.grid(axis='y',color='#E6E8EB',lw=.55,alpha=.7,zorder=0);ax.set_axisbelow(True)
 rows=sorted([r for r in summary if r['Material']==material],key=lambda r:r['Period'])
 for label,field,color,marker,style in specs:
  values=[float(r[field]) if valid(r[field]) else None for r in rows]
  old=next(q for q in previous if q['Material']==material and q['Metric']==label)
  assert old['y']==values
  line,=ax.plot([1,2,3,4],[v if v is not None else np.nan for v in values],color=color,linestyle=style,lw=1.9,marker=marker,markersize=6,markeredgewidth=1,markeredgecolor=color,markerfacecolor='white' if label=='E / Lprev' else color,label=label,zorder=3)
  if style=='--':line.set_dashes([3.4,2.2])
  if i==0:handles.append(line)
  lines.append({'Material':material,'Metric':label,'x':[1,2,3,4],'y':values})
  for r,v in zip(rows,values):data.append({'Material':material,'Period':r['Period'],'Metric':label,'Mean_percent':v,'n_adjacent_pairs':r['n_interval'],'source_field':field})
 ax.set_xlabel('Period',fontsize=10.5,labelpad=6)
 fig.text((left-10)/W,1-7/H,'abc'[i],fontsize=12,fontweight='bold',ha='left',va='center')
 fig.text((left+24.75)/W,1-7/H,material,fontsize=12.5,fontweight='bold',ha='center',va='center')
 layout.append({'Material':material,'axis_count':1,'y_limits':[0,100],'curves':len(ax.lines),'axes_mm':[left,14,49.5,56]})
fig.text(3.6/W,1-42/H,'Temporal traits (%)',rotation=90,fontsize=11.5,ha='center',va='center')
fig.legend(handles=handles,labels=[s[0] for s in specs],ncol=4,loc='center',bbox_to_anchor=(.53,1-91/H),frameon=False,fontsize=10,handlelength=2.7,columnspacing=2.2,handletextpad=.6)
for t in fig.findobj(match=Text):t.set_fontfamily('Times New Roman');t.set_color('black')
assert len(fig.axes)==3 and len(lines)==12
stem='Three_series_four_percentage_traits_SCI'
for ext in ['png','pdf','svg']:fig.savefig(ROOT/f'{stem}.{ext}',dpi=600,facecolor='white')
fig.savefig(ROOT/f'{stem}.tiff',dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
Image.open(ROOT/f'{stem}.png').convert('RGB').save(ROOT/f'{stem}.jpg','JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
(ROOT/'plotted_lines.json').write_text(json.dumps(lines,indent=2))
with (ROOT/'plotted_percentage_means.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)
x=Workbook();s=x.active;s.title='Plotted_percentage_means';s.append(['Material','Period','n_adjacent_pairs']+[q[0]+' (%)' for q in specs])
for r in summary:s.append([r['Material'],r['Period'],r['n_interval']]+[r[q[1]] if valid(r[q[1]]) else None for q in specs])
for name,h,rs in [('Original_source_summary',head,summary),('Original_72_cells',raw_head,raw)]:
 sh=x.create_sheet(name);sh.append(h)
 for r in rs:sh.append([r[k] for k in h])
for sh in x:
 sh.freeze_panes='C2';sh.auto_filter.ref=sh.dimensions
 for cell in sh[1]:cell.font=Font(name='Times New Roman',size=11,bold=True,color='000000');cell.alignment=Alignment(wrap_text=True)
 for col in sh.columns:sh.column_dimensions[col[0].column_letter].width=24
x.save(ROOT/'Three_series_four_percentage_plot_data.xlsx')
(ROOT/'plot_metadata.json').write_text(json.dumps({'figure_mm':[W,H],'panels':layout,'metrics':[q[0] for q in specs],'displayed_root_length_curves':0,'displayed_secondary_axes':0,'source_values_identical_to_previous_plot':True,'all_means':'Original frozen Full_precision percentage means from valid adjacent pairs.','valid_mean_points':36,'T1':'Baseline percentages undefined; missing, not zero.','adjacent_pair_counts_T2_T3_T4':{'0353':[6,6,6],'A017':[6,4,4],'Q1':[3,2,3]},'sample_counts_location':'Caption and data workbook; removed from image to simplify layout after removing the length metric.','font':'Black Times New Roman, 10–12.5 pt','line_width_pt':1.9,'marker_size_pt':6,'aggregation_scope':'18 positions nested within 8 source tubes; valid temporal pairs n=40.','source_workbook_SHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_commit':'8b4fdb81b5938720e263d802426745c982c4479c','source_models':'V35 binary / V66 temporal U-Net trait estimates, not V90.','original_project_files_changed':False},indent=2))
print('Created three larger single-axis panels with four unchanged percentage curves; no root-length curve or secondary axis.')
