from pathlib import Path
import json,csv,hashlib
from PIL import Image
import fitz

r=Path(__file__).resolve().parent
lines=json.loads((r/'plotted_lines.json').read_text());old=json.loads((r/'previous_five_metric_lines.json').read_text());meta=json.loads((r/'plot_metadata.json').read_text())
assert len(lines)==12 and sum(v is not None for row in lines for v in row['y'])==36
assert {row['Metric'] for row in lines}=={'Persistent','New','Extension','E / Lprev'}
for row in lines:
 previous=next(q for q in old if q['Material']==row['Material'] and q['Metric']==row['Metric'])
 assert row['y']==previous['y'] and row['x']==[1,2,3,4] and row['y'][0] is None
assert meta['displayed_root_length_curves']==meta['displayed_secondary_axes']==0
assert all(q['axis_count']==1 and q['y_limits']==[0,100] and q['curves']==4 for q in meta['panels'])
doc=fitz.open(r/'Three_series_four_percentage_traits_SCI.pdf');assert len(doc)==1
page=doc[0];assert not page.get_images();assert 'Skeleton' not in page.get_text()
spans=[s for b in page.get_text('dict')['blocks'] if 'lines' in b for line in b['lines'] for s in line['spans'] if s['text'].strip()]
assert all(s['color']==0 and page.rect.contains(fitz.Rect(s['bbox'])) for s in spans)
assert all(s['font'] in ['TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'] for s in spans)
assert min(s['size'] for s in spans)>=9.99
images={}
for ext in ['jpg','png','tiff']:
 im=Image.open(r/f'Three_series_four_percentage_traits_SCI.{ext}');assert im.size==(4500,2362)
 assert all(abs(float(d)-600)<.1 for d in im.info['dpi'])
 images[ext]={'size':im.size,'dpi':[float(d) for d in im.info['dpi']]}
report={'three_material_panels':True,'curves_per_panel':4,'root_length_curve_and_axis_removed':True,'no_secondary_axes':True,'all_36_means_unchanged_from_previous_figure':True,'T1_baseline_not_zero_filled':True,'all_panels_y_range':[0,100],'fonts':sorted(set(s['font'] for s in spans)),'font_size_pt':[min(s['size'] for s in spans),max(s['size'] for s in spans)],'all_text_black_and_within_page':True,'vector_PDF':True,'figure_mm':[190.5,100],'raster_exports':images}
(r/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
