"""Three matched 3D filled-line panels using the existing percentage means."""
from pathlib import Path
import argparse,json,csv,sys
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,colors
from matplotlib.collections import PolyCollection
from matplotlib.patches import Patch
from matplotlib.text import Text

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'provenance/analysis-scripts'))
from dataset_identity import require_active_position
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);a=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(a.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':10.5,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'svg.fonttype':'none','axes.unicode_minus':False})
data=json.loads((ROOT/'source_four_metric_lines.json').read_text())
# Increasing depth; the tallest persistent layer sits behind the smaller layers.
traits=[('E / Lprev','R','#725B9E'),('Extension','E','#2A9D9A'),('New','N','#7ACB80'),('Persistent','P','#F3D84A')]
W,H=240,112
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white');audit=[];axes_meta=[]
for i,material in enumerate(['0353','A017','Q1']):
 ax=fig.add_axes([.035+i*.33,.16,.27,.74],projection='3d')
 ax.set_proj_type('ortho');ax.view_init(elev=24,azim=-58);ax.set_box_aspect((1.15,1,.85))
 ax.set(xlim=(1,4.1),ylim=(-.25,3.25),zlim=(0,100))
 ax.set_xticks([1,2,3,4],['T1','T2','T3','T4']);ax.set_yticks([0,1,2,3],[q[1] for q in traits]);ax.set_zticks([0,25,50,75,100])
 ax.tick_params(axis='x',labelsize=10,pad=1);ax.tick_params(axis='y',labelsize=10,pad=1);ax.tick_params(axis='z',labelsize=10,pad=1)
 ax.set_xlabel('Period',fontsize=11,labelpad=4,fontweight='bold');ax.set_ylabel('Trait',fontsize=11,labelpad=7,fontweight='bold');ax.set_zlabel('')
 for axis in [ax.xaxis,ax.yaxis,ax.zaxis]:
  axis.set_pane_color((1,1,1,1));axis._axinfo['grid'].update({'color':(.83,.85,.87,1),'linewidth':.55});axis.line.set_color('black');axis.line.set_linewidth(.7)
 for depth,(metric,short,color) in enumerate(traits):
  record=next(r for r in data if r['Material']==material and r['Metric']==metric)
  assert record['y'][0] is None
  xx=np.array([x for x,z in zip(record['x'],record['y']) if z is not None],float)
  zz=np.array([z for z in record['y'] if z is not None],float)
  verts=[[(xx[0],0),*list(zip(xx,zz)),(xx[-1],0)]]
  poly=PolyCollection(verts,facecolors=[color],edgecolors=[tuple(.75*v for v in colors.to_rgb(color))],linewidths=.7,alpha=.66)
  ax.add_collection3d(poly,zs=depth,zdir='y')
  ax.plot(xx,np.full_like(xx,depth),zz,color='black',lw=1,ls=(0,(3,2)),marker='o',markersize=3.5,markerfacecolor='white',markeredgecolor='black',markeredgewidth=.7,zorder=6)
  for x,z in zip(xx,zz):
   align='right' if depth==0 or (depth==3 and x==4) else 'left' if depth==1 else 'center'
   ax.text(x,depth,z+4,f'{z:.2f}',fontsize=10.5,color='black',ha=align,va='bottom',zorder=9)
   audit.append({'Material':material,'Metric':metric,'Period':f'T{int(x)}','Depth':depth,'Mean_percent':float(z),'Annotation':f'{z:.2f}'})
 axes_meta.append({'Material':material,'projection':'orthographic','elevation':24,'azimuth':-58,'z_limits':[0,100],'trait_layers':4,'observed_points':12,'T1_imputed':False})
 fig.text(.17+i*.33,.95,material,ha='center',va='center',fontsize=14,fontweight='bold')
 fig.text(.025+i*.33,.95,'ABC'[i],ha='left',va='center',fontsize=13,fontweight='bold')
fig.text(.012,.54,'Mean (%)',rotation=90,ha='center',va='center',fontsize=11,fontweight='bold')
legend=[Patch(facecolor=traits[k][2],edgecolor='none',alpha=.8,label=label) for k,label in [(3,'Persistent (P)'),(2,'New (N)'),(1,'Extension (E)'),(0,'E / Lprev (R)')]]
leg=fig.legend(handles=legend,loc='center',bbox_to_anchor=(.5,.065),ncol=4,frameon=False,fontsize=11,handlelength=1.6,columnspacing=2)
for t in leg.get_texts():t.set_fontweight('bold')
for ax in fig.axes:
 for axis in [ax.xaxis,ax.yaxis,ax.zaxis]:
  axis.label.set_fontweight('bold')
  for t in axis.get_ticklabels():t.set_fontweight('bold')
for t in fig.findobj(match=Text):t.set_color('black');t.set_fontfamily('Times New Roman')
stem='Three_series_3D_bold_legend_axes'
for ext in ['png','pdf','svg']:fig.savefig(ROOT/f'{stem}.{ext}',dpi=600,facecolor='white')
fig.savefig(ROOT/f'{stem}.tiff',dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
Image.open(ROOT/f'{stem}.png').convert('RGB').save(ROOT/f'{stem}.jpg','JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
with (ROOT/'plotted_point_annotations.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(audit[0]));w.writeheader();w.writerows(audit)
(ROOT/'plot_metadata.json').write_text(json.dumps({'figure_mm':[W,H],'panels':axes_meta,'depth_order':[q[0] for q in traits],'source_values_unchanged':True,'observed_point_annotations':len(audit),'fill_definition':'Polygon closure to z=0 for display only, not additional observations. Fill exists only over T2–T4.','curve_definition':'Straight segments between actual mean points; no smoothing or new peaks.','source':'Same frozen percentage means as previous four-metric plot. Root-length curve remains omitted.','font':'Black Times New Roman','bold_elements':['legend text','Period axis label','Trait axis label','Mean (%) axis label','all x/y/z tick labels'],'formatting_only':True,'line_annotations':'Actual means, displayed to two decimals.'},indent=2))
print('Rendered three 3D filled-line panels with 36 actual point annotations.')
