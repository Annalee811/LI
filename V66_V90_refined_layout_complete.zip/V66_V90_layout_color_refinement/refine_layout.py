"""Format-only refinement of the uploaded PDF using its native embedded fonts."""
from pathlib import Path
import argparse,json,hashlib,io,re
import numpy as np
from PIL import Image
import fitz
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties,fontManager
from matplotlib.patches import Patch
from matplotlib import patheffects

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',type=Path,default=ROOT/'uploaded_source.pdf');args=p.parse_args()
(ROOT/'fonts').mkdir(exist_ok=True);(ROOT/'original_pdf_images').mkdir(exist_ok=True);(ROOT/'recolored_pdf_images').mkdir(exist_ok=True)
with fitz.open(args.input) as doc:
 page=doc[0];assert len(doc)==1
 for r in page.get_fonts():
  name,ext,kind,data=doc.extract_font(r[0])
  assert 'TimesNewRoman' in name and ext=='ttf'
  (ROOT/'fonts'/('TimesNewRoman_Bold.ttf' if 'Bold' in name else 'TimesNewRoman_Regular.ttf')).write_bytes(data)
 spans=[s for b in page.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
 infos=sorted(page.get_image_info(xrefs=True),key=lambda r:(round(r['bbox'][1],1),r['bbox'][0]))
 assert len(infos)==16
 images={}
 for i,info in enumerate(infos):
  row,col=divmod(i,4);key=(f'T{row+1}',['RGB','reference','U-Net','Reviewed'][col])
  images[key]=np.array(Image.open(io.BytesIO(doc.extract_image(info['xref'])['image'])).convert('RGB'))
  Image.fromarray(images[key]).save(ROOT/'original_pdf_images'/(key[0]+'_'+key[1]+'.png'))

def fp(size=8.5,bold=False):return FontProperties(fname=str(ROOT/'fonts'/('TimesNewRoman_Bold.ttf' if bold else 'TimesNewRoman_Regular.ttf')),size=size)
for f in (ROOT/'fonts').glob('*.ttf'):fontManager.addfont(str(f))
plt.rcParams.update({'pdf.fonttype':42,'svg.fonttype':'none','text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','axes.linewidth':.5})

# All numeric strings and styles are read from the upload, not from old metrics.
numeric=[s for s in spans if re.fullmatch(r'\d+\.\d+',s['text']) and 55<s['bbox'][1]<159]
groups=[]
for j in range(3):
 ss=sorted([s for s in numeric if (0 if s['bbox'][0]<190 else 1 if s['bbox'][0]<365 else 2)==j],key=lambda s:s['origin'][1])
 assert len(ss)==8 and all(s['size']==8.5 for s in ss)
 groups.append(ss)
titles=sorted([s for s in spans if 'roots (%)' in s['text']],key=lambda s:s['bbox'][0]);assert len(titles)==3
macro=next(s for s in spans if s['text'].startswith('Macro Dice:'))
macro_text=macro['text'].rstrip().removesuffix('|').rstrip()  # orphaned layout separator only
headers=sorted([s for s in spans if 249<s['bbox'][1]<252],key=lambda s:s['bbox'][0]);assert len(headers)==4

OLD={1:(91,118,164),2:(217,123,102),3:(101,166,154)}
COLORS={1:'#56709C',2:'#D38B73',3:'#408F83'}
RGB={c:(np.array(matplotlib.colors.to_rgb(h))*255).round().astype(np.uint8) for c,h in COLORS.items()}
recolored={};image_audit=[]
for key,a in images.items():
 t,role=key;out=a.copy();changed=np.zeros(a.shape[:2],bool);counts={}
 if role!='RGB':
  background=images[(t,'RGB')]
  for c,color in OLD.items():
   m=np.all(a==color,2)
   assert not np.any(m&np.all(a==background,2)), 'Ambiguous class/background palette collision'
   out[m]=RGB[c];changed|=m;counts[str(c)]=int(m.sum())
 assert np.array_equal(out[~changed],a[~changed])
 if role=='RGB' or t=='T1':assert np.array_equal(out,a)
 recolored[key]=out
 file='recolored_pdf_images/'+t+'_'+role+'.png';Image.fromarray(out).save(ROOT/file)
 image_audit.append({'period':t,'role':role,'file':file,'shape':list(a.shape),'source_array_sha256':hashlib.sha256(a.tobytes()).hexdigest(),'output_array_sha256':hashlib.sha256(out.tobytes()).hexdigest(),'original_geometry_and_background_unchanged':True,'recolored_pixels':int(changed.sum()),'class_pixel_counts':counts})

W,H=540,650
fig=plt.figure(figsize=(W/72,H/72),facecolor='white')
def txt(x,y,s,size=8.5,bold=False,ha='left'):
 return fig.text(x/W,1-y/H,s,ha=ha,va='center',fontproperties=fp(size,bold),color='black')
txt(12,13,'A',12,True)
fig.legend(handles=[Patch(fc='#DCE2E5',ec='none',label='U-Net'),Patch(fc='#6C7B87',ec='none',label='Reviewed')],loc='center',bbox_to_anchor=(.79,1-13/H),ncol=2,frameon=False,prop=fp(9),handlelength=1.1,columnspacing=1.8)
metric_names=['Precision','Recall','Dice','IoU']
for j,c in enumerate([2,3,1]):
 left=54+j*176;width=120;center=left+width/2
 txt(center,34,titles[j]['text'],10.5,True,'center')
 fig.add_artist(plt.Line2D([(center-17)/W,(center+17)/W],[1-46/H]*2,transform=fig.transFigure,color=COLORS[c],lw=1.5,solid_capstyle='round'))
 ax=fig.add_axes([left/W,1-159/H,width/W,101/H])
 yy=np.arange(4)[::-1]
 a=np.array([float(groups[j][i]['text']) for i in [0,2,4,6]])
 b=np.array([float(groups[j][i]['text']) for i in [1,3,5,7]])
 pale=.28*np.array(matplotlib.colors.to_rgb(COLORS[c]))+.72
 ax.barh(yy+.16,a,height=.245,color=pale,ec='none',zorder=3)
 ax.barh(yy-.16,b,height=.245,color=COLORS[c],ec='none',zorder=3)
 for k in range(4):
  for model,offset in [(0,.16),(1,-.16)]:
   span=groups[j][2*k+model];val=float(span['text'])
   ax.text(val+1.6,yy[k]+offset,span['text'],ha='left',va='center',fontproperties=fp(span['size'],'Bold' in span['font']),color='black',zorder=4)
 ax.set(xlim=(0,118),ylim=(-.6,3.6));ax.set_yticks(yy,metric_names);ax.set_xticks([0,50,100])
 ax.tick_params(axis='x',length=2,width=.5,color='#A8B1B6',pad=3);ax.tick_params(axis='y',length=0,pad=3)
 for t in ax.get_yticklabels():t.set_fontproperties(fp(8.5,t.get_text()=='Dice'))
 for t in ax.get_xticklabels():t.set_fontproperties(fp(8.5))
 ax.spines[['top','left','right']].set_visible(False);ax.spines['bottom'].set_color('#BAC3C8');ax.spines['bottom'].set_linewidth(.5)
 ax.xaxis.grid(True,color='#EDF0F1',lw=.5);ax.set_axisbelow(True)

# Centered, quiet metric band replaces the uneven empty gap in the source PDF.
for y in [180,201]:fig.add_artist(plt.Line2D([12/W,526/W],[1-y/H]*2,transform=fig.transFigure,color='#E1E6E8',lw=.55))
txt(W/2,190.5,macro_text,9.5,True,'center')
txt(12,216,'B',12,True)
LEFT,CW,GAP=31,120,5
PH=CW*747/981
for j,h in enumerate(headers):txt(LEFT+j*(CW+GAP)+CW/2,230,h['text'],h['size'],'Bold' in h['font'],'center')
for i,t in enumerate(['T1','T2','T3','T4']):
 top=242+i*(PH+5)
 txt(14,top+PH/2,t,10,True,'center')
 for j,role in enumerate(['RGB','reference','U-Net','Reviewed']):
  ax=fig.add_axes([(LEFT+j*(CW+GAP))/W,1-(top+PH)/H,CW/W,PH/H])
  a=recolored[(t,role)];ax.imshow(a,interpolation='nearest');ax.set(xlim=(-.5,a.shape[1]-.5),ylim=(a.shape[0]-.5,-.5));ax.set_xticks([]);ax.set_yticks([])
  for spine in ax.spines.values():spine.set_visible(False)
  if j==0:
   # Same 100-source-pixel scale as in the uploaded document (420-pixel ROI).
   sx=a.shape[1]/420;sy=a.shape[0]/320
   line,=ax.plot(np.array([16,116])*sx,[304*sy]*2,color='white',lw=1.6,solid_capstyle='butt')
   line.set_path_effects([patheffects.Stroke(linewidth=2.5,foreground='black'),patheffects.Normal()])
   ax.text(66*sx,286*sy,'100 px',fontproperties=fp(8.5),ha='center',va='bottom',color='black',bbox={'fc':'white','ec':'none','pad':.5})
legend=[Patch(fc=COLORS[2],ec='none',label='Newly emerged'),Patch(fc=COLORS[3],ec='none',label='Elongating'),Patch(fc=COLORS[1],ec='none',label='Persistent'),Patch(fc='white',ec='#888888',label='T1 baseline'),Patch(fc='#A7A7A7',ec='none',label='Ignored reference')]
fig.legend(handles=legend,loc='center',bbox_to_anchor=(.52,1-638/H),ncol=5,frameon=False,prop=fp(8.5),handlelength=1.05,columnspacing=1.3)
stem='V66_V90_refined_layout_colors_font_preserved'
for ext in ['png','pdf']:fig.savefig(ROOT/(stem+'.'+ext),dpi=600,facecolor='white')
fig.savefig(ROOT/(stem+'.tiff'),dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)
Image.open(ROOT/(stem+'.png')).convert('RGB').save(ROOT/(stem+'.jpg'),'JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
with fitz.open(ROOT/(stem+'.pdf')) as d:d[0].get_pixmap(matrix=fitz.Matrix(1.6,1.6),alpha=False).save(ROOT/'preview.png')
(ROOT/'layout_manifest.json').write_text(json.dumps({'input_sha256':hashlib.sha256(args.input.read_bytes()).hexdigest(),'figure_points':[W,H],'figure_mm':[W/72*25.4,H/72*25.4],'native_font_source':'Exact TrueType subsets extracted from user PDF; original face, sizes and weights retained','plot_numeric_strings':[[s['text'] for s in g] for g in groups],'macro_text':macro_text,'palette':COLORS,'image_audit':image_audit,'changes':'Layout, alignment, spacing and color only; orphaned trailing separator after Macro Dice removed.','scientific_values':'Preserved exactly from user PDF; not replaced with archived metrics and not independently scientifically validated.','source_issue':'Uploaded elongating Dice75.51% < IoU77.5%; requires verification before publication.','raster_DPI':600},indent=2)+'\n')
print('Refined layout and palette using exact source fonts and unchanged uploaded values.')
