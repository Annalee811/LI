"""Check formatting-only changes against the exact uploaded document."""
from pathlib import Path
from collections import Counter
import json,hashlib,io
import numpy as np
from PIL import Image
import fitz
ROOT=Path(__file__).resolve().parent
meta=json.loads((ROOT/'layout_manifest.json').read_text())
source=ROOT/'uploaded_source.pdf';stem='V66_V90_refined_layout_colors_font_preserved'
assert hashlib.sha256(source.read_bytes()).hexdigest()==meta['input_sha256']
def get_styles(path):
 with fitz.open(path) as d:
  assert len(d)==1
  spans=[s for b in d[0].get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
  chars=Counter((s['font'],round(s['size'],3),ch) for s in spans for ch in s['text'] if not ch.isspace() and ch!='|')
  return chars,spans,d[0].get_fonts(),list(d[0].rect)
before,original_spans,original_fonts,_=get_styles(source)
after,out,fonts,page=get_styles(ROOT/(stem+'.pdf'))
assert before==after, 'Changed text, numeric string, typeface, point size or weight'
assert all(s['color']==0 for s in out)
for s in out:
 x0,y0,x1,y1=s['bbox'];assert x0>=0 and y0>=0 and x1<=page[2] and y1<=page[3]
assert sorted(set(s['size'] for s in out))==[8.5,9.0,9.5,10.0,10.5,12.0]
old={1:(91,118,164),2:(217,123,102),3:(101,166,154)}
colors={int(c):np.array([int(h[i:i+2],16) for i in [1,3,5]],np.uint8) for c,h in meta['palette'].items()}
with fitz.open(source) as d:
 infos=sorted(d[0].get_image_info(xrefs=True),key=lambda r:(round(r['bbox'][1],1),r['bbox'][0]))
 assert len(infos)==16
 for record,info in zip(meta['image_audit'],infos):
  a=np.array(Image.open(io.BytesIO(d.extract_image(info['xref'])['image'])).convert('RGB'))
  assert hashlib.sha256(a.tobytes()).hexdigest()==record['source_array_sha256']
  expected=a.copy()
  if record['role']!='RGB':
   for code,color in old.items():expected[np.all(a==color,2)]=colors[code]
  b=np.array(Image.open(ROOT/record['file']).convert('RGB'))
  assert np.array_equal(expected,b)
  assert hashlib.sha256(b.tobytes()).hexdigest()==record['output_array_sha256']
  if record['role']=='RGB' or record['period']=='T1':assert np.array_equal(a,b)
exports={}
for ext in ['png','jpg','tiff']:
 with Image.open(ROOT/(stem+'.'+ext)) as im:
  assert im.width==4500 and abs(im.height-round(650/72*600))<=1
  assert im.convert('RGB').getpixel((0,0))==(255,255,255)
  exports[ext]={'pixels':list(im.size),'dpi':[float(v) for v in im.info.get('dpi',(0,0))]}
report={'uploaded_source_unchanged':True,'font_source':'Native embedded TrueType subsets extracted from uploaded PDF','same_text_and_numeric_characters':True,'same_typeface_weight_and_point_size_for_each_character':True,'decorative_change':'Removed orphaned trailing vertical separator; ignored whitespace and that separator in text comparison','point_sizes':[8.5,9,9.5,10,10.5,12],'all_text_black':True,'all_text_within_page':True,'source_image_panels_verified':16,'only_existing_three_class_colors_replaced':True,'source_image_geometry_and_background_unchanged':True,'original_RGB_and_T1_images_unchanged':True,'output_page_points':page,'font_faces':sorted({r[3].split('+')[-1] for r in fonts}),'exports':exports,'scientific_metric_validation_performed':False,'scientific_issue_preserved_from_input':'Elongating Dice75.51% < IoU77.5%; verify before publication.'}
(ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
