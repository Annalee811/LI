from pathlib import Path
import csv,json
from PIL import Image
import fitz

r=Path(__file__).resolve().parent
original=json.loads((r/'source_four_metric_lines.json').read_text())
points=list(csv.DictReader((r/'plotted_point_annotations.csv').open(encoding='utf-8-sig')))
assert len(points)==36
for q in points:
 src=next(v for v in original if v['Material']==q['Material'] and v['Metric']==q['Metric'])
 actual=src['y'][int(q['Period'][1])-1];assert actual==float(q['Mean_percent'])
 assert q['Annotation']==f'{actual:.2f}' and q['Period']!='T1'
for material in ['0353','A017','Q1']:assert sum(q['Material']==material for q in points)==12
d=fitz.open(r/'Three_series_3D_marked_filled_lines.pdf');assert len(d)==1
p=d[0];assert not p.get_images()
spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for line in b['lines'] for s in line['spans'] if s['text'].strip()]
assert all(s['color']==0 and p.rect.contains(fitz.Rect(s['bbox'])) for s in spans)
assert all(s['font'] in ['TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'] for s in spans)
assert min(s['size'] for s in spans)>=9.99
images={}
for ext in ['jpg','png','tiff']:
 im=Image.open(r/f'Three_series_3D_marked_filled_lines.{ext}');assert im.size==(5669,2645)
 assert all(abs(float(d)-600)<.1 for d in im.info['dpi'])
 images[ext]={'size':im.size,'dpi':[float(v) for v in im.info['dpi']]}
report={'material_panels':3,'filled_trait_layers_per_panel':4,'real_mean_markers_and_annotations':36,'all_means_identical_to_previous_plot':True,'no_imputed_T1_or_synthetic_peak_data':True,'all_text_black_and_inside_page':True,'fonts':sorted(set(s['font'] for s in spans)),'font_size_pt':[min(s['size'] for s in spans),max(s['size'] for s in spans)],'vector_PDF':True,'figure_mm':[240,112],'raster_exports':images}
(r/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
p.get_pixmap(matrix=fitz.Matrix(2,2)).save(r/'preview.png')
