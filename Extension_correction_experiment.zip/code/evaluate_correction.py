"""Compare checkpoints on matching held-out pixels, then render only B3."""
import csv
import json
import shutil
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from data import load
from finetune import ORIGINAL, ROOT, SEEDS, atomic_json, digest, evaluate
from predict_prepared import load_model, predict

V66 = Path('/workspace/work/V66_V90_same_field_SCI_20261113/sources/V66')
REFERENCE_FIGURE = ROOT.parent/'V90_joint_ablation_V66_SCI_20261124'
ACTIVE_SEED = 20261125


def read_image(path):
    return np.asarray(Image.open(path))


def baseline_counts(pixels):
    cm = np.zeros((3,2),dtype=int)
    periods = {}
    for t, values in pixels.items():
        eligible = values['split']==2
        predicted = read_image(V66/f'{t}_classes.png').ravel()[values['pixel'][eligible]]==2
        local = np.bincount(2*values['target'][eligible]+predicted,minlength=6).reshape(3,2)
        cm+=local
        periods[t]=local.tolist()
    tn,fp = cm[[0,2]].sum(0)
    fn,tp = cm[1]
    d_new,d_existing = 2*tp/(2*tp+fn+fp),2*tn/(2*tn+fn+fp)
    return dict(raw_cm=cm.tolist(),periods=periods,macro_dice=float((d_new+d_existing)/2),
                new_dice=float(d_new),existing_dice=float(d_existing),
                new_recall=float(tp/(tp+fn)),new_precision=float(tp/(tp+fp)),
                extension_pixels=int(cm[2].sum()),extension_as_new=int(cm[2,1]),
                extension_error=float(cm[2,1]/cm[2].sum()))


def save_visualization_inputs(model, checkpoint_path):
    source = ORIGINAL/'prepared_inputs/0353-2-B3'
    figure_crops = dict(np.load(REFERENCE_FIGURE/'B3_matched_crops.npz'))
    roi = json.loads((REFERENCE_FIGURE/'Figure_data.json').read_text())['crop_xyxy']
    x0,y0,x1,y1 = roi
    out = ROOT/'B3_predictions'
    out.mkdir(exist_ok=True)
    figure_crops['crop'] = np.array(roi)
    for t,mask in predict(model,source):
        old = read_image(ORIGINAL/'predictions/0353-2-B3'/f'{t}_two_classes.png')
        assert np.array_equal(mask>0,old>0)
        Image.fromarray(mask).save(out/f'{t}_two_classes.png')
        mask[mask==255]=4
        figure_crops[f'{t}_corrected'] = mask[y0:y1,x0:x1].copy()
        original_truth = read_image(ORIGINAL/'data/reference_masks_current'/f'{t}_classes.png')
        figure_crops[f'{t}_manual_elongation'] = (original_truth[y0:y1,x0:x1]==3)
    np.savez_compressed(ROOT/'Figure_crops.npz',**figure_crops)
    atomic_json(out/'Provenance.json',dict(checkpoint_sha256=digest(checkpoint_path),
                B3_only=True, fixed_foreground=True, no_manual_labels_used_to_predict=True,
                original_RGB_crop=roi, class_codes={'1':'existing','2':'new','255':'T1 baseline'}))


def main():
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    variants = ('runs','balanced_runs','focused_runs')
    assert all((ROOT/variant/str(seed)/'complete.json').exists()
               for seed in SEEDS for variant in variants)
    _,graph,junctions,options,_,pixels,_ = load(ROOT)
    models = [('V66',None,baseline_counts(pixels))]
    selected_paths = {}
    for seed in SEEDS:
        candidates = []
        for variant in variants:
            folder = ROOT/variant/str(seed)
            result = json.loads((folder/'complete.json').read_text())
            validation = result['validation_after']
            candidates.append((validation['extension_as_new'],-validation['macro_dice'],folder/'best.pt'))
        selected_paths[seed] = min(candidates,key=lambda x:x[:2])[2]
    atomic_json(ROOT/'Validation_selection.json',
                {str(seed):dict(checkpoint=str(path.relative_to(ROOT)),sha256=digest(path))
                 for seed,path in selected_paths.items()})
    for seed in SEEDS:
        old_path = ORIGINAL/'experiments/joint_full'/str(seed)/'best.pt'
        new_path = selected_paths[seed]
        original_model = load_model(old_path)
        old = evaluate(original_model,graph,junctions,options,pixels,2)
        original = json.loads((old_path.parent/'result.json').read_text())['test']
        assert abs(old['macro_dice']-original['macro_Dice'])<1e-10
        model = load_model(new_path)
        heldout = ROOT/'runs'/str(seed)/'heldout'
        heldout.mkdir(exist_ok=True)
        new = evaluate(model,graph,junctions,options,pixels,2,heldout)
        assert new['extension_pixels']==1028 and old['extension_pixels']==1028
        transitions = {}
        for period, values in pixels.items():
            use = values['split']==2
            truth = values['target'][use]
            pixels_at = values['pixel'][use]
            original_mask = read_image(old_path.parent/'predictions'/f'{period}_two_classes.png').ravel()[pixels_at]
            replacement = read_image(heldout/f'{period}_heldout.png').ravel()[pixels_at]
            transitions[period] = {
                'extension_recovered':int(((truth==2)&(original_mask==2)&(replacement==1)).sum()),
                'extension_new_errors':int(((truth==2)&(original_mask==1)&(replacement==2)).sum()),
                'real_new_lost':int(((truth==1)&(original_mask==2)&(replacement==1)).sum()),
                'real_new_recovered':int(((truth==1)&(original_mask==1)&(replacement==2)).sum()),
            }
        net = sum(v['extension_recovered']-v['extension_new_errors'] for v in transitions.values())
        assert net==old['extension_as_new']-new['extension_as_new']
        atomic_json(heldout/'Pixel_transitions.json',transitions)
        models.extend([('Original joint',seed,old),('Extension-aware',seed,new)])
        if seed==ACTIVE_SEED:
            shutil.copy2(new_path, ROOT/'Best_continuation_model.pt')
            save_visualization_inputs(model, new_path)
    records = [dict(configuration=name, seed=seed, **record) for name,seed,record in models]
    atomic_json(ROOT/'Heldout_results.json',records)
    with (ROOT/'Heldout_metrics.csv').open('w',newline='',encoding='utf-8-sig') as file:
        keys = [key for key in records[0] if key not in ('raw_cm','periods')]
        writer = csv.DictWriter(file,fieldnames=keys,extrasaction='ignore')
        writer.writeheader()
        writer.writerows(records)
    for record in records:
        print({key:value for key,value in record.items() if key not in ('raw_cm','periods')},flush=True)


if __name__=='__main__':
    main()
