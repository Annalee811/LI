"""Learned continuation evidence for a two-class U-Net temporal refinement."""
import torch
from torch import nn
from model import JointRootNet


class ContinuationRootNet(JointRootNet):
    def __init__(self):
        super().__init__('joint_full')
        self.new_logit_bias = 0.
        self.focus_prior_extension = False
        self.continuation = nn.Sequential(
            nn.Linear(64 * 2 + 15 + 2, 48), nn.LayerNorm(48), nn.ELU(), nn.Linear(48, 2)
        )
        nn.init.zeros_(self.continuation[-1].weight)
        nn.init.zeros_(self.continuation[-1].bias)

    def forward(self, graph, junctions, options):
        result = super().forward(graph, junctions, options)
        first, second = graph['pairs'].T
        phase = graph['phase']
        cross = phase[first] != phase[second]
        source = torch.where(phase[first] < phase[second], first, second)[cross]
        dest = torch.where(phase[first] < phase[second], second, first)[cross]
        delta = (phase[dest] - phase[source]).float()
        evidence = result['link_logits'][cross].sigmoid() * delta.reciprocal()
        features = result['h_axis']
        weight = features.new_zeros(len(features)).index_add_(0, dest, evidence)
        max_link = features.new_zeros(len(features)).scatter_reduce(0, dest, evidence, reduce='amax')
        prior = features.new_zeros(features.shape).index_add_(0, dest, evidence[:, None] * features[source])
        prior = prior / weight.clamp_min(.01)[:, None]
        # Transfer continuation evidence to neighboring nodes on a candidate axis.
        # The model weights each edge with its learned identity score.
        same = ~cross
        source = torch.cat([first[same], second[same]])
        dest = torch.cat([second[same], first[same]])
        affinity = result['link_logits'][same].sigmoid().square().repeat(2)
        support = max_link > 0
        affinity = affinity * support[source]
        weighted_context = features.new_zeros(features.shape).index_add_(0, dest, affinity[:, None] * prior[source])
        neighbor_weight = features.new_zeros(len(features)).index_add_(0, dest, affinity)
        context = (prior + weighted_context) / (support.float() + neighbor_weight).clamp_min(1)[:, None]
        result['continuation_context'] = context
        result['continuation_evidence'] = torch.stack([max_link, neighbor_weight.log1p()], dim=-1)
        return result

    def predict_logits(self, result, node, pixel_features):
        evidence = torch.cat([result['h'][node], result['continuation_context'][node],
                              pixel_features, result['continuation_evidence'][node]], dim=-1)
        residual, tip_logit = self.continuation(evidence).unbind(dim=-1)
        if self.focus_prior_extension:
            extension_prior = pixel_features[:, :3].softmax(-1)[:, 2]
            residual = extension_prior * residual
        original = super().pixel_logits(result, node, pixel_features)
        # The second auxiliary logit discriminates elongating from persistent
        # tissue among existing roots. The final public mask still has two classes.
        return original + torch.stack([residual, -residual], dim=-1), tip_logit

    def pixel_logits(self, result, node, pixel_features):
        logits = self.predict_logits(result, node, pixel_features)[0]
        return logits + logits.new_tensor([0., -self.new_logit_bias])
