"""Publication-style comparison of the B3 correction with the original predictions."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch
from matplotlib.patches import Circle
import numpy as np
from scipy.ndimage import uniform_filter

ROOT = Path(__file__).resolve().parents[1]
COLORS = {1:'#548FCA',2:'#EDAF4D',4:'#E1E4E6'}


def blend(rgb, labels):
    out = rgb.copy()
    for label, hexcolor in COLORS.items():
        color = np.array([int(hexcolor[i:i+2],16) for i in (1,3,5)])
        selected = labels==label
        out[selected] = np.rint(.94*color + .06*rgb[selected]).astype(np.uint8)
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--fonts',type=Path,
                        default=Path('/workspace/work/root_workflow_real_assets_20261109/fonts'))
    args=parser.parse_args()
    if args.fonts.is_dir():
        for path in args.fonts.glob('*.ttf'):
            font_manager.fontManager.addfont(str(path))
    font_manager.findfont(font_manager.FontProperties(family='Times New Roman'),fallback_to_default=False)
    plt.rcParams.update({'font.family':'Times New Roman','font.size':8,'text.color':'black',
                         'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,
                         'axes.spines.right':False,'axes.spines.left':False})
    width,height=190,122
    fig=plt.figure(figsize=(width/25.4,height/25.4),facecolor='white')
    records=json.loads((ROOT/'Heldout_results.json').read_text())
    crops=np.load(ROOT/'Figure_crops.npz')

    def text(x,y,string,size=8,bold=False,ha='left'):
        fig.text(x/width,y/height,string,ha=ha,va='center',fontsize=size,
                 fontweight='bold' if bold else 'normal')

    def axis(x,y,w,h):
        return fig.add_axes((x/width,y/height,w/width,h/height))

    text(3,116,'A',12,True)
    text(10,116,'Elongating pixels predicted as new',9,True)
    text(98,116,'B',12,True)
    text(105,116,'New-root performance',9,True)
    left=axis(33,89,50,20)
    right=axis(112,89,70,20)
    configs=['V66','Original joint','Extension-aware']
    colors=['#7C8490','#8A647B','#256879']
    for index,(name,color) in enumerate(zip(configs,colors)):
        group=[r for r in records if r['configuration']==name]
        values=np.array([r['extension_error']*100 for r in group])
        left.barh(index,values.mean(),height=.45,color=color)
        if len(values)>1:
            left.errorbar(values.mean(),index,xerr=values.std(ddof=1),fmt='none',color='black',capsize=1.7,lw=.6)
        left.text(values.mean()+3,index,f'{values.mean():.1f}',va='center',fontsize=7.1)
        for xx,(metric,label) in enumerate([('new_precision','Precision'),('new_recall','Recall'),('new_dice','Dice')]):
            y=np.array([100*r[metric] for r in group])
            right.errorbar(xx+(index-1)*.20,y.mean(),yerr=y.std(ddof=1) if len(y)>1 else None,
                           fmt=['o','s','D'][index],color=color,ms=3.8,capsize=2.1,lw=.8)
    left.set(xlim=(0,112),ylim=(2.6,-.6),xlabel='Share of true extension (%)')
    left.set_yticks(range(3),configs)
    left.set_xticks([0,25,50,75,100])
    right.set(xlim=(-.48,2.48),ylim=(70,100),ylabel='Score (%)')
    right.set_xticks(range(3),['Precision','Recall','Dice'])
    for ax in (left,right):
        ax.tick_params(axis='both',labelsize=7.0,length=2.5)
        ax.set_axisbelow(True)
    left.tick_params(axis='y',length=0)
    left.grid(axis='x',color='#E3E8EB',lw=.45)
    right.grid(axis='y',color='#E3E8EB',lw=.45)
    text(3,78,'B3 held-out root pixels. Whiskers indicate sample SD across three optimization seeds.',7.2)
    text(3,74.8,'Rings highlight selected manual elongation pixels restored to Existing in the RGB example.',7.0)
    text(3,71,'C',12,True)
    text(10,71,'Same B3 field across T1–T4',9,True)
    handles=[Patch(facecolor=COLORS[k],label=label) for k,label in [(1,'Existing'),(2,'New'),(4,'T1 baseline')]]
    fig.legend(handles=handles,loc='center right',bbox_to_anchor=(187/width,71/height),frameon=False,
               ncol=3,handletextpad=.45,handlelength=1,columnspacing=1,prop={'size':7.5,'weight':'bold'})
    names=['RGB','Human annotation','V66 U-Net','Original joint','Extension-aware']
    keys=['rgb','reference','v66','joint','corrected']
    left_x=9.5
    tile_w=35
    # Same fixed coordinates as the prior figure, with a tighter layout.
    tile_h=tile_w*260/660
    for column,name in enumerate(names):
        text(left_x+column*36+tile_w/2,65.8,name,7.6,True,'center')
    for row,t in enumerate(['T1','T2','T3','T4']):
        bottom=62.5-(row+1)*tile_h-row*.95
        text(3,bottom+tile_h/2,t,8.1,True)
        rgb=crops[f'{t}_rgb']
        restored=(crops[f'{t}_manual_elongation'] & (crops[f'{t}_joint']==2)
                  & (crops[f'{t}_corrected']==1))[30:290]
        signal=uniform_filter(restored.astype(np.float32),size=38)
        signal[:24]=0
        signal[-24:]=0
        signal[:,:24]=0
        signal[:,-24:]=0
        point=None
        if signal.max()>0:
            y,x=np.unravel_index(signal.argmax(),signal.shape)
            point=(x,y)
        for column,key in enumerate(keys):
            pane=axis(left_x+column*36,bottom,tile_w,tile_h)
            display=rgb if key=='rgb' else blend(rgb,crops[f'{t}_{key}'])
            pane.imshow(display[30:290],aspect='auto', interpolation='nearest')
            pane.axis('off')
            if point is not None and key in ('reference','joint','corrected'):
                pane.add_patch(Circle(point,24,fill=False,edgecolor='black',linewidth=1.75))
                pane.add_patch(Circle(point,24,fill=False,edgecolor='white',linewidth=.75))
            if row==0 and column==0:
                pane.plot([17,117],[241,241],color='white',lw=1.6,solid_capstyle='butt')
                pane.text(17,229,'100 px',fontsize=6.2,bbox=dict(fc='white',ec='none',pad=.35))
    for extension in ['jpg','pdf','tif']:
        extra = {'pil_kwargs':{'quality':98,'subsampling':0}} if extension=='jpg' else {}
        if extension=='tif':
            extra={'pil_kwargs':{'compression':'tiff_lzw'}}
        fig.savefig(ROOT/f'Extension_correction_B3.{extension}',dpi=600,facecolor='white',**extra)
    fig.savefig(ROOT/'Preview.png',dpi=205,facecolor='white')
    plt.close(fig)


if __name__=='__main__':
    main()
