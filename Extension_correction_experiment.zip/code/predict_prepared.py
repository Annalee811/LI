"""Predict the two classes on one existing RGB-derived graph."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from continuation import ContinuationRootNet


def load_model(path):
    checkpoint = torch.load(path, weights_only=True, map_location='cpu')
    model = ContinuationRootNet()
    if 'continuation.0.weight' in checkpoint['model']:
        model.load_state_dict(checkpoint['model'])
    else:
        missing, unexpected = model.load_state_dict(checkpoint['model'], strict=False)
        assert not unexpected and all(key.startswith('continuation.') for key in missing)
    model.new_logit_bias = checkpoint.get('bias', 0.)
    model.focus_prior_extension = checkpoint['config'].get('focus_prior_extension', False)
    return model.eval()


@torch.inference_mode()
def predict(model, source):
    metadata = json.loads((source/'complete.json').read_text())
    graph = {key: torch.from_numpy(value) for key,value in np.load(source/'graph_inputs.npz').items()}
    graph.update(part=torch.zeros(len(graph['x']),dtype=torch.int64),
                 partition_frame_masks=torch.ones((1,*graph['frames'].shape[-2:])),
                 native_width=metadata['native_width'],native_height=metadata['native_height'])
    with np.load(source/'junction_inputs.npz') as data:
        junctions = {key: torch.from_numpy(data[key]) for key in ('nodes','ptr','a','b','fixed')}
        options = {key: torch.from_numpy(data[key]) for key in ('index','mask')}
    result = model(graph,junctions,options)
    for step, period in enumerate(metadata['periods']):
        with np.load(source/f'{period}_pixels.npz') as data:
            pixels,nodes,features = data['pixel'],data['node'],data['pf']
            mask = np.zeros(tuple(data['shape']),dtype=np.uint8)
            if step == 0:
                mask.ravel()[pixels] = 255
            else:
                for start in range(0,len(pixels),32768):
                    subset = slice(start,start+32768)
                    logits = model.pixel_logits(result,torch.from_numpy(nodes[subset]),
                                                 torch.from_numpy(features[subset]))
                    mask.ravel()[pixels[subset]] = logits.argmax(1).numpy()+1
        yield period,mask


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint',type=Path,required=True)
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    model = load_model(args.checkpoint)
    args.output.mkdir(parents=True,exist_ok=False)
    periods = []
    for period,mask in predict(model,args.input):
        Image.fromarray(mask).save(args.output/f'{period}_two_classes.png')
        periods.append(period)
    (args.output/'metadata.json').write_text(json.dumps({
        'checkpoint_sha256':hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
        'periods':periods, 'classes':{'0':'background','1':'existing','2':'new','255':'baseline'}
    },indent=2))


if __name__=='__main__':
    main()
