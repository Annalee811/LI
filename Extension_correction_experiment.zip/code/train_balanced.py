"""Train with matched penalties for continuation and novelty and calibrate on validation."""
import argparse
import csv
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F
from continuation import ContinuationRootNet
from data import load
from finetune import ORIGINAL, ROOT, SEEDS, atomic_json, atomic_save, digest, evaluate
from losses import compute

UPDATES = 30
BIASES = (-.18,-.12,-.06,0.,.06,.12,.18)


@torch.inference_mode()
def validation_candidates(model, graph, junctions, options, pixels):
    result = model(graph,junctions,options)
    margin, truth = [], []
    for values in pixels.values():
        idx = np.flatnonzero(values['split']==1)
        logits = model.pixel_logits(result,torch.from_numpy(values['node'][idx]),torch.from_numpy(values['pf'][idx]))
        margin.append((logits[:,1]-logits[:,0]).numpy())
        truth.append(values['target'][idx])
    margin, truth = np.concatenate(margin),np.concatenate(truth)
    for bias in BIASES:
        pred = margin > bias
        cm = np.bincount(2*truth+pred,minlength=6).reshape(3,2)
        tn,fp = cm[[0,2]].sum(0)
        fn,tp = cm[1]
        score = .5*(2*tn/(2*tn+fp+fn)+2*tp/(2*tp+fp+fn))
        yield bias, int(cm[2,1]),float(score),float(tp/(tp+fn))


def main(seed, focus_prior=False):
    output = ROOT/('focused_runs' if focus_prior else 'balanced_runs')/str(seed)
    output.mkdir(parents=True,exist_ok=True)
    source = ORIGINAL/'experiments/joint_full'/str(seed)/'best.pt'
    initial = torch.load(source,weights_only=True,map_location='cpu')
    _,graph,junctions,options,target,pixels,all_pixels=load(ROOT)
    model=ContinuationRootNet()
    model.focus_prior_extension=focus_prior
    model.load_state_dict(initial['model'],strict=False)
    base = evaluate(model,graph,junctions,options,pixels,1)
    truth = torch.from_numpy(np.concatenate([p['target'] for p in pixels.values()]))
    train = torch.nonzero(all_pixels['split']==0).flatten()
    groups = [train[truth[train]==class_id].numpy() for class_id in (2,0,1)]
    weights = torch.bincount(all_pixels['target'][train],minlength=2).float()
    weights = (weights.max()/weights).sqrt()
    updates = 20 if focus_prior else UPDATES
    backbone_lr, head_lr = (8e-6, 2e-3) if focus_prior else (8e-5, 8e-4)
    optimizer = torch.optim.AdamW([
        dict(params=[p for n,p in model.named_parameters() if not n.startswith('continuation.')],lr=backbone_lr),
        dict(params=model.continuation.parameters(),lr=head_lr)],weight_decay=1e-4)
    config = dict(seed=seed,updates=updates,warm_start_sha=digest(source),bias_candidates=BIASES,
                  focus_prior_extension=focus_prior, backbone_lr=backbone_lr, head_lr=head_lr,
                  tip_loss_weight=.55,new_loss_weight=.55,subtype_loss_weight=.25,
                  validation_constraints='Original validation macro Dice and new recall minus at most one percentage point')
    best = (base['extension_as_new'],-base['macro_dice'])
    atomic_save(output/'best.pt',dict(model=model.state_dict(),config=config,update=0,validation=base,bias=0.))
    history=[]
    for update in range(1,updates+1):
        model.train()
        rng = np.random.default_rng(seed+1733*update)
        optimizer.zero_grad(set_to_none=True)
        result = model(graph,junctions,options)
        subset = torch.from_numpy(rng.choice(train.numpy(),8192,replace=False))
        original_loss,_=compute(model,result,graph,junctions,options,target,all_pixels,subset,weights)
        selected=torch.from_numpy(np.concatenate([rng.choice(g,1024,replace=False) for g in groups]))
        scores,subtypes=model.predict_logits(result,all_pixels['node'][selected],all_pixels['pf'][selected])
        labels=all_pixels['target'][selected]
        tip_loss=F.cross_entropy(scores[:1024],labels[:1024])
        new_loss=F.cross_entropy(scores[2048:],labels[2048:])
        subtype_loss=F.binary_cross_entropy_with_logits(subtypes[:2048],(truth[selected[:2048]]==2).float())
        loss=original_loss+.55*tip_loss+.55*new_loss+.25*subtype_loss
        assert torch.isfinite(loss)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True)
        optimizer.step()
        model.eval()
        minimum = None
        for bias,errors,macro,recall in validation_candidates(model,graph,junctions,options,pixels):
            allowed=macro>=base['macro_dice']-.01 and recall>=base['new_recall']-.01
            key = (errors,-macro)
            if allowed and (minimum is None or key < minimum):
                minimum=key
            if allowed and key<best:
                best=key
                atomic_save(output/'best.pt',dict(model=model.state_dict(),config=config,update=update,bias=bias,
                             validation=dict(extension_as_new=errors,macro_dice=macro,new_recall=recall)))
            history.append(dict(update=update,bias=bias,validation_extension_as_new=errors,
                                validation_macro_dice=macro,validation_new_recall=recall,admissible=allowed,loss=float(loss.detach())))
        with (output/'history.csv').open('w',newline='') as file:
            writer=csv.DictWriter(file,fieldnames=list(history[0]));writer.writeheader();writer.writerows(history)
        atomic_save(output/'latest.pt',dict(model=model.state_dict(), optimizer=optimizer.state_dict(),update=update,config=config))
        if update==1 or update%6==0:
            print(seed,update,'admissible extension errors',None if minimum is None else minimum[0],
                  'best',best[0],flush=True)
    selected=torch.load(output/'best.pt',weights_only=True,map_location='cpu')
    atomic_json(output/'complete.json',dict(seed=seed,best_update=selected['update'],bias=selected['bias'],
                                           validation_before=base,validation_after=selected['validation']))


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--seed',type=int,choices=SEEDS,required=True)
    ap.add_argument('--focus-prior',action='store_true')
    args=ap.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(args.seed)
    main(args.seed,focus_prior=args.focus_prior)
