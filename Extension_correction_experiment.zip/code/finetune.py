"""Continue training with explicit manual-tip supervision. Select on validation alone."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F
from PIL import Image
from data import load
from losses import compute
from continuation import ContinuationRootNet

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL = ROOT.parent / 'V90_joint_learned_structure_20261124'
SEEDS = (20261124, 20261125, 20261126)
UPDATES = 36


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atomic_json(path, content):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(content, indent=2, allow_nan=False))
    tmp.replace(path)


def atomic_save(path, content):
    tmp = path.with_suffix('.tmp')
    torch.save(content, tmp)
    tmp.replace(path)


def evaluate(model, graph, junctions, options, pixels, split, output=None):
    raw_cm = np.zeros((3,2), dtype=np.int64)
    periods = {}
    model.eval()
    with torch.inference_mode():
        result = model(graph, junctions, options)
        for t, values in pixels.items():
            indices = np.flatnonzero(values['split'] == split)
            predictions = []
            for start in range(0, len(indices), 32768):
                idx = indices[start:start+32768]
                pred = model.pixel_logits(result, torch.from_numpy(values['node'][idx]),
                                          torch.from_numpy(values['pf'][idx])).argmax(1)
                predictions.append(pred.numpy())
            prediction = np.concatenate(predictions)
            counts = np.bincount(2*values['target'][indices] + prediction, minlength=6).reshape(3,2)
            raw_cm += counts
            periods[t] = counts.tolist()
            if output:
                mask = np.zeros((1108,2541), dtype=np.uint8)
                mask.ravel()[values['pixel'][indices]] = prediction+1
                Image.fromarray(mask).save(output/f'{t}_heldout.png')
    tn, fp = raw_cm[[0,2]].sum(0)
    fn, tp = raw_cm[1]
    dice_new = 2*tp / (2*tp + fp + fn)
    dice_existing = 2*tn / (2*tn + fp + fn)
    return dict(raw_cm=raw_cm.tolist(), periods=periods, macro_dice=float((dice_new+dice_existing)/2),
                new_dice=float(dice_new), existing_dice=float(dice_existing),
                new_recall=float(tp/(tp+fn)), new_precision=float(tp/(tp+fp)) if tp+fp else 0.,
                extension_pixels=int(raw_cm[2].sum()), extension_as_new=int(raw_cm[2,1]),
                extension_error=float(raw_cm[2,1]/raw_cm[2].sum()))


def train(seed, smoke=False):
    original_path = ORIGINAL/'experiments/joint_full'/str(seed)/'best.pt'
    out = ROOT/('smoke' if smoke else 'runs')/str(seed)
    out.mkdir(parents=True, exist_ok=True)
    _, graph, junctions, options, target, pixels, all_pixels = load(ROOT)
    model = ContinuationRootNet()
    checkpoint = torch.load(original_path, weights_only=True, map_location='cpu')
    missing, unexpected = model.load_state_dict(checkpoint['model'], strict=False)
    assert missing and not unexpected and all(name.startswith('continuation.') for name in missing)
    original_class = torch.from_numpy(np.concatenate([p['target'] for p in pixels.values()]))
    training = torch.nonzero(all_pixels['split']==0).flatten()
    tip_indices = training[original_class[training]==2].numpy()
    persistent = training[original_class[training]==0].numpy()
    new = training[original_class[training]==1].numpy()
    config = dict(seed=seed, updates=2 if smoke else UPDATES, checkpoint_sha=digest(original_path),
                  tip_loss_weight=.65, subtype_loss_weight=.18, new_companion_weight=.50,
                  main_samples=8192, samples_per_added_group=1024,
                  validation_selection='Minimize extension-as-new among checkpoints retaining baseline macro Dice and new recall within one percentage point',
                  target_classes=['existing','new'], upstream_frozen=True)
    atomic_json(out/'protocol.json',config)
    weights = torch.bincount(all_pixels['target'][training], minlength=2).float()
    weights = (weights.max()/weights).sqrt()
    head_parameters = set(model.continuation.parameters())
    optimizer = torch.optim.AdamW([
        dict(params=[p for p in model.parameters() if p not in head_parameters], lr=8e-5),
        dict(params=model.continuation.parameters(), lr=8e-4),
    ], weight_decay=1e-4)
    base = evaluate(model,graph,junctions,options,pixels,1)
    expected = json.loads((original_path.parent/'result.json').read_text())['validation']['macro_Dice']
    assert abs(base['macro_dice']-expected)<1e-10, (base,expected)
    print(seed,'BASE_VALIDATION',base['extension_as_new'],base['extension_pixels'],base['macro_dice'],flush=True)
    initial = dict(model=model.state_dict(),config=config,update=0,validation=base)
    best_key = (base['extension_as_new'],-base['macro_dice'])
    atomic_save(out/'best.pt',initial)
    history = []
    for update in range(1,config['updates']+1):
        rng = np.random.default_rng(seed+1733*update)
        model.train()
        optimizer.zero_grad(set_to_none=True)
        result = model(graph,junctions,options)
        subset = rng.choice(training.numpy(),8192,replace=False)
        base_loss, _ = compute(model,result,graph,junctions,options,target,all_pixels,
                               torch.from_numpy(subset),weights)
        extra = [rng.choice(group,1024,replace=False) for group in [tip_indices,persistent,new]]
        indices = torch.from_numpy(np.concatenate(extra))
        logits, subtype_logit = model.predict_logits(result,all_pixels['node'][indices],all_pixels['pf'][indices])
        continuation_loss = F.cross_entropy(logits[:1024],all_pixels['target'][indices[:1024]])
        new_loss = F.cross_entropy(logits[2048:],all_pixels['target'][indices[2048:]])
        subtype_loss = F.binary_cross_entropy_with_logits(subtype_logit[:2048],
                                                          (original_class[indices[:2048]]==2).float())
        total = base_loss + .65*(continuation_loss+.50*new_loss) + .18*subtype_loss
        assert torch.isfinite(total)
        total.backward()
        if update==1:
            assert float(model.continuation[-1].weight.grad.abs().sum())>0
            assert float(model.axis_value[0].weight.grad.abs().sum())>0
            assert float(model.junction_value[0].weight.grad.abs().sum())>0
        torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True)
        optimizer.step()
        evaluation = evaluate(model,graph,junctions,options,pixels,1)
        row = dict(update=update, loss=float(total.detach()),
                   tip_loss=float(continuation_loss.detach()), new_loss=float(new_loss.detach()),
                   validation_macro_dice=evaluation['macro_dice'],
                   validation_new_recall=evaluation['new_recall'],
                   validation_extension_as_new=evaluation['extension_as_new'])
        history.append(row)
        admissible = (evaluation['macro_dice']>=base['macro_dice']-.01
                      and evaluation['new_recall']>=base['new_recall']-.01)
        key = (evaluation['extension_as_new'],-evaluation['macro_dice'])
        if admissible and key<best_key:
            best_key=key
            atomic_save(out/'best.pt',dict(model=model.state_dict(),config=config,update=update,validation=evaluation))
        with (out/'history.csv').open('w', newline='') as file:
            writer = csv.DictWriter(file,fieldnames=list(row))
            writer.writeheader()
            writer.writerows(history)
        atomic_save(out/'latest.pt',dict(model=model.state_dict(),optimizer=optimizer.state_dict(),update=update,config=config))
        if update==1 or update%6==0:
            print(seed,update,'validation extension errors',evaluation['extension_as_new'],
                  'macro Dice',round(evaluation['macro_dice'],4),'new recall',round(evaluation['new_recall'],4),
                  'eligible',admissible,flush=True)
    chosen = torch.load(out/'best.pt', weights_only=True, map_location='cpu')
    model.load_state_dict(chosen['model'])
    atomic_json(out/'complete.json',dict(seed=seed,best_update=chosen['update'],validation_before=base,
                                        validation_after=chosen['validation'],updates=config['updates']))
    print(seed,'COMPLETE',chosen['update'],chosen['validation']['extension_as_new'],flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--seed',type=int,choices=SEEDS,required=True)
    parser.add_argument('--smoke',action='store_true')
    args=parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(args.seed)
    train(args.seed,args.smoke)
