Extension-aware temporal root refinement

The intended endpoint is two root classes. Existing roots include both persistent segments and the elongation of the same root axis. A newly appearing independent axis is a new root. The foreground comes from the frozen U-Net and its V66 temporal priors. ConvLSTM, gated GAT, learned Axis refinement and learned Junction matching remain in the differentiable network.

The added continuation head uses earlier-node features gathered using predicted identity links, current Axis/Junction features, and the original pixel priors. Manual root identities do not enter the inference path. Training uses the original three manual labels to supervise elongation as a distinct subtype within Existing and to penalize elongation predicted as New. A separate New loss protects the true-new class. The published prediction mask contains two temporal classes.

Three warm-start training schedules were evaluated on validation: an elongation-weighted loss, a balanced elongation/new loss, and a balanced loss with the correction residual scaled by the frozen V66 elongation prior. The two balanced schedules also examine fixed candidate offsets to the new-class logit on validation. Checkpoint selection minimizes the count of elongation pixels classified as new while allowing at most a 1 percentage point validation decrease in macro Dice and new-root recall from the paired starting model. Macro Dice breaks ties. The RGB comparison kept the original deployment seed 20261125. Use Validation_selection.json for checkpoint provenance.

The held-out internal B3 metrics use exactly the 83,478 shared typed-root pixels. The three rows of raw_cm are manual Persistent, New, Extension. The two columns are predicted Existing and New. Auxiliary extension-specific statistics use 1,028 held-out extension pixels, with 121 validation pixels for checkpoint selection. Pixel-transition records count corrections and newly induced errors. Outer data lack manual labels for independent validation. This targeted correction reuses the same B3 development and internal split, where the failure was first observed.

B3_predictions contains selected checkpoint predictions using the whole registered B3 field. The same archived local field was cropped across dates for the illustration. The quantitative internal masks are in a different inference context, with partition separation. Extending and persistent pixels are shown in blue under the two-class scheme. Gold denotes new roots, and light gray denotes T1 baseline. The trial addresses class errors. Instance association remains a separate question.

To read a prepared graph into the model, run:
python code/predict_prepared.py --checkpoint Best_continuation_model.pt --input PATH_TO_PREPARED_POSITION --output NEW_OUTPUT_DIRECTORY

The graph contract is graph_inputs.npz, junction_inputs.npz, complete.json and period-specific *_pixels.npz from the prior workflow. This package supplies the model and the inference entry point for an already prepared graph.

The source B3 input and starting model can be obtained from the earlier study release:
https://github.com/Annalee811/LI/tree/9e5c7fb8cd3902bb45df165361fd1e74eb38c5b0

Fine-tuning requires PyTorch, NumPy and Pillow, the B3_training_inputs.zip data folder and the original joint experiments at the documented neighboring path. Run finetune.py and train_balanced.py once per seed. train_balanced.py --focus-prior enables the prior-scaled residual. Code evaluate_correction.py additionally uses the archived aligned RGB masks and B3 prepared graph to reproduce local figure assets. The supplied quantitative CSV, JSON and figure crop cache are reproducible inputs to draw_diagnostic.py with Matplotlib and Times New Roman.
