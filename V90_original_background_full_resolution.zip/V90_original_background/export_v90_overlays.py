"""Export exact archived V90 temporal classes on the corresponding full RGB field."""
from pathlib import Path
import argparse,json,hashlib,shutil,sys
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch
import fitz

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source-dir',type=Path,default=ROOT/'sources')
p.add_argument('--verification',type=Path,default=ROOT/'source_verification.json')
p.add_argument('--fonts-dir',type=Path,required=True)
args=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(args.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':9,'text.color':'black','pdf.fonttype':42,'axes.labelcolor':'black'})
expected=json.loads(args.verification.read_text())
lookup={r['file']:r for r in expected['checks']}
PALETTE={1:(82,151,195),2:(245,204,60),3:(105,173,82),4:(255,255,255),255:(180,180,180)}
NAMES={0:'Background',1:'Persistent',2:'Newly emerged',3:'Elongating',4:'T1 baseline',255:'Uncertain / ignored'}
(ROOT/'sources/RGB').mkdir(parents=True,exist_ok=True)
(ROOT/'sources/V90').mkdir(parents=True,exist_ok=True)
(ROOT/'PNG').mkdir(exist_ok=True);(ROOT/'JPG').mkdir(exist_ok=True)
records=[]
for t in ['T1','T2','T3','T4']:
 paths={'RGB':args.source_dir/f'RGB/{t}_RGB.png','V90':args.source_dir/f'V90/{t}_classes.png'}
 checks={}
 for group,src in paths.items():
  rel=f'sources/{group}/'+src.name
  actual=hashlib.sha256(src.read_bytes()).hexdigest()
  assert actual==lookup[rel]['sha256'],f'Source hash mismatch: {src}'
  dest=ROOT/rel
  if src.resolve()!=dest.resolve():shutil.copy2(src,dest)
  checks[group]={'file':rel,'sha256':actual,'archive_asset':lookup[rel]['archive_asset'],'stage':lookup[rel]['stage']}
 rgb=np.array(Image.open(paths['RGB']).convert('RGB'))
 labels=np.array(Image.open(paths['V90']))
 assert rgb.shape==(1108,2541,3) and labels.shape==rgb.shape[:2]
 assert set(np.unique(labels)).issubset({0,1,2,3,4,255})
 overlay=rgb.copy()
 for code,color in PALETTE.items():overlay[labels==code]=color
 # No blending, dilation, skeleton manipulation, geometry changes or new labels.
 assert np.array_equal(overlay[labels==0],rgb[labels==0])
 name=f'0353-2-B3_{t}_V90_temporal_on_original_RGB'
 Image.fromarray(overlay).save(ROOT/'PNG'/(name+'.png'),dpi=(300,300))
 Image.fromarray(overlay).save(ROOT/'JPG'/(name+'.jpg'),quality=98,subsampling=0,optimize=True,dpi=(300,300))
 reread=np.array(Image.open(ROOT/'PNG'/(name+'.png')))
 assert np.array_equal(reread,overlay)
 records.append({'period':t,'image_pixels':[2541,1108],'source_checks':checks,'class_pixel_counts':{str(c):int((labels==c).sum()) for c in np.unique(labels)},'class_names':{str(c):NAMES[int(c)] for c in np.unique(labels)},'background_pixels_exact_in_PNG':True,'output_png':'PNG/'+name+'.png','output_jpg':'JPG/'+name+'.jpg','array_sha256':hashlib.sha256(overlay.tobytes()).hexdigest()})

# Compact full-field overview, not a local crop. Text stays vector in PDF.
W,H=190.5,108
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
fig.text(.5,1-5/H,'V90 temporal labels on original RGB — 0353-2-B3',ha='center',va='center',fontsize=12,fontweight='bold',color='black')
pw=91;ph=pw*1108/2541
for i,r in enumerate(records):
 col=i%2;row=i//2;left=3+col*94.5;top=15+row*46
 title=['T1 · Baseline','T2 · T1 → T2','T3 · T2 → T3','T4 · T3 → T4'][i]
 fig.text((left+pw/2)/W,1-(top-3.4)/H,title,ha='center',va='center',fontsize=10,fontweight='bold',color='black')
 ax=fig.add_axes([left/W,1-(top+ph)/H,pw/W,ph/H])
 ax.imshow(Image.open(ROOT/r['output_png']),interpolation='nearest');ax.set_axis_off()
legend=[Patch(facecolor=np.array(PALETTE[c])/255,edgecolor='#777777' if c==4 else 'none',label=NAMES[c]) for c in [4,2,3,1]]
fig.legend(handles=legend,loc='center',bbox_to_anchor=(.5,1-103.5/H),ncol=4,frameon=False,fontsize=9,handlelength=1.25,columnspacing=1.8)
stem='V90_T1-T4_fullfield_original_RGB_overview'
for ext in ['png','pdf']:fig.savefig(ROOT/(stem+'.'+ext),dpi=600,facecolor='white')
plt.close(fig)
Image.open(ROOT/(stem+'.png')).convert('RGB').save(ROOT/(stem+'.jpg'),'JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
manifest={'position_id':'0353-2-B3','source_commit':expected['source_commit'],'archived_field_pixels':[2541,1108],'source_scope':'Complete archived registered RGB/V90 field; no local crop; not a claim of unregistered full-camera sensor extent.','class_colors_RGB':{str(c):color for c,color in PALETTE.items()},'class_names':{str(c):n for c,n in NAMES.items()},'label_definition':'Original V90 final learned/structural/reviewed class labels; T1=baseline. Colors are classes, not unique biological instance IDs.','overlay_rule':'Replace existing labelled foreground pixels only; preserve every source RGB background pixel exactly in lossless PNG.','new_training_registration_inference_or_labels':False,'records':records,'overview_mm':[W,H]}
(ROOT/'export_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with fitz.open(ROOT/(stem+'.pdf')) as d:
 spans=[s for b in d[0].get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
 assert all(s['color']==0 for s in spans)
 fonts={f[3].split('+')[-1] for f in d[0].get_fonts()}
 assert fonts=={'TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'}
 d[0].get_pixmap(matrix=fitz.Matrix(1.8,1.8),alpha=False).save(ROOT/'preview.png')
(ROOT/'verification.json').write_text(json.dumps({'source_files_sha256_verified':8,'periods':4,'full_field_no_local_crop':True,'PNG_background_exact':True,'PNG_foreground_matches_original_label_palette':True,'original_class_arrays_unchanged':True,'new_training_or_inference':False,'overview_font_names':sorted(fonts),'overview_text_black':True,'overview_text_pt':[min(s['size'] for s in spans),max(s['size'] for s in spans)]},indent=2)+'\n')
print('Exported four full-field V90 overlays with exact background pixels and verified source labels.')
