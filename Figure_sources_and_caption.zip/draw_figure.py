"""Render a publication figure using the archived numerical and image data."""
import argparse
import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parent
W, H = 190, 161
INK = '#25323A'
JOINT = '#255B6C'
V66 = '#7C8490'
GRID = '#E3E8EB'
NEW = '#EDAF4D'
EXISTING = '#548FCA'
BASELINE = '#E1E4E6'


def load_fonts(font_directory):
    if font_directory.is_dir():
        for path in font_directory.glob('*.ttf'):
            font_manager.fontManager.addfont(str(path))
    font_manager.findfont(font_manager.FontProperties(family='Times New Roman'),
                          fallback_to_default=False)


def overlay(rgb, mask):
    image = rgb.copy()
    for code, color in [(1, EXISTING), (2, NEW), (4, BASELINE)]:
        pixels = mask == code
        color = np.array([int(color[i:i+2], 16) for i in (1, 3, 5)])
        image[pixels] = np.rint(.94*color + .06*rgb[pixels]).astype(np.uint8)
    unmarked = np.isin(mask, [0, 255])
    assert np.array_equal(image[unmarked], rgb[unmarked])
    return image


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--fonts', type=Path, default=Path('/workspace/work/root_workflow_real_assets_20261109/fonts'))
    args = parser.parse_args()
    load_fonts(args.fonts)
    plt.rcParams.update({
        'font.family':'Times New Roman', 'font.size':8, 'text.color':'black',
        'axes.labelcolor':'black', 'xtick.color':'black', 'ytick.color':'black',
        'axes.edgecolor':INK, 'axes.linewidth':.65, 'axes.spines.top':False,
        'axes.spines.right':False, 'axes.spines.left':False,
        'pdf.fonttype':42, 'svg.fonttype':'none',
    })
    metadata = json.loads((ROOT/'Figure_data.json').read_text())
    figure = plt.figure(figsize=(W/25.4,H/25.4), facecolor='white')

    def text(x, y, label, size=8, bold=False, ha='left', **kwargs):
        return figure.text(x/W, y/H, label, fontsize=size, fontweight='bold' if bold else 'normal',
                           ha=ha, va='center', **kwargs)

    def axes(x, y, width, height):
        return figure.add_axes([x/W, y/H, width/W, height/H])

    def heading(x, y, letter, title):
        text(x, y, letter, size=12.5, bold=True)
        text(x+7, y, title, size=9.1, bold=True)

    data = metadata['performance']
    # A. The historical frame-only model provides a descriptive temporal control.
    heading(3, 154, 'A', 'Temporal baselines')
    axis = axes(24, 118, 33, 29)
    entries = [('Frame only*', metadata['historical_frame_control'], '#C2CAD0'),
               ('V66 U-Net', data['v66']['macro_dice'], V66),
               ('V90 full', data['v90']['macro_dice'], JOINT)]
    for row, (label, value, color) in enumerate(entries):
        axis.barh(row, value, height=.42, color=color, zorder=3)
        axis.text(value+2.6, row, f'{value:.2f}', va='center', fontsize=7.3,
                  fontweight='bold' if label=='V90 full' else 'normal')
    axis.set(ylim=(2.55,-.55), xlim=(0,117), xticks=[0,25,50,75,100], xlabel='Macro Dice (%)')
    axis.set_yticks(range(3), [entry[0] for entry in entries])
    axis.tick_params(axis='y', length=0, labelsize=7.5, pad=3)
    axis.tick_params(axis='x', length=2.4, labelsize=7.1, pad=2.4)
    axis.xaxis.label.set_size(7.7)
    axis.grid(axis='x', color=GRID, linewidth=.45)
    axis.set_axisbelow(True)

    # B. A single bypass removes the complete V90 workflow.
    heading(61, 154, 'B', 'Workflow ablation')
    axis = axes(85, 118, 30, 27)
    for row, label, key, color in [(0,'Refinement off','v66',V66),(1,'Refinement on','v90',JOINT)]:
        value = data[key]['extension_error']
        count = metadata['extension_counts'][row]
        axis.barh(row, value, height=.36, color=color, zorder=3)
        axis.text(value+3, row, f'{value:.2f}%', va='center', fontsize=7.2)
        axis.text(2, row+.33, f'{count:,} / 1,028 pixels', fontsize=6.7, va='center')
    axis.set(ylim=(1.61,-.53), xlim=(0,115), xlabel='Extension labeled as new (%)')
    axis.set_xticks([0,25,50,75,100])
    axis.set_yticks([0,1], ['Refinement off','Refinement on'])
    axis.tick_params(axis='y', length=0, labelsize=7.3, pad=3)
    axis.tick_params(axis='x', length=2.4, labelsize=7.0, pad=2.4)
    axis.xaxis.label.set_size(7.3)
    axis.grid(axis='x', color=GRID, linewidth=.45)
    axis.set_axisbelow(True)

    heading(123, 154, 'C', 'Two-class scores')
    axis = axes(143, 118, 24, 27)
    locations = [0,1,2,3,4.38,5.38]
    text(175, 147, 'V66', size=7.1, bold=True, ha='center')
    text(185, 147, 'V90', size=7.1, bold=True, ha='center')
    metrics = [('New','Precision'),('New','Recall'),('New','Dice'),('New','IoU'),
               ('Existing','Dice'),('Existing','IoU')]
    for row, (root_class, metric) in zip(locations, metrics):
        a,b = (data[key][root_class][metric] for key in ('v66','v90'))
        is_dice = metric=='Dice'
        axis.plot([a,b], [row+.11,row-.11], color='#BAC7CC', linewidth=1.05)
        axis.plot(a, row+.11, 'o', markerfacecolor='white', markeredgecolor=V66, markersize=3.4, markeredgewidth=.85)
        axis.plot(b, row-.11, 's', color=JOINT, markersize=3.4)
        for xpos, value in [(1.17,a),(1.59,b)]:
            axis.text(xpos,row, f'{value:.2f}',transform=axis.get_yaxis_transform(),
                      ha='left',va='center',fontsize=7.0,fontweight='bold' if is_dice else 'normal')
    axis.axhline(3.67, color=GRID, lw=.65)
    axis.set(ylim=(5.9,-.6), xlim=(65,101), xticks=[70,85,100], xlabel='Score (%)')
    axis.xaxis.label.set_size(7.7)
    axis.set_yticks(locations, [root_class+' '+m.lower() if m in ('Precision','Recall') else root_class+' '+m
                               for root_class,m in metrics])
    axis.tick_params(axis='y', length=0, labelsize=7.2, pad=2)
    axis.tick_params(axis='x', length=2.4, labelsize=7.1, pad=2.4)
    axis.grid(axis='x', color=GRID, linewidth=.45)
    axis.set_axisbelow(True)

    text(3,108.0,'B3 internal evaluation on 83,478 annotated root pixels.  *Historical single-frame control.',size=7.0)
    text(3,104.7,'Refinement off: V66 U-Net.  Refinement on: V66 U-Net with the complete original V90 workflow.',size=7.0)

    heading(3, 99.6, 'D', 'Matched RGB overlays across T1–T4')
    handles = [Patch(facecolor=c, edgecolor='none', label=s) for c,s in
               [(NEW,'New'),(EXISTING,'Existing'),(BASELINE,'T1 baseline')]]
    figure.legend(handles=handles, ncol=3, loc='center right', bbox_to_anchor=(188/W,99.6/H),
                  frameon=False, prop=dict(size=7.4,weight='bold'),
                  columnspacing=1.15, handlelength=1.0, handletextpad=.45, borderaxespad=0)
    rasters = np.load(ROOT/'B3_matched_crops.npz')
    names = ['Original RGB','Human annotation','V66 U-Net','V90 full workflow']
    keys = ['rgb','reference','v66','v90']
    left, gap, tile_width, top, row_gap = 9.5, 1.24, 43.8, 91.0, .85
    tile_height = tile_width * 320/660
    for column, name in enumerate(names):
        text(left+column*(tile_width+gap)+tile_width/2, 94.1, name, size=8.3, bold=True, ha='center')
    for row, period in enumerate(['T1','T2','T3','T4']):
        bottom = top - (row+1)*tile_height - row*row_gap
        text(3, bottom+tile_height/2, period, size=8.6, bold=True)
        rgb = rasters[f'{period}_rgb']
        for column, key in enumerate(keys):
            rendered = rgb if column==0 else overlay(rgb, rasters[f'{period}_{key}'])
            tile = axes(left+column*(tile_width+gap), bottom, tile_width, tile_height)
            tile.imshow(rendered, interpolation='nearest', aspect='auto')
            tile.axis('off')
            if row==0 and column==0:
                tile.add_line(Line2D([.045,.045+100/660],[.070,.070],transform=tile.transAxes,
                                     color='white',linewidth=1.6,solid_capstyle='butt'))
                tile.text(.045,.116,'100 px',transform=tile.transAxes,fontsize=6.5,color='black',
                          va='bottom',bbox=dict(facecolor='white',edgecolor='none',pad=.45))

    figure.canvas.draw()
    renderer = figure.canvas.get_renderer()
    for item in figure.findobj(matplotlib.text.Text):
        if item.get_visible() and item.get_text():
            bounds = item.get_window_extent(renderer)
            assert bounds.x0 >= -.5 and bounds.x1 <= figure.bbox.width+.5, item.get_text()
            assert bounds.y0 >= -.5 and bounds.y1 <= figure.bbox.height+.5, item.get_text()
    stem = 'V90_workflow_ablation_SCI'
    for extension in ['jpg','tif','pdf','svg']:
        options = {'dpi':600, 'facecolor':'white'}
        if extension=='jpg':
            options['pil_kwargs'] = {'quality':98,'subsampling':0}
        if extension=='tif':
            options['pil_kwargs'] = {'compression':'tiff_lzw'}
        figure.savefig(ROOT/f'{stem}.{extension}', **options)
    figure.savefig(ROOT/'Preview.png', dpi=205, facecolor='white')
    plt.close(figure)


if __name__ == '__main__':
    main()
