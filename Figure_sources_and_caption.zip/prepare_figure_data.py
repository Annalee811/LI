"""Compile archived B3 metrics and exact matched RGB/mask crops."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image

OUT = Path(__file__).resolve().parent
STUDY = OUT.parent / 'V90_joint_learned_structure_20261124'
FIGURE_ARCHIVE = Path('/workspace/work/V66_V90_same_field_SCI_20261113')
HISTORICAL = Path('/workspace/work/V90_two_class_key_figures_20261123/metrics')
PERIODS = ['T1', 'T2', 'T3', 'T4']


def read_csv(path):
    with path.open(encoding='utf-8-sig') as file:
        return list(csv.DictReader(file))


def scores(confusion):
    results = []
    for index in range(2):
        tp = int(confusion[index, index])
        fp = int(confusion[:, index].sum() - tp)
        fn = int(confusion[index, :].sum() - tp)
        results.append(dict(precision=tp/(tp+fp), recall=tp/(tp+fn),
                            dice=2*tp/(2*tp+fp+fn), iou=tp/(tp+fp+fn)))
    return results


def summarize(values):
    return dict(mean=float(np.mean(values)),
                sd=float(np.std(values, ddof=1)) if len(values) > 1 else None,
                values=[float(x) for x in values])


def group(mask, period, kind):
    out = np.zeros(mask.shape, dtype=np.uint8)
    if period == 'T1':
        out[(mask == (255 if kind == 'joint' else 4))] = 4
        return out
    out[np.isin(mask, [1] if kind == 'joint' else [1, 3])] = 1
    out[mask == 2] = 2
    if kind == 'reference':
        out[mask == 255] = 255
    return out


def main():
    selected = json.loads((STUDY/'selected_model/Selection.json').read_text())
    provenance_path = STUDY/'predictions/0353-2-B3/Prediction_provenance.json'
    provenance = json.loads(provenance_path.read_text())
    checkpoint_sha = hashlib.sha256((STUDY/'selected_model/best.pt').read_bytes()).hexdigest()
    assert provenance['checkpoint_SHA256'] == checkpoint_sha
    assert provenance['seed'] == selected['seed'] and provenance['model_variant'] == 'joint_full'
    paths = {
        'reference': STUDY/'data/reference_masks_current',
        'v66': FIGURE_ARCHIVE/'sources/V66',
        'joint': STUDY/'predictions/0353-2-B3',
        'rgb': FIGURE_ARCHIVE/'sources/RGB',
    }
    roi = json.loads((FIGURE_ARCHIVE/'roi_manifest.json').read_text())['ROI_xyxy']
    x0, y0, x1, y1 = roi
    x0, x1 = x0 - 120, x1 + 120
    area = np.s_[y0:y1, x0:x1]
    crops = {}
    hashes = {}
    confusion = np.zeros((2, 2), dtype=np.int64)
    for t in PERIODS:
        rgb_file = paths['rgb']/f'{t}_RGB.png'
        rgb = np.array(Image.open(rgb_file).convert('RGB'))
        rgb_sha = hashlib.sha256(rgb_file.read_bytes()).hexdigest()
        assert rgb_sha == next(p['RGB_SHA256'] for p in provenance['prediction_records'] if p['period'] == t)
        hashes[f'{t}_rgb'] = rgb_sha
        crops[f'{t}_rgb'] = rgb[area].copy()
        labels = {}
        for key in ['reference', 'v66', 'joint']:
            suffix = 'two_classes' if key == 'joint' else 'classes'
            file = paths[key]/f'{t}_{suffix}.png'
            raw = np.array(Image.open(file))
            assert raw.shape == rgb.shape[:2]
            labels[key] = group(raw, t, key)
            hashes[f'{t}_{key}'] = hashlib.sha256(file.read_bytes()).hexdigest()
            crops[f'{t}_{key}'] = labels[key][area].copy()
        if t == 'T1':
            continue
        assert np.array_equal(labels['joint'] > 0, labels['v66'] > 0)
        with np.load(STUDY/'data'/f'{t}_pixels.npz') as data:
            eligible = data['split'] == 2
            pixels = data['pixel'][eligible]
            truth = (data['target'][eligible] == 1).astype(int)
            assert np.array_equal(labels['reference'].ravel()[pixels], truth+1)
            prediction = labels['v66'].ravel()[pixels].astype(int)-1
            assert np.isin(prediction, [0, 1]).all()
            confusion += np.bincount(2*truth+prediction, minlength=4).reshape(2, 2)
    assert confusion.sum() == 83478 and confusion.sum(1).tolist() == [70907, 12571]
    original_scores = scores(confusion)
    expected = read_csv(HISTORICAL/'Historical_two_class_references.csv')
    assert all(abs(s['dice'] - float(e['Dice'])) < 1e-12 for s, e in zip(original_scores, expected))
    runs = read_csv(STUDY/'reports/Per_run_metrics.csv')
    full_runs = [run for run in runs if run['variant'] == 'joint_full']
    control = [float(r['macro_Dice'])*100 for r in read_csv(HISTORICAL/'Internal_two_class_runs.csv')
               if r['variant'] == 'current_only']
    baselines = {
        'frame_only': summarize(control),
        'v66': summarize([100*np.mean([c['dice'] for c in original_scores])]),
        **{variant: summarize([100*float(r['macro_Dice']) for r in runs if r['variant'] == variant])
           for variant in ['neural_only', 'joint_full']},
    }
    paired = read_csv(STUDY/'reports/Paired_effects.csv')
    ablation = {reference: summarize([float(r['macro_Dice_delta_pp']) for r in paired
                                    if r['reference'] == reference])
                for reference in ['neural_only', 'without_axis', 'without_junction']}
    comparison = []
    for index, name, metrics in [(1, 'New', ['Precision','Recall','Dice','IoU']),
                                 (0, 'Existing', ['Dice','IoU'])]:
        for metric in metrics:
            column = f'{name.lower()}_{metric}'
            values = summarize([100*float(r[column]) for r in full_runs])
            comparison.append(dict(root_class=name, metric=metric,
                                   v66=100*original_scores[index][metric.lower()], joint=values))
    np.savez_compressed(OUT/'B3_matched_crops.npz', **crops)
    manifest = dict(position='0353-2-B3', eligible_pixels=83478, crop_xyxy=[x0,y0,x1,y1],
                    crop_selection='Previously archived morphology-based crop widened by 120 pixels on each side',
                    checkpoint_sha256=checkpoint_sha, qualitative_checkpoint_seed=selected['seed'],
                    historical_v66_confusion=confusion.tolist(), source_sha256=hashes,
                    baselines=baselines, paired_ablations=ablation, comparison=comparison)
    (OUT/'Figure_data.json').write_text(json.dumps(manifest, indent=2))
    rows = []
    for key, entry in baselines.items():
        rows.append(['A', key, 'Macro Dice', '%', entry['mean'], entry['sd'], len(entry['values'])])
    for key, entry in ablation.items():
        rows.append(['B', f'joint_full minus {key}', 'Macro Dice', 'pp', entry['mean'], entry['sd'], len(entry['values'])])
    for entry in comparison:
        rows.append(['C', 'V66 U-Net', entry['root_class']+' '+entry['metric'], '%', entry['v66'], None, 1])
        rows.append(['C', 'Joint model', entry['root_class']+' '+entry['metric'], '%', entry['joint']['mean'],
                     entry['joint']['sd'], len(entry['joint']['values'])])
    with (OUT/'Plotted_metrics.csv').open('w', newline='', encoding='utf-8-sig') as file:
        writer = csv.writer(file)
        writer.writerow(['Panel','Comparison','Metric','Unit','Mean','SD','Runs'])
        writer.writerows(rows)
    print(json.dumps({'roi':manifest['crop_xyxy'], 'counts':confusion.tolist(),
                      'baselines':baselines,'ablations':ablation,'metrics':comparison}, indent=2))


if __name__ == '__main__':
    main()
