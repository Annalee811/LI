"""Compare frozen V66 outputs with the original V90 workflow on matched B3 pixels."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image

OUT = Path(__file__).resolve().parent
STUDY = OUT.parent/'V90_joint_learned_structure_20261124'
EARLIER_FIGURE = OUT.parent/'V90_joint_ablation_V66_SCI_20261124'
HISTORY = Path('/workspace/work/V90_two_class_key_figures_20261123/metrics')
ARCHIVE = Path('/workspace/work/V90_all_microtubes_20261118')
INFERENCE = ARCHIVE/'B3_verified_inference'
PERIODS = ('T1','T2','T3','T4')


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    with path.open(encoding='utf-8-sig') as file:
        return list(csv.DictReader(file))


def group(mask, period):
    if period=='T1':
        assert set(np.unique(mask)) <= {0,4}
        return mask.copy()
    assert set(np.unique(mask)) <= {0,1,2,3}
    result = mask.copy()
    result[mask==3] = 1
    return result


def score(raw):
    matrix = np.stack([raw[0]+raw[2],raw[1]])
    result = {}
    for i, name in enumerate(('Existing','New')):
        tp = int(matrix[i,i])
        fp = int(matrix[:,i].sum()-tp)
        fn = int(matrix[i].sum()-tp)
        result[name] = dict(Precision=100*tp/(tp+fp), Recall=100*tp/(tp+fn),
                            Dice=100*2*tp/(2*tp+fp+fn), IoU=100*tp/(tp+fp+fn))
    result['macro_dice'] = (result['Existing']['Dice']+result['New']['Dice'])/2
    result['extension_error'] = 100*int(raw[2,1])/int(raw[2].sum())
    return result


def main():
    old = json.loads((EARLIER_FIGURE/'Figure_data.json').read_text())
    x0,y0,x1,y1 = old['crop_xyxy']
    area = np.s_[y0:y1,x0:x1]
    with np.load(EARLIER_FIGURE/'B3_matched_crops.npz') as cache:
        crops = {k:v for k,v in cache.items() if not k.endswith('_joint')}
    staged = {'v66':INFERENCE/'base/unet/full','v90':INFERENCE/'junction/full'}
    total = np.zeros((3,2,2),dtype=np.int64)
    per_period, hashes = {},{}
    for period in PERIODS:
        loaded = {}
        for kind, path in staged.items():
            file = path/f'{period}_classes.png'
            loaded[kind] = group(np.array(Image.open(file)),period)
            hashes[f'{period}_{kind}'] = hash_file(file)
            cropped = loaded[kind][area].copy()
            if kind=='v66':
                assert np.array_equal(cropped,crops[f'{period}_v66'])
            else:
                released = ARCHIVE/'delivery/B3_V90_automatic'/file.name
                assert hash_file(released)==hashes[f'{period}_{kind}']
                crops[f'{period}_v90'] = cropped
        assert np.array_equal(loaded['v66']>0,loaded['v90']>0)
        if period=='T1':
            continue
        with np.load(STUDY/'data'/f'{period}_pixels.npz') as inputs:
            take = inputs['split']==2
            truth = inputs['target'][take]
            location = inputs['pixel'][take]
        reference = STUDY/'data/reference_masks_current'/f'{period}_classes.png'
        assert np.array_equal(np.array(Image.open(reference)).ravel()[location],truth+1)
        hashes[f'{period}_reference'] = hash_file(reference)
        a,b=(loaded[k].ravel()[location] for k in ('v66','v90'))
        assert np.isin(a,[1,2]).all() and np.isin(b,[1,2]).all()
        paired = np.bincount(4*truth+2*(a-1)+(b-1),minlength=12).reshape(3,2,2)
        per_period[period]=paired.tolist()
        total += paired
    assert total.sum()==83478 and total.sum(axis=(1,2)).tolist()==[69879,12571,1028]
    before,after = total.sum(axis=2),total.sum(axis=1)
    performance={'v66':score(before),'v90':score(after)}
    historical = rows(HISTORY/'Historical_two_class_references.csv')
    for key, archivemodel in [('v66','V66_pairwise_frozen'),('v90','V90_automatic_historical')]:
        stored = next(r for r in historical if r['model']==archivemodel)
        assert abs(performance[key]['macro_dice']-100*float(stored['macro_Dice'])) < 1e-10
    frame_values=[100*float(r['macro_Dice']) for r in rows(HISTORY/'Internal_two_class_runs.csv')
                  if r['variant']=='current_only']
    assert len(frame_values)==3
    diff=performance['v90']['extension_error']-performance['v66']['extension_error']
    info = dict(position='0353-2-B3', crop_xyxy=[x0,y0,x1,y1], evaluation_pixels=int(total.sum()),
                historical_frame_control=float(np.mean(frame_values)), frame_control_runs=frame_values,
                performance=performance, extension_counts=[int(before[2,1]),int(after[2,1])],
                extension_error_delta_pp=diff, macro_delta_pp=performance['v90']['macro_dice']-performance['v66']['macro_dice'],
                paired_counts=total.tolist(), per_period=per_period,
                paired_axes=['manual P,N,E','V66 Existing,New','V90 Existing,New'],
                input_sha256=hashes, foreground_masks_match_all_dates=True)
    (OUT/'Figure_data.json').write_text(json.dumps(info,indent=2))
    np.savez_compressed(OUT/'B3_matched_crops.npz',**crops)
    with (OUT/'Metrics.csv').open('w',newline='',encoding='utf-8-sig') as file:
        writer=csv.writer(file)
        writer.writerow(['Metric','V66 U-Net','Original automatic V90','V90 minus V66 (percentage points)'])
        for key in ['macro_dice','extension_error']:
            a,b=(performance[k][key] for k in ('v66','v90'))
            writer.writerow([key,a,b,b-a])
        for name in ('New','Existing'):
            fields=['Precision','Recall','Dice','IoU'] if name=='New' else ['Dice','IoU']
            for metric in fields:
                a,b=(performance[k][name][metric] for k in ('v66','v90'))
                writer.writerow([f'{name} {metric}',a,b,b-a])
    print(json.dumps({'performance':performance,'extension_misclassified':info['extension_counts'],
                      'extension_error_delta_pp':diff, 'macro_delta_pp':info['macro_delta_pp']},indent=2))


if __name__=='__main__':
    main()
