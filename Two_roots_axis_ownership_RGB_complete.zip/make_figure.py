"""Four-panel, two-candidate root-axis and temporal-segment figure on exact RGB."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,patheffects
from matplotlib.patches import Patch
from matplotlib.text import Text
import fitz
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);arg=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(arg.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':10,'text.color':'black','pdf.fonttype':42,'svg.fonttype':'none'})
d=json.loads((R/'data_manifest.json').read_text());z=np.load(R/'exact_inputs.npz');a={k:z[k] for k in z.files}
for k,q in d['arrays'].items():assert hashlib.sha256(a[k].tobytes()).hexdigest()==q['array_sha256']
rgb=a['RGB'];sel=a['selected_domain'];before=rgb.copy();after=rgb.copy();segments=rgb.copy()
AXCOL={327:'#00A6A0',388:'#D2674F'};CLCOL={1:'#3F75C4',2:'#E69F35',3:'#B64E8B'};UNC='#808890'
def col(s):return np.array([int(s[i:i+2],16) for i in [1,3,5]],np.uint8)
before[sel]=col('#D1D3D6');before[sel&a['before_uncertain']]=col(UNC)
for k,c in AXCOL.items():after[sel&(a['after_axis_ids']==k)]=col(c)
for k,c in CLCOL.items():segments[sel&(a['after_temporal']==k)]=col(c)
after[sel&a['after_uncertain']]=col(UNC);segments[sel&a['after_uncertain']]=col(UNC)
images=[rgb,before,after,segments];names=['Original_RGB','Before_axis_fragments','Refined_candidate_axes','Refined_root_segments'];records=[]
for im,n in zip(images,names):
 assert np.array_equal(im[~sel],rgb[~sel]);Image.fromarray(im).save(R/(n+'.png'))
 records.append({'file':n+'.png','array_sha256':hashlib.sha256(im.tobytes()).hexdigest()})
W,H=210,76;LEFT,CW,GAP=7,47.5,2;PH=CW*180/240
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
def txt(x,y,s,size=10,bold=False,ha='left'):
 return fig.text(x/W,1-y/H,s,ha=ha,va='center',fontsize=size,fontweight='bold' if bold else 'normal',color='black')
headers=['A  Original RGB','B  Before axes','C  Refined axes','D  Root segments']
axs=[]
for j,(im,title) in enumerate(zip(images,headers)):
 x=LEFT+j*(CW+GAP);txt(x+CW/2,7.5,title,11,bold=True,ha='center')
 aa=fig.add_axes([x/W,1-(15+PH)/H,CW/W,PH/H]);aa.imshow(im,interpolation='nearest');aa.axis('off');axs.append(aa)
# Source-fragment terminal nodes, not invented breaks or manually redrawn roots.
x0,y0,_,_=d['ROI_xyxy']
for e in d['before_fragment_endpoints']:
 x,y=e['xy'];axs[1].plot(x-x0,y-y0,'o',ms=3.5,mfc='white',mec='black',mew=.7,zorder=8)
# Labels point to existing, non-uncertain source pixels.
def anchor(mask,target):
 pts=np.argwhere(mask);target_yx=np.array(target[::-1]);q=pts[np.argmin(((pts-target_yx)**2).sum(1))];return (float(q[1]),float(q[0]))
def label(aa,text,mask,xytext,target):
 aa.annotate(text,xy=anchor(mask,target),xytext=xytext,textcoords='data',ha='center',va='center',fontsize=9.5,fontweight='bold',color='black',bbox={'fc':'white','ec':'none','alpha':.95,'pad':1.2},arrowprops={'arrowstyle':'-','color':'black','lw':.7},zorder=9)
valid=sel&~a['after_uncertain']
label(axs[2],'R1',valid&(a['after_axis_ids']==327),(88,28),(124,27))
label(axs[2],'R2',valid&(a['after_axis_ids']==388),(52,145),(64,109))
label(axs[3],'N',valid&(a['after_temporal']==2),(88,28),(124,27))
label(axs[3],'P',valid&(a['after_temporal']==1),(52,145),(64,109))
label(axs[3],'E',valid&(a['after_temporal']==3),(196,25),(165,54))
# One common native-pixel scale, valid for every matched panel.
line,=axs[0].plot([12,62],[166,166],color='white',lw=1.8,solid_capstyle='butt');line.set_path_effects([patheffects.Stroke(linewidth=2.7,foreground='black'),patheffects.Normal()])
axs[0].text(37,154,'50 px',fontsize=9,ha='center',va='bottom',color='black',bbox={'fc':'white','ec':'none','pad':.5})
txt(LEFT+CW+GAP+CW/2,57,'○  Fragment endpoints',9,bold=True,ha='center')
txt(LEFT+2*(CW+GAP)+CW/2,57,'Two candidate axes',9,bold=True,ha='center')
legend=[Patch(fc=CLCOL[c],ec='none',label=n) for c,n in [(1,'Persistent (P)'),(2,'New (N)'),(3,'Extension (E)')]]+[Patch(fc=UNC,ec='none',label='Uncertain')]
leg=fig.legend(handles=legend,loc='center',bbox_to_anchor=(.52,1-67/H),ncol=4,frameon=False,fontsize=9.5,handlelength=1.1,columnspacing=1.6)
for t in leg.get_texts():t.set_fontweight('bold')
for t in fig.findobj(match=Text):t.set_fontfamily('Times New Roman');t.set_color('black')
stem='Two_roots_axis_ownership_and_segments_on_RGB_SCI'
for ext in ['png','pdf']:fig.savefig(R/(stem+'.'+ext),dpi=600,facecolor='white')
fig.savefig(R/(stem+'.tiff'),dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
with Image.open(R/(stem+'.png')) as im:im.convert('RGB').save(R/(stem+'.jpg'),'JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
(R/'figure_manifest.json').write_text(json.dumps({'stem':stem,'figure_mm':[W,H],'dpi':600,'panels':records,'selected_roots_only':2,'display_IDs':d['display_IDs'],'axis_ID_colors':{str(k):v for k,v in AXCOL.items()},'temporal_class_colors':{str(k):v for k,v in CLCOL.items()},'uncertainty_color':UNC,'uncertainty_preserved':True,'unknown_pixels_omitted_from_confident_color':int((sel&a['after_uncertain']).sum()),'overlay_definition':'Exact existing selected-domain raster recoloring; other RGB pixels untouched. Pixel ownership is the single scalar owner in the existing axis map.','source_versions':d['source_versions'],'font':'Black Times New Roman; titles, legend and labels bold','new_training_inference_registration':False},indent=2)+'\n')
with fitz.open(R/(stem+'.pdf')) as doc:doc[0].get_pixmap(matrix=fitz.Matrix(2.3,2.3),alpha=False).save(R/'preview.png')
print('Rendered one local example, two candidate roots, four panels; all three temporal classes shown.')
