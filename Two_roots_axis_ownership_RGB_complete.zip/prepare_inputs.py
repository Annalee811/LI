"""Prepare one genuine two-candidate example; preserve all source predictions."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/LI/analysis-scripts')
from dataset_identity import require_active_position
require_active_position('0353-2-B3')
base=Path('/workspace/LI/results');old=base/'B3_temporal_manual_continuity_v17';new=base/'B3_temporal_root_identity_v18'
box=[1530,870,1770,1050];x,y,xx,yy=box;sl=np.s_[y:yy,x:xx];t='T2';files=[]
def readrec(p):
 files.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});return p
oldrgb=np.array(Image.open(readrec(old/f'data/upper/{t}_RGB.png')).convert('RGB'));rgb=np.array(Image.open(readrec(new/f'data/upper/{t}_RGB.png')).convert('RGB'));assert np.array_equal(oldrgb,rgb)
a=np.load(readrec(old/f'axis_cache/unet/{t}.npz'));b=np.load(readrec(new/f'axis_cache/unet/{t}.npz'))
am=a['axis_map'];bm=b['axis_map'];assert np.array_equal(am>0,bm>0)
full_rgb_hash=hashlib.sha256(rgb.tobytes()).hexdigest()
root_ids=[327,388];selected=np.isin(bm[sl],root_ids)
oldids=np.unique(am[sl][selected]);oldids=oldids[oldids>0].astype(int).tolist()
oldtemp=np.array(Image.open(readrec(old/f'unet/four_period_prediction/{t}_temporal_classes.png')))
newtemp=np.array(Image.open(readrec(new/f'unet/four_period_prediction/{t}_temporal_classes.png')))
root_records=json.loads(readrec(new/f'unet/four_period_prediction/{t}_root_axes.json').read_text())
od=json.loads(readrec(old/f'axis_cache/unet/{t}.json').read_text());nd=json.loads(readrec(new/f'axis_cache/unet/{t}.json').read_text())
paths={};ends=[]
for ai in oldids:
 pts=a['xy'][a[f'path_{ai-1}']];paths[f'before_{ai}']=pts
 for q in [pts[0],pts[-1]]:
  if y<=q[0]<yy and x<=q[1]<xx and selected[int(q[0])-y,int(q[1])-x]:ends.append({'axis_id':ai,'xy':[int(q[1]),int(q[0])]})
for ai in root_ids:paths[f'after_{ai}']=b['xy'][b[f'path_{ai-1}']]
arrays={'RGB':rgb[sl].copy(),'before_axis_ids':am[sl].copy(),'after_axis_ids':bm[sl].copy(),'before_uncertain':a['uncertain'][sl].copy(),'after_uncertain':b['uncertain'][sl].copy(),'before_temporal':oldtemp[sl].copy(),'after_temporal':newtemp[sl].copy(),'selected_domain':selected}
np.savez_compressed(R/'exact_inputs.npz',**arrays);np.savez_compressed(R/'selected_paths.npz',**paths)
(R/'source_checks.json').write_text(json.dumps({'files':files,'original_RGB_identical_before_after':True,'binary_root_geometry_identical_before_after':True,'full_RGB_array_sha256':full_rgb_hash},indent=2)+'\n')
counts={str(ai):{str(int(c)):int(n) for c,n in zip(*np.unique(newtemp[sl][bm[sl]==ai],return_counts=True))} for ai in root_ids}
manifest={'position':'0353-2-B3','period':t,'ROI_xyxy':box,'crop_shape':[180,240],'selected_after_candidate_IDs':root_ids,'display_IDs':{'R1':327,'R2':388},'before_fragment_IDs':oldids,'before_fragment_endpoints':ends,'source_versions':{'before':'V17 manual continuity','after':'V18 root identity refinement'},'source_root_records':[root_records[i-1] for i in root_ids],'after_class_counts_per_selected_axis':counts,'arrays':{k:{'shape':list(v.shape),'dtype':str(v.dtype),'array_sha256':hashlib.sha256(v.tobytes()).hexdigest()} for k,v in arrays.items()},'selection':'One local two-axis example of archived geometric fragment association at an intersection; not selected as an independent accuracy test.','limitation':'Candidate axes and final raster ownership, not independently established biological parent/lateral identity. Both selected full paths contain unresolved crossing flags; local uncertainty is retained.','ROI_domain':'Exactly the same two final-candidate foreground masks define the displayed domain across panels; all source IDs and classes remain unchanged. No other roots are colored.','new_training_inference_registration':False}
(R/'data_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
Image.fromarray(arrays['RGB']).save(R/'Original_RGB_crop.png')
print(json.dumps({'selected_axes':root_ids,'before_fragments':oldids,'before_endpoints':ends,'classes':counts,'uncertain_selected_pixels':int((selected&arrays['after_uncertain']).sum())},indent=2))
