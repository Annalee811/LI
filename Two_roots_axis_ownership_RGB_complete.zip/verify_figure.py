"""Verify exact source ownership/class overlays and scientific export typography."""
from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
import fitz
R=Path(__file__).resolve().parent;d=json.loads((R/'data_manifest.json').read_text());f=json.loads((R/'figure_manifest.json').read_text());z=np.load(R/'exact_inputs.npz');a={k:z[k] for k in z.files}
for k,q in d['arrays'].items():assert hashlib.sha256(a[k].tobytes()).hexdigest()==q['array_sha256']
checked=0
for q in json.loads((R/'source_checks.json').read_text())['files']:
 p=Path(q['file'])
 if p.exists():assert hashlib.sha256(p.read_bytes()).hexdigest()==q['sha256'];checked+=1
rgb=a['RGB'];sel=a['selected_domain'];assert rgb.shape==(180,240,3)
assert np.array_equal(sel,np.isin(a['after_axis_ids'],[327,388]))
assert not np.any((a['after_axis_ids']==327)&(a['after_axis_ids']==388))
def col(v):return np.array([int(v[i:i+2],16) for i in [1,3,5]],np.uint8)
expected=[rgb.copy(),rgb.copy(),rgb.copy(),rgb.copy()]
expected[1][sel]=col('#D1D3D6');expected[1][sel&a['before_uncertain']]=col(f['uncertainty_color'])
for k,c in f['axis_ID_colors'].items():expected[2][sel&(a['after_axis_ids']==int(k))]=col(c)
for k,c in f['temporal_class_colors'].items():expected[3][sel&(a['after_temporal']==int(k))]=col(c)
for j in [2,3]:expected[j][sel&a['after_uncertain']]=col(f['uncertainty_color'])
for rec,expect in zip(f['panels'],expected):
 im=np.array(Image.open(R/rec['file']));assert np.array_equal(im,expect)
 assert np.array_equal(im[~sel],rgb[~sel]);assert hashlib.sha256(im.tobytes()).hexdigest()==rec['array_sha256']
assert set(np.unique(a['after_temporal'][sel]).tolist())=={1,2,3}
assert int((sel&a['after_uncertain']).sum())==84
with fitz.open(R/(f['stem']+'.pdf')) as doc:
 assert len(doc)==1;page=doc[0]
 fonts={q[3].split('+')[-1] for q in page.get_fonts()};assert fonts=={'TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'}
 spans=[s for b in page.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
 assert all(s['color']==0 for s in spans)
 for s in spans:
  box=fitz.Rect(s['bbox']);assert box.x0>=0 and box.y0>=0 and box.x1<=page.rect.width and box.y1<=page.rect.height
 assert min(s['size'] for s in spans)>=8.99
 text=page.get_text();assert all(q in text for q in ['R1','R2','Persistent (P)','New (N)','Extension (E)','Uncertain'])
exports={}
for ext in ['png','jpg','tiff']:
 with Image.open(R/(f['stem']+'.'+ext)) as im:
  assert abs(im.width-round(210/25.4*600))<=1 and abs(im.height-round(76/25.4*600))<=1
  assert im.convert('RGB').getpixel((0,0))==(255,255,255)
  exports[ext]={'pixels':list(im.size),'dpi':[float(v) for v in im.info.get('dpi',[])]}
report={'source_file_hashes_checked_locally':checked,'two_existing_candidate_axes_only':True,'candidate_IDs':[327,388],'same_ROI_all_four_panels':[1530,870,1770,1050],'existing_foreground_geometry_unchanged':True,'unhighlighted_RGB_pixels_exact':True,'one_existing_raster_owner_per_pixel':True,'independent_biological_identity_validated':False,'all_three_temporal_classes_present':True,'uncertain_pixels_retained':84,'fonts':sorted(fonts),'all_text_black_within_page':True,'font_range_pt':[min(s['size'] for s in spans),max(s['size'] for s in spans)],'exports':exports,'new_training_registration_inference':False}
(R/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
