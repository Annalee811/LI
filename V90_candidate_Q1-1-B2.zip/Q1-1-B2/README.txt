V90 frozen-weight transfer CANDIDATE; not the exact archived reviewed V90 pipeline.
Read adapter_provenance.json before use. No independent accuracy is claimed.
Classes:0 background,1 persistent,2 newly observed,3 extending,4 first-observation baseline.
RGB_temporal_candidate: full native grid over original registered RGB.
RGB_uncertainty_review: uncertain foreground is grey. Other version has all provisional class colors.
Ownership is exclusive at every pixel. Track IDs are inferred links, not validated biological identities.
First observation is baseline; missing dates are absent.
