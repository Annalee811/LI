from pathlib import Path
import json,csv,hashlib,shutil,argparse
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.text import Text
from matplotlib import font_manager
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Render matched V66/V90 radial charts from archived pooled metrics.')
parser.add_argument('--source',type=Path,default=HERE/'source_comparison.json')
parser.add_argument('--output-dir',type=Path,default=HERE)
parser.add_argument('--fonts-dir',type=Path,help='Directory containing licensed Times New Roman regular and bold TTF files; omit when installed.')
args=parser.parse_args();ROOT=args.output_dir.resolve();SOURCE=args.source.resolve();ROOT.mkdir(parents=True,exist_ok=True)
if args.fonts_dir:
 for name in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(args.fonts_dir/name))
for weight in ['normal','bold']:
 font_manager.findfont(font_manager.FontProperties(family='Times New Roman',weight=weight),fallback_to_default=False)
plt.rcParams.update({'font.family':'Times New Roman','font.size':8,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'svg.fonttype':'none','axes.unicode_minus':False,'mathtext.fontset':'stix','axes.linewidth':.6})
v=json.loads(SOURCE.read_text());rows=v['classes'];METRICS=['Precision','Recall','Dice','IoU'];COLORS=['#75BED8','#E6AA75','#D7838C'];NAMES=['Newly observed','Extending','Persistent'];STARTS=[-48,72,192]
WMM,HMM=190.5,118;fig=plt.figure(figsize=(WMM/25.4,HMM/25.4),facecolor='white');cy=.53;R0=56;SPAN=40;data=[]
for panel,(cx,prefix,model,title) in enumerate([(.255,'V66','V66 U-Net','V66 U-Net'),(.745,'V90','V90 reviewed','V90 reviewed')]):
 ax=fig.add_axes([cx-.225,cy-.36,.45,.72],projection='polar');ax.set_theta_zero_location('N');ax.set_theta_direction(-1);ax.set_ylim(0,140);ax.set_axis_off()
 theta=np.linspace(0,2*np.pi,721)
 for rr in [R0,R0+SPAN*.5,R0+SPAN]:ax.plot(theta,np.full_like(theta,rr),color='#D2D8DB',lw=.55,ls='-' if rr==R0 else (0,(2,2)),zorder=0)
 for ci,r in enumerate(rows):
  for mi,metric in enumerate(METRICS):
   deg=STARTS[ci]+12+24*mi;angle=np.deg2rad(deg);value=100*r[prefix+'_'+metric];height=SPAN*value/100
   ax.bar(angle,SPAN,width=np.deg2rad(22.8),bottom=R0,color=COLORS[ci],alpha=.15,edgecolor='white',linewidth=.55,zorder=1)
   ax.bar(angle,height,width=np.deg2rad(22.8),bottom=R0,color=COLORS[ci],alpha=.98,edgecolor='white',linewidth=.6,zorder=2)
   # Metric names follow the outward radial direction, with upright text on both halves.
   a=deg%360;rot=90-a;ha='left'
   if 180<a<360:rot+=180;ha='right'
   ax.text(angle,105.5,metric,rotation=rot,rotation_mode='anchor',ha=ha,va='center',fontsize=8,zorder=5)
   # Score annotations use the local tangent outside each actual bar.
   nr=-a
   if 90<a<270:nr+=180
   ax.text(angle,R0+height+3.8,f'{value:.1f}',rotation=nr,rotation_mode='anchor',ha='center',va='center',fontsize=8,zorder=5,bbox=dict(fc='white',ec='none',alpha=.82,pad=.1))
   data.append(dict(Workflow=model,Root_class=r['class_en'],Metric=metric,Score_percent=value))
 # Small reference ticks in a gap between adjacent root-class sectors.
 for score in [0,50,100]:ax.text(np.deg2rad(60),R0+SPAN*score/100,str(score),fontsize=8,ha='center',va='center',color='black',bbox=dict(fc='white',ec='none',alpha=.9,pad=.25),zorder=5)
 # The center shows the three exact pooled class Dice values (not synthetic replicates).
 iw,ih=21/WMM,18/HMM;inset=fig.add_axes([cx+2/WMM-iw/2,cy-ih/2,iw,ih],facecolor='white')
 vals=[100*r[prefix+'_Dice'] for r in rows];inset.bar(range(3),vals,color=COLORS,width=.66,edgecolor='white',linewidth=.4,zorder=2)
 for i,val in enumerate(vals):inset.text(i,val+3,f'{val:.1f}',ha='center',va='bottom',fontsize=8)
 inset.set(xlim=(-.6,2.6),ylim=(0,125));inset.set_xticks([0,1,2],['N','E','P']);inset.set_yticks([0,50,100]);inset.tick_params(labelsize=8,width=.5,length=1.5,pad=1.5);inset.spines[['top','right']].set_visible(False)
 for side in ['left','bottom']:inset.spines[side].set_color('black');inset.spines[side].set_linewidth(.5)
 inset.set_title('Dice (%)',fontsize=8.5,pad=1.5,fontweight='bold')
 fig.text(cx-.225,.963,'ab'[panel],fontsize=11,fontweight='bold',ha='left',va='center')
 fig.text(cx,.963,title,fontsize=11,fontweight='bold',ha='center',va='center')
 fig.text(cx,.142,f'Macro Dice = {100*v["summaries"][model]["macro"]["Dice"]:.2f}%',fontsize=8.5,ha='center',va='center')
fig.legend(handles=[Patch(facecolor=c,edgecolor='none',label=n) for c,n in zip(COLORS,NAMES)],loc='lower center',bbox_to_anchor=(.5,.063),ncol=3,frameon=False,fontsize=8.5,handlelength=1.25,columnspacing=2.0)
fig.text(.5,.027,'Outer ring: class-wise metrics (%)    |    Center: Dice (%)    |    N, newly observed; E, extending; P, persistent',fontsize=8,ha='center',va='center')
for t in fig.findobj(match=Text):t.set_color('#000000');t.set_fontfamily('Times New Roman')
for ext in ['png','pdf','svg']:fig.savefig(ROOT/f'V66_V90_radial_comparison.{ext}',dpi=600,facecolor='white')
fig.savefig(ROOT/'V66_V90_radial_comparison.tiff',dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
im=Image.open(ROOT/'V66_V90_radial_comparison.png').convert('RGB');im.save(ROOT/'V66_V90_radial_comparison.jpg','JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
with (ROOT/'V66_V90_radial_data.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
if SOURCE!=(ROOT/'source_comparison.json').resolve():shutil.copy2(SOURCE,ROOT/'source_comparison.json')
(ROOT/'source_verification.json').write_text(json.dumps({'source_json':str(SOURCE),'sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'scope':v['scope'],'metrics':'Whole-root-region pooled values from the prior comparison table, NOT window-wise boxplot medians.','colors':'Root classes use the same palette in both workflows.','radial_scale':'Score 0–100% maps linearly onto radius 56–96; pale tracks show the full 100% range.','center_bars':'Exact pooled class Dice values, no sampling error bars or synthetic replicates.','V90':'Final reviewed/structured workflow, including explicit manual support.'},indent=2))
print('Created two matched radial panels with identical scales and exact pooled comparison-table values.')
