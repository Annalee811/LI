from pathlib import Path
import csv, json, hashlib
import fitz
from PIL import Image

root = Path(__file__).resolve().parent
source = json.loads((root/'source_comparison.json').read_text())
rows = list(csv.DictReader((root/'V66_V90_radial_data.csv').open(encoding='utf-8-sig')))
assert len(rows) == 24
for row in rows:
    reference = next(r for r in source['classes'] if r['class_en'] == row['Root_class'])
    prefix = 'V66' if row['Workflow'] == 'V66 U-Net' else 'V90'
    assert float(row['Score_percent']) == 100*reference[prefix+'_'+row['Metric']]
doc = fitz.open(root/'V66_V90_radial_comparison.pdf')
assert len(doc) == 1
page = doc[0]
spans = [s for b in page.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()]
assert all(s['color'] == 0 for s in spans)
assert all(s['font'] in ['TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'] for s in spans)
assert min(s['size'] for s in spans) >= 7.99
assert all(page.rect.contains(fitz.Rect(s['bbox'])) for s in spans)
assert len(page.get_images()) == 0
images = {}
for ext in ['jpg','png','tiff']:
    im = Image.open(root/f'V66_V90_radial_comparison.{ext}')
    assert im.width == 4500 and 2786 <= im.height <= 2788
    assert all(abs(d-600) < .1 for d in im.info['dpi'])
    images[ext] = {'size': im.size, 'dpi': [float(d) for d in im.info['dpi']]}
report = {'data_rows_checked':len(rows),'match':'exact pooled source percentages',
          'fonts':sorted(set(s['font'] for s in spans)), 'all_text_black':True,
          'min_font_pt':min(s['size'] for s in spans),'all_text_inside_page':True,
          'vector_pdf':True,'page_size_pt':list(page.rect),'images':images,
          'source_sha256':hashlib.sha256((root/'source_comparison.json').read_bytes()).hexdigest()}
(root/'verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
