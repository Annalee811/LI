V35 complete root-segmentation figure

This replaces the earlier unpopulated layout proof with actual V35 results. Every source mask/probability/manifest/curve used or collected was verified against the frozen repository resource manifest at commit 4615bcbd37442a3b11e5ad4533242df95f237fb6 of Annalee811/Temporal-segmentation-model.

Inputs:
- V35 test manifest: 24 tile-date views, six spatial positions × four stages.
- Exact V35 reference masks and three branches of frozen float32 test probabilities.
- Whole-field RGB and reference from 02_root_background resources.
- Corresponding binary whole-field masks archived as frozen binary inputs for the temporal stage. These are binary segmentations, not temporal classifications. They also match the existing local files byte-for-byte.

No registration, neural training or new model inference was run. Pixel metrics and ROC were recomputed from archived V35 probabilities. TP/FP/FN/TN and all scalar reference metrics, including AUC, match the release (tolerance 1e-10). Root-length errors were recomputed from those same thresholded test probabilities using the explicit skeleton-edge definition in the caption and source script.

Outputs: complete JPG, PNG, PDF, SVG and 600-dpi TIFF, plotting data, bilingual caption and figure/evaluation source. Native pixel units are retained. DeepLabV3+ has negative identity-line agreement R²; this is a valid result and was not clipped or replaced.

The 24 paired observations are correlated within six spatial positions at one development location. No independent-tube generalization or biological replication claim is made. Whole-field panels are qualitative; hold-out metrics remain separate.

Reference pixel metrics:
U-Net: Dice 0.8787985060; AUC 0.9854476690.
DeepLabV3+: Dice 0.6392384909; AUC 0.8307972780.
SegFormer-B0: Dice 0.8357494382; AUC 0.9838803269.
