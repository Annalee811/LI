from pathlib import Path
import json,csv,hashlib
import numpy as np
from PIL import Image
from skimage.morphology import skeletonize
from scipy import ndimage as ndi
ROOT=Path('/workspace/work/V35_segmentation_figure_20261104');ASSETS=ROOT/'sources/02_root_background/assets';OUT=ROOT/'evaluation';OUT.mkdir(exist_ok=True)
MODELS={'unet':'U-Net','deeplab':'DeepLabV3+','segformer':'SegFormer-B0'}
def csvread(p):return list(csv.DictReader(Path(p).open(encoding='utf-8-sig')))
def csvwrite(p,rows):
 with Path(p).open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def length(mask):
 s=skeletonize(mask);h=(s[:,:-1]&s[:,1:]).sum();v=(s[:-1,:]&s[1:,:]).sum()
 dr=(s[:-1,:-1]&s[1:,1:]&~(s[1:,:-1]|s[:-1,1:])).sum()
 dl=(s[:-1,1:]&s[1:,:-1]&~(s[:-1,:-1]|s[1:,1:])).sum()
 degree=ndi.convolve(s.astype(np.uint8),np.ones((3,3),np.uint8),mode='constant')-s
 isolated=(s&(degree==0)).sum();return float(h+v+np.sqrt(2)*(dr+dl)+isolated)
def roc(y,p):
 order=np.argsort(-p,kind='stable');v=p[order];g=y[order]
 ends=np.r_[np.flatnonzero(np.diff(v)),len(v)-1];tp=np.cumsum(g,dtype=np.int64)[ends];fp=ends+1-tp
 tpr=np.r_[0,tp/y.sum()];fpr=np.r_[0,fp/(len(y)-y.sum())];auc=float(np.trapezoid(tpr,fpr))
 # Keep exact full ROC separately and simplify only the rendered polyline.
 return fpr,tpr,auc
manifest=csvread(ASSETS/'data/manifest.csv');rows=[r for r in manifest if r['split']=='test'];assert len(rows)==24 and len({r['tile_id'] for r in rows})==6
reference={r['model']:r for r in csvread(ASSETS/'reference_metrics.csv')};gts={};ref_lengths={}
for r in rows:
 p=ASSETS/r['mask_path'];a=np.array(Image.open(p));assert hashlib.sha256(p.read_bytes()).hexdigest()==r['mask_sha256'];gts[r['image_id']]=a;ref_lengths[r['image_id']]=length(a==255)
summary=[];pairs=[];per=[];coords={};verification={}
for m,name in MODELS.items():
 c=np.zeros(4,np.int64);yy=[];pp=[]
 for r in rows:
  key=r['image_id'];g=gts[key];p=np.load(ASSETS/'test_probabilities'/m/(key+'_probability.npy'));assert p.shape==g.shape and np.isfinite(p).all() and p.min()>=0 and p.max()<=1
  valid=g!=128;y=g==255;pred=p>=.5
  cc=np.array([(y&pred&valid).sum(),(~y&pred&valid).sum(),(y&~pred&valid).sum(),(~y&~pred&valid).sum()],np.int64);c+=cc
  ref=ref_lengths[key];est=length(pred&valid);pairs.append(dict(model=m,model_name=name,image_id=key,tile_id=r['tile_id'],period=r['period'],split='test',reference_length_px=ref,predicted_length_px=est,error_px=est-ref))
  per.append(dict(model=name,image_id=key,tile_id=r['tile_id'],period=r['period'],TP=int(cc[0]),FP=int(cc[1]),FN=int(cc[2]),TN=int(cc[3]),Dice=float(2*cc[0]/(2*cc[0]+cc[1]+cc[2]))))
  yy.append(y[valid]);pp.append(p[valid])
 y=np.concatenate(yy);p=np.concatenate(pp);fpr,tpr,auc=roc(y,p);coords[m+'_FPR']=fpr;coords[m+'_TPR']=tpr
 tp,fp,fn,tn=map(int,c);rec=dict(model=name,model_key=m,selected_epoch=int(reference[name]['selected_epoch']),TP=tp,FP=fp,FN=fn,TN=tn,Precision=tp/(tp+fp),Recall=tp/(tp+fn),Dice=2*tp/(2*tp+fp+fn),IoU=tp/(tp+fp+fn),Accuracy=(tp+tn)/c.sum(),AUC=auc)
 for k in ['TP','FP','FN','TN']:assert rec[k]==int(reference[name][k]),(m,k,rec[k],reference[name][k])
 for k in ['Precision','Recall','Dice','IoU','Accuracy','AUC']:assert abs(rec[k]-float(reference[name][k]))<1e-10,(m,k,rec[k],reference[name][k])
 a=[q for q in pairs if q['model']==m];x=np.array([q['reference_length_px'] for q in a]);z=np.array([q['predicted_length_px'] for q in a]);dif=z-x
 rec.update(length_pairs=24,MAE_px=float(np.abs(dif).mean()),RMSE_px=float(np.sqrt((dif*dif).mean())),R2_identity=float(1-(dif*dif).sum()/((x-x.mean())**2).sum()))
 summary.append(rec);verification[m]=dict(reference_metrics_match=True,valid_pixels=int(c.sum()),reference_root_pixels=int(y.sum()),ROC_points=len(fpr))
 print(m,'Dice',round(rec['Dice'],6),'AUC',round(auc,6),'R2',round(rec['R2_identity'],4),'MAE',round(rec['MAE_px'],2),'RMSE',round(rec['RMSE_px'],2),flush=True)
np.savez_compressed(OUT/'ROC_exact_coordinates.npz',**coords);csvwrite(OUT/'V35_metrics.csv',summary);csvwrite(OUT/'V35_root_length_pairs.csv',pairs);csvwrite(OUT/'V35_per_view_counts.csv',per)
(OUT/'V35_metrics.json').write_text(json.dumps(summary,indent=2));(OUT/'verification.json').write_text(json.dumps({'experiment':'V35, fixed100, threshold 0.5','evaluation':'archived probabilities; no model forward or training','test_views':24,'test_spatial_positions':6,'periods':['T1','T2','T3','T4'],'reference_count_and_auc_tolerance':1e-10,'models':verification,'length_definition':'2D Zhang skeleton; unique 8-neighbour edges; H/V=1, diagonal=sqrt(2), remove orthogonal-bridge redundant diagonals, isolated pixel=1; native pixels','length_errors':'Recomputed from V35 thresholded test probabilities and exact frozen test reference masks; no OLS regression fitted'},indent=2))
