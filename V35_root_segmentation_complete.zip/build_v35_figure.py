from pathlib import Path
import csv,json,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image
import numpy as np
ROOT=Path('/workspace/work/V35_segmentation_figure_20261104');OUT=ROOT/'figure';OUT.mkdir(exist_ok=True)
ASSETS=ROOT/'sources/02_root_background/assets';FROZEN=ROOT/'sources/03_temporal_V66/assets/frozen_binary';EV=ROOT/'evaluation'
plt.rcParams.update({'font.family':'Liberation Sans','font.size':8,'mathtext.fontset':'dejavusans','svg.fonttype':'none','pdf.fonttype':42,'axes.unicode_minus':False,'axes.linewidth':.65})
W,H=190,255;DPI=600;INK='#26333D';GRAY='#64747D';COL={'unet':'#3874A6','deeplab':'#D58B45','segformer':'#4C8A7E'};NAMES={'unet':'U-Net','deeplab':'DeepLabV3+','segformer':'SegFormer-B0'}
MODELS=list(NAMES);metrics={x['model_key']:x for x in json.loads((EV/'V35_metrics.json').read_text())};pairs=list(csv.DictReader((EV/'V35_root_length_pairs.csv').open(encoding='utf-8-sig')));rocs=np.load(EV/'ROC_exact_coordinates.npz')
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
def ftext(x,y,s,size=8,ha='left',bold=False,color=INK):return fig.text(x/W,1-y/H,s,fontsize=size,ha=ha,va='center',fontweight='bold' if bold else 'normal',color=color)
def axes(x,y,w,h):return fig.add_axes([x/W,1-(y+h)/H,w/W,h/H])
def panel(y,letter,title,x=4.7):ftext(x,y,letter,10.5,bold=True);ftext(x+6.3,y,title,9,bold=True)
def imgax(x,y,w,h,im):
 ax=axes(x,y,w,h);ax.imshow(im,interpolation='nearest',aspect='equal');ax.set_axis_off();return ax
def style(ax):
 ax.spines[['top','right']].set_visible(False);ax.spines[['bottom','left']].set_color('#8A969D');ax.tick_params(labelsize=7.2,width=.6,length=2,color='#8A969D');ax.grid(axis='y',color='#EEF1F3',lw=.5);ax.set_axisbelow(True)
ftext(4.7,2.6,'V35 · 24 held-out tile-date views from six spatial positions',6.8,color=GRAY)
columns=['Original RGB','Reference','U-Net','DeepLabV3+','SegFormer-B0'];x0=14;gap=1.5;cw=(169-4*gap)/5;data={}
for t in ['T1','T2','T3','T4']:
 rgb=np.array(Image.open(ASSETS/f'data/upper/{t}_RGB.png').convert('RGB'));paths=[ASSETS/f'data/upper/{t}_mask.png']+[FROZEN/m/'upper'/f'{t}_root_mask.png' for m in MODELS];images=[rgb]
 for p in paths:
  mask=np.array(Image.open(p));assert mask.shape==rgb.shape[:2] and set(np.unique(mask)).issubset({0,255});im=rgb.copy();im[mask==0]=255;assert np.array_equal(im[mask>0],rgb[mask>0]);images.append(im)
 data[t]=images
panel(8,'a','Full-field root segmentation across four observation stages')
for k,lab in enumerate(columns):ftext(x0+k*(cw+gap)+cw/2,14,lab,8,ha='center',color=COL[MODELS[k-2]] if k>=2 else INK)
for i,t in enumerate(['T1','T2','T3','T4']):
 hh=cw*1108/2541;yy=18+i*(hh+1.3);ftext(10.7,yy+hh/2,t,8.4,ha='right',bold=True)
 for k,im in enumerate(data[t]):
  ax=imgax(x0+k*(cw+gap),yy,cw,hh,im)
  if k==0:ax.plot([120,620],[1020,1020],color='white',lw=1.6);ax.text(370,945,'500 px',fontsize=6.2,color='white',ha='center')
  if t in ['T2','T4']:
   ax.add_patch(Rectangle((1428,916),256,128,fc='none',ec='#C5A055',lw=.65))
   if k==0:ax.text(1428,875,'i' if t=='T2' else 'ii',fontsize=6.2,color='#F4D89E',fontweight='bold')
panel(84,'b','Matched local details at the same native coordinates')
for k,lab in enumerate(columns):ftext(x0+k*(cw+gap)+cw/2,90,lab,8,ha='center',color=COL[MODELS[k-2]] if k>=2 else INK)
for i,t in enumerate(['T2','T4']):
 yy=94+i*(cw/2+3);ftext(10.7,yy+cw/4,'i  T2' if i==0 else 'ii  T4',8,ha='right',bold=True)
 for k,im in enumerate(data[t]):
  crop=im[916:1044,1428:1684];assert crop.shape==(128,256,3);ax=imgax(x0+k*(cw+gap),yy,cw,cw/2,crop)
  if k==0:ax.plot([16,66],[112,112],color='white',lw=1.5);ax.text(41,97,'50 px',fontsize=6.2,color='white',ha='center')
# Pooled, foreground-specific metrics from the exact V35 test probabilities.
panel(136,'c','Foreground segmentation performance')
for j,m in enumerate(MODELS):
 xx=25+j*29;fig.add_artist(plt.Line2D([(xx-4)/W,(xx-1)/W],[1-142/H,1-142/H],transform=fig.transFigure,color=COL[m],lw=1.8));ftext(xx,142,NAMES[m],7.8)
ax=axes(23,148,88,34);style(ax);labels=['Dice','IoU','Precision','Recall'];xx=np.arange(4)
for j,m in enumerate(MODELS):
 vals=[metrics[m][k] for k in labels];pos=xx+(j-1)*.24;ax.bar(pos,vals,width=.205,color=COL[m],alpha=.9,zorder=3)
 for x,y in zip(pos,vals):ax.text(x,y+.018,f'{y:.3f}',fontsize=6.3,color=COL[m],ha='center',va='bottom')
ax.set(xlim=(-.55,3.55),ylim=(0,1.03));ax.set_xticks(xx,labels);ax.set_yticks([0,.5,1]);ax.set_ylabel('Score',fontsize=7.5)
# Exact AUC values; dense monotonic resampling is for plot export only.
panel(136,'d','ROC discrimination',124)
ax=axes(136,145,40,40);style(ax);ax.grid(False);ax.plot([0,1],[0,1],ls='--',color='#B7C0C6',lw=.7)
roc_render_checks={}
for m,ls in zip(MODELS,['-','--','-.']):
 fpr=rocs[m+'_FPR'];tpr=rocs[m+'_TPR'];grid=np.unique(np.r_[0,np.geomspace(1e-8,.01,201),np.linspace(.01,1,10001)]);yy=np.interp(grid,fpr,tpr);gx=np.r_[0,grid];gy=np.r_[0,yy]
 error=abs(np.trapezoid(gy,gx)-metrics[m]['AUC']);assert error<1e-4;roc_render_checks[m]={'AUC_render_error':float(error),'rendered_points':len(gx),'exact_AUC':metrics[m]['AUC']}
 ax.plot(gx,gy,color=COL[m],lw=1.1,ls=ls,label=f'{NAMES[m]}  {metrics[m]["AUC"]:.3f}')
ax.set(xlim=(0,1),ylim=(0,1.015));ax.set_xticks([0,.5,1]);ax.set_yticks([0,.5,1]);ax.set_xlabel('False-positive rate',fontsize=7.5,labelpad=2);ax.set_ylabel('True-positive rate',fontsize=7.5,labelpad=2);ax.legend(loc='lower right',frameon=False,fontsize=6.2,handlelength=1.2,labelspacing=.45,borderaxespad=.2)
# Root-length errors are derived from the same 24 matched test views, no OLS fit.
panel(198,'e','Root-length agreement on the common held-out set')
markers={'T1':'o','T2':'s','T3':'^','T4':'D'}
for j,(t,marker) in enumerate(markers.items()):
 axleg=axes(140+j*10,196.6,2.2,2.2);axleg.scatter([.5],[.5],s=10,marker=marker,color=GRAY);axleg.set_axis_off();ftext(142.8+j*10,198,t,6.7,color=GRAY)
limit=3500
for i,m in enumerate(MODELS):
 xx=23+i*56;ftext(xx+18.5,204,NAMES[m],8,ha='center',bold=True,color=COL[m]);ax=axes(xx,209,37,36);style(ax);ax.grid(False)
 ax.set(xlim=(0,limit),ylim=(0,limit));ax.plot([0,limit],[0,limit],ls='--',color='#AEB7BE',lw=.7,zorder=1)
 rows=[p for p in pairs if p['model']==m];assert len(rows)==24
 for t,marker in markers.items():
  z=[p for p in rows if p['period']==t];assert len(z)==6
  ax.scatter([float(p['reference_length_px']) for p in z],[float(p['predicted_length_px']) for p in z],s=13,marker=marker,color=COL[m],alpha=.85,edgecolors='white',linewidths=.25,zorder=3)
 ax.set_xticks([0,1500,3000]);ax.set_yticks([0,1500,3000]);ax.tick_params(labelsize=6.4);ax.set_xlabel('Reference length (px)',fontsize=7.1,labelpad=2)
 if i==0:ax.set_ylabel('Predicted length (px)',fontsize=7.1,labelpad=2)
 else:ax.set_yticklabels([])
 q=metrics[m];stat=(rf'$R^2_{{y=x}}={q["R2_identity"]:.3f}$'+'\n'+f'MAE = {q["MAE_px"]:.1f} px\nRMSE = {q["RMSE_px"]:.1f} px')
 ax.text(.045,.965,stat,ha='left',va='top',transform=ax.transAxes,fontsize=6.5,color=INK,linespacing=1.25,bbox=dict(fc='white',ec='none',alpha=.86,pad=.5),zorder=4)
for ext in ['png','pdf','svg']:fig.savefig(OUT/f'V35_root_segmentation_combined.{ext}',dpi=DPI,facecolor='white')
fig.savefig(OUT/'V35_root_segmentation_combined.tiff',dpi=DPI,facecolor='white',pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)
im=Image.open(OUT/'V35_root_segmentation_combined.png').convert('RGB');im.save(OUT/'V35_root_segmentation_combined.jpg','JPEG',quality=98,subsampling=0,optimize=True,dpi=(DPI,DPI))
for p in OUT.glob('*.svg'):p.write_text(p.read_text().replace("font-family: 'Liberation Sans'","font-family: Arial, 'Liberation Sans', Helvetica, sans-serif"))
(ROOT/'evaluation/ROC_render_checks.json').write_text(json.dumps(roc_render_checks,indent=2))
print('Rendered populated V35 figure: PNG / JPG / PDF / SVG / TIFF')
