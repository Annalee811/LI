from pathlib import Path
import csv,json,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
from matplotlib.lines import Line2D
ROOT=Path('/workspace/work/V66_V90_boxplots_20261105');META=Path('/workspace/work/materials_methods_20261103/sources');V90=Path('/workspace/work/V90_class_accuracy_20261105');V66=Path('/workspace/work/V66_V90_comparison_20261105/V66_unet')
meta_path=META/'asset_metadata/03_temporal_V66/assets/spatial_manifest.csv';manifest=json.loads((META/'core/resources/03_temporal_V66/manifest.json').read_text());entry=next(x for x in manifest['files'] if x['file']=='assets/spatial_manifest.csv');assert hashlib.sha256(meta_path.read_bytes()).hexdigest()==entry['sha256']
windows=[r for r in csv.DictReader(meta_path.open(encoding='utf-8-sig')) if r['split']=='test'];assert len(windows)==6
# Verify all original evaluation maps against the immutable source manifests.
checks=[]
for stage,prefix,base in [('03_temporal_V66','assets/evaluation_reference',V90/'sources/03_temporal_V66/assets/evaluation_reference'),('03_temporal_V66','assets/expected/unet',V66),('04_ConvLSTM_GAT_V90','assets/expected',V90/'sources/04_ConvLSTM_GAT_V90/assets/expected')]:
 man=json.loads((META/'core/resources'/stage/'manifest.json').read_text());lookup={x['file']:x for x in man['files']}
 for t in ['T2','T3','T4']:
  p=base/f'{t}_classes.png';sha=hashlib.sha256(p.read_bytes()).hexdigest();assert sha==lookup[f'{prefix}/{t}_classes.png']['sha256'];checks.append(dict(stage=stage,file=f'{prefix}/{t}_classes.png',sha256=sha))
refs={t:np.array(Image.open(V90/f'sources/03_temporal_V66/assets/evaluation_reference/{t}_classes.png')) for t in ['T2','T3','T4']}
preds={m:{t:np.array(Image.open((V66 if m=='V66 U-Net' else V90/'sources/04_ConvLSTM_GAT_V90/assets/expected')/f'{t}_classes.png')) for t in refs} for m in ['V66 U-Net','V90 reviewed']}
classes=[(2,'Newly observed','新生根'),(3,'Extending','延伸根'),(1,'Persistent','持续根')];rows=[];cms={}
for w in windows:
 x,y,ww,hh=map(int,[w['x'],w['y'],w['width'],w['height']])
 for m in preds:
  cm=np.zeros((3,4),np.int64)
  for t,g in refs.items():
   gt=g[y:y+hh,x:x+ww];p=preds[m][t][y:y+hh,x:x+ww];use=np.isin(gt,[1,2,3]);assert np.isin(p[use],[0,1,2,3]).all();z=np.where(p[use]==0,3,p[use]-1);cm+=np.bincount((gt[use].astype(np.int64)-1)*4+z,minlength=12).reshape(3,4)
  cms[w['tile_id']+' / '+m]=cm.tolist()
  for c,en,cn in classes:
   k=c-1;tp=int(cm[k,k]);fp=int(cm[:,k].sum()-tp);fn=int(cm[k].sum()-tp);support=int(cm[k].sum());assert support>0
   rows.append(dict(Window=w['tile_id'],x=x,y=y,width=ww,height=hh,Periods='T2–T4 pooled',Model=m,Class=en,Class_CN=cn,Reference_pixels=support,TP=tp,FP=fp,FN=fn,Precision=tp/(tp+fp) if tp+fp else 0.,Recall=tp/(tp+fn),Dice=2*tp/(2*tp+fp+fn),IoU=tp/(tp+fp+fn)))
with (ROOT/'V66_V90_window_metrics.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Six matched windows, with stages pooled before calculating the four metrics.
plt.rcParams.update({'font.family':'Liberation Sans','font.size':8,'pdf.fonttype':42,'svg.fonttype':'none','axes.unicode_minus':False,'axes.linewidth':.7,'mathtext.fontset':'dejavusans'})
COLORS=['#4B9F90','#D2A04E'];HEADERS=['#8F6E64','#AD8577','#927783','#A28D6C'];MODELS=['V66 U-Net','V90 reviewed'];METRICS=['Precision','Recall','Dice','IoU'];LABELS=['New','Extending','Persistent'];stats=[]
fig,axs=plt.subplots(1,4,figsize=(8.2,3.12));fig.subplots_adjust(left=.065,right=.988,bottom=.25,top=.79,wspace=.16)
jitter=np.array([-.055,-.03,-.01,.015,.035,.06]);centers=[.95,3.35,5.75];half=.32
for q,(ax,metric) in enumerate(zip(axs,METRICS)):
 ax.add_patch(Rectangle((0,1.035),1,.14,transform=ax.transAxes,fc=HEADERS[q],ec='none',clip_on=False))
 ax.text(.5,1.105,metric,transform=ax.transAxes,ha='center',va='center',fontsize=9,color='white',fontweight='bold')
 ax.text(-.075,1.20,'abcd'[q],transform=ax.transAxes,fontsize=10.5,fontweight='bold',color='#26333D')
 for c,(code,en,cn) in enumerate(classes):
  vals=[]
  for m in MODELS:
   a=[next(r[metric] for r in rows if r['Window']==w['tile_id'] and r['Model']==m and r['Class']==en) for w in windows];vals.append(np.array(a))
   stats.append(dict(Metric=metric,Class=en,Model=m,n=len(a),median=float(np.median(a)),Q1=float(np.percentile(a,25)),Q3=float(np.percentile(a,75)),minimum=min(a),maximum=max(a)))
  pos=[centers[c]-half,centers[c]+half]
  bp=ax.boxplot(vals,positions=pos,widths=.49,patch_artist=True,showfliers=False,whis=1.5,medianprops=dict(color='#25313B',linewidth=1.1),boxprops=dict(linewidth=.85,color='#37424B'),whiskerprops=dict(linewidth=.75,color='#37424B'),capprops=dict(linewidth=.75,color='#37424B'),manage_ticks=False)
  for b,col in zip(bp['boxes'],COLORS):b.set_facecolor(col);b.set_alpha(.82)
  for i in range(6):
   xp=np.array(pos)+jitter[i]
   ax.plot(xp,[vals[0][i],vals[1][i]],color='#626D76',lw=.55,ls=(0,(1.2,1.8)),alpha=.72,zorder=3)
   ax.scatter(xp,[vals[0][i],vals[1][i]],s=5.5,color='#20262B',alpha=.9,linewidths=0,zorder=4)
  by=1.04;ax.plot([pos[0]-.08,pos[0]-.08,pos[1]+.08,pos[1]+.08],[by-.018,by,by,by-.018],color='#38434C',lw=.65)
  ax.text(centers[c],by+.025,'n = 6',ha='center',va='bottom',fontsize=6.4,color='#424D56')
 ax.set(xlim=(.1,6.6),ylim=(-.045,1.145));ax.set_xticks(centers,LABELS);ax.tick_params(axis='x',labelsize=6.7,length=0,pad=5);ax.tick_params(axis='y',labelsize=7,length=2.5,width=.65)
 ax.set_yticks([0,.25,.5,.75,1]);ax.set_yticklabels(['0','0.25','0.50','0.75','1.00']);ax.spines[['top','right']].set_visible(False);ax.spines[['bottom','left']].set_color('#7B858C')
 if q==0:ax.set_ylabel('Pixel-level score',fontsize=8,labelpad=4)
 else:ax.set_yticklabels([])
 ax.axhline(0,color='#EEF0F2',lw=.5,zorder=0)
fig.legend(handles=[Patch(fc=COLORS[0],ec='#37424B',label='V66 U-Net'),Patch(fc=COLORS[1],ec='#37424B',label='V90 reviewed'),Line2D([0],[0],color='#626D76',ls=(0,(1.2,1.8)),marker='o',markersize=2.2,lw=.6,label='Matched spatial window')],loc='lower center',bbox_to_anchor=(.53,.088),ncol=3,frameon=False,fontsize=7.4,handlelength=1.6,columnspacing=2.3)
fig.text(.53,.047,'Six fixed paired windows; T2–T4 pooled within each window',ha='center',va='center',fontsize=7.1,color='#68757E')
for ext in ['png','pdf','svg']:fig.savefig(ROOT/f'V66_V90_paired_boxplots.{ext}',dpi=600,facecolor='white')
fig.savefig(ROOT/'V66_V90_paired_boxplots.tiff',dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
im=Image.open(ROOT/'V66_V90_paired_boxplots.png').convert('RGB');im.save(ROOT/'V66_V90_paired_boxplots.jpg','JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
for p in ROOT.glob('*.svg'):p.write_text(p.read_text().replace("font-family: 'Liberation Sans'","font-family: Arial, 'Liberation Sans', Helvetica, sans-serif"))
with (ROOT/'V66_V90_boxplot_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(stats[0]));w.writeheader();w.writerows(stats)
(ROOT/'provenance.json').write_text(json.dumps({'reference':'T2–T4 common frozen B','source_commit':'4615bcbd37442a3b11e5ad4533242df95f237fb6','window_selection':'All six archived V35/V66 spatial hold-out windows, coordinates applied unchanged to both full-map workflows. No independent V90 test-split claim is made.','windows':windows,'evaluation_unit':'Spatial window; TP/FP/FN pooled over T2–T4 before each metric. n=6 pairs per class/metric. All classes have positive reference support in all windows.','zero_division_precision':'0 when no positives were predicted in a window with positive reference support','confidence_and_tests':'Descriptive within-development-position comparison. No inferential p-values or biological-replication claim.','difference_from_prior_table':'Prior table pools all 468203 reference-root pixels. This boxplot describes distributions within six fixed windows; medians/means need not equal pooled full-field metrics.','plot':'Box = Q1–Q3, line = median, whiskers = 1.5 IQR, all original observations plotted, matching windows connected by dotted segments. No synthetic replicates.','V90_scope':'Final learned/structured/manually reviewed workflow; reference includes U-Net-assisted foreground outlines.','source_files':checks,'confusion_by_window':cms},ensure_ascii=False,indent=2))
print('n=6 pairs for each class and metric; support per window:',[(w['tile_id'],[next(r['Reference_pixels'] for r in rows if r['Window']==w['tile_id'] and r['Class']==en and r['Model']==MODELS[0]) for _,en,_ in classes]) for w in windows])
for k in ['Dice','IoU']:print(k,[(r['Class'],r['Model'],round(r['median'],4)) for r in stats if r['Metric']==k])
