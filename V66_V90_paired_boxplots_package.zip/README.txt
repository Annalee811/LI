V66 U-Net / V90 reviewed paired boxplots

JPG/PNG/TIFF: 600 dpi. PDF and SVG: vector graphics. SVG text remains editable. Source code, exact TP/FP/FN counts, all per-window metrics, boxplot summaries and bilingual caption are included.

Sampling unit: one fixed 256×256 spatial window. Counts are first pooled within T2–T4, reducing repeated-stage pseudoreplication. Six pre-existing windows are used without performance-based selection: P16, P22, P23, P28, P30 and P33. The same coordinates and frozen reference B are used for both workflows. These are descriptive paired windows from one development position, not six independent plants or tubes. No inferential P values are attached; n=6 is shown instead.

The window index is the archived V35/V66 spatial hold-out index. Applying it to V90 is a matched descriptive comparison and does not by itself establish that these are independent V90 held-out cases. The figure should not be labelled as an independent cross-tube test.

The earlier table pooled the entire 468,203-pixel reference-root region; this plot describes six subregions and their medians/quartiles. Its values are not supposed to equal the whole-field pooled table. All black points are actual window metrics; dotted lines connect matched cases. No values are repeated to manufacture sample size, and no synthetic P values are used.

V90 is the final learned/structured/manually reviewed workflow. The revised reference includes U-Net-assisted outlines. Model differences do not isolate a single network module contribution.
