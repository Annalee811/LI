"""Verify sources, fixed ROI, class colors, metric values and publication exports."""
from pathlib import Path
import json,hashlib,csv
import numpy as np
from PIL import Image
import fitz
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'figure_manifest.json').read_text())
roi=json.loads((ROOT/'roi_manifest.json').read_text())
src=json.loads((ROOT/'source_comparison.json').read_text())
source_verification=json.loads((ROOT/'source_verification.json').read_text())
for r in source_verification['checks']:assert hashlib.sha256((ROOT/r['file']).read_bytes()).hexdigest()==r['sha256']
assert not manifest['full_field_panels']
assert manifest['same_ROI_all_four_periods']
assert len(manifest['crop_records'])==4
assert {tuple(r['ROI_xyxy']) for r in manifest['crop_records']}=={tuple(roi['ROI_xyxy'])}
colors={int(c):np.array([int(v[i:i+2],16) for i in (1,3,5)],dtype=np.uint8) for c,v in manifest['colors'].items()}
x0,y0,x1,y1=roi['ROI_xyxy']
for record in manifest['crop_records']:
 t=record['period'];dest=ROOT/'exact_crops'/t
 rgb=np.array(Image.open(dest/'Original_RGB.png').convert('RGB'))
 assert rgb.shape==(320,420,3)
 original=np.array(Image.open(ROOT/f'sources/RGB/{t}_RGB.png').convert('RGB'))[y0:y1,x0:x1]
 assert np.array_equal(rgb,original)
 assert hashlib.sha256(rgb.tobytes()).hexdigest()==record['RGB_array_sha256']
 for group in ['reference','V66','V90']:
  labels=np.array(Image.open(dest/(group+'_labels.png')))
  original_labels=np.array(Image.open(ROOT/f'sources/{group}/{t}_classes.png'))[y0:y1,x0:x1]
  assert np.array_equal(labels,original_labels)
  assert hashlib.sha256(labels.tobytes()).hexdigest()==record['label_array_sha256'][group]
  expected=rgb.copy()
  for code,color in colors.items():expected[labels==code]=color
  overlay=np.array(Image.open(dest/(group+'_RGB_overlay.png')))
  assert np.array_equal(overlay,expected)
  assert np.array_equal(overlay[labels==0],rgb[labels==0])
with (ROOT/'plotted_metrics.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
assert len(rows)==24
for row in rows:
 entry=next(r for r in src['per_class'] if r['class_code']==int(row['class_code']) and r['model']=={'V66':'V66 U-Net','V90':'V90 reviewed'}[row['workflow']])
 assert abs(float(row['score_percent'])/100-entry[row['metric']])<1e-12
for workflow,conf in manifest['verified_full_field_confusion'].items():
 assert np.array_equal(conf,src['confusion'][workflow])
 assert np.array(conf).sum()==468203
stem='V66_V90_performance_same_field_T1-T4_SCI'
with fitz.open(ROOT/(stem+'.pdf')) as doc:
 assert len(doc)==1
 fonts={r[3].split('+')[-1] for r in doc[0].get_fonts()}
 assert fonts=={'TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'}
 spans=[s for b in doc[0].get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
 assert all(s['color']==0 for s in spans)
 assert min(s['size'] for s in spans)>=8.49
 for s in spans:
  r=fitz.Rect(s['bbox']);assert r.x0>=0 and r.x1<=doc[0].rect.width and r.y0>=0 and r.y1<=doc[0].rect.height
 font_range=[min(s['size'] for s in spans),max(s['size'] for s in spans)]
exports={}
for ext in ['png','jpg','tiff']:
 with Image.open(ROOT/(stem+'.'+ext)) as im:
  assert im.width==4500 and abs(im.height-round(244/25.4*600))<=1
  assert im.convert('RGB').getpixel((0,0))==(255,255,255)
  exports[ext]={'pixels':list(im.size),'dpi':[float(d) for d in im.info.get('dpi',(0,0))]}
report={'source_hashes_verified':16,'fixed_ROI_xyxy':roi['ROI_xyxy'],'four_periods_same_registered_coordinates':True,'crop_pixels':[420,320],'full_field_panels':False,'exact_original_RGB_and_class_arrays':True,'background_RGB_unchanged_in_lossless_overlays':True,'plotted_scores_verified':24,'archived_pooled_confusion_rechecked':True,'evaluated_root_pixels':468203,'T1_in_temporal_metrics':False,'PDF_pages':1,'fonts':sorted(fonts),'text_color':'black','font_range_pt':font_range,'all_text_within_page':True,'exports':exports,'new_training_registration_or_inference':False}
(ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
