"""Paired V66/V90 performance and four-period same-field original-RGB overlays."""
from pathlib import Path
import argparse,json,csv,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,patheffects
from matplotlib.patches import Patch
from matplotlib.text import Text
import fitz

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--fonts-dir',type=Path,required=True)
args=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(args.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':9,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'svg.fonttype':'none','axes.linewidth':.6})
source=json.loads((ROOT/'source_comparison.json').read_text())
verification=json.loads((ROOT/'source_verification.json').read_text())
roi=json.loads((ROOT/'roi_manifest.json').read_text())
x0,y0,x1,y1=roi['ROI_xyxy']
for r in verification['checks']:assert hashlib.sha256((ROOT/r['file']).read_bytes()).hexdigest()==r['sha256']

# Recheck the archived pooled comparison from the unchanged full-field maps.
confusion={}
for group,key in [('V66','V66 U-Net'),('V90','V90 reviewed')]:
 conf=np.zeros((3,4),np.int64)
 for t in ['T2','T3','T4']:
  ref=np.array(Image.open(ROOT/f'sources/reference/{t}_classes.png'))
  pred=np.array(Image.open(ROOT/f'sources/{group}/{t}_classes.png'))
  valid=(ref>=1)&(ref<=3)
  rr=ref[valid].astype(int)-1;pp=pred[valid].astype(int)
  cc=np.where((pp>=1)&(pp<=3),pp-1,3)
  conf+=np.bincount(rr*4+cc,minlength=12).reshape(3,4)
 assert np.array_equal(conf,np.array(source['confusion'][key]))
 assert conf.sum()==468203
 for row in source['per_class']:
  if row['model']!=key:continue
  c=row['class_code']-1;tp=int(conf[c,c]);fp=int(conf[:,c].sum()-tp);fn=int(conf[c,:].sum()-tp)
  assert (tp,fp,fn)==(row['TP'],row['FP'],row['FN'])
  for metric,value in [('Precision',tp/(tp+fp)),('Recall',tp/(tp+fn)),('Dice',2*tp/(2*tp+fp+fn)),('IoU',tp/(tp+fp+fn))]:assert abs(value-row[metric])<1e-12
 confusion[key]=conf.tolist()

# Muted coral, jade and slate blue, consistent in plots and actual label overlays.
COLORS={1:'#5B76A4',2:'#D97B66',3:'#65A69A',4:'#FFFFFF',255:'#A7A7A7'}
NAMES={1:'Persistent',2:'Newly emerged',3:'Elongating',4:'T1 baseline',255:'Ignored reference'}
RGB_COLORS={code:(np.array(matplotlib.colors.to_rgb(color))*255).round().astype(np.uint8) for code,color in COLORS.items()}
def overlay(rgb,labels):
 out=rgb.copy()
 for code,color in RGB_COLORS.items():out[labels==code]=color
 assert np.array_equal(out[labels==0],rgb[labels==0])
 return out

W,H=190.5,244
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
def txt(x,y,s,size=9,ha='left',bold=False,rotation=0):
 return fig.text(x/W,1-y/H,s,fontsize=size,ha=ha,va='center',color='black',fontweight='bold' if bold else 'normal',rotation=rotation)
txt(3,4.8,'A',12,bold=True);txt(11,4.8,'Class-wise performance (%)',11.5,bold=True)
fig.legend(handles=[Patch(fc='#D5D9DF',ec='none',label='V66 U-Net'),Patch(fc='#677486',ec='none',label='V90 reviewed')],loc='center',bbox_to_anchor=(.765,1-5/H),ncol=2,frameon=False,fontsize=9,handlelength=1.2,columnspacing=1.6)
metrics=['Precision','Recall','Dice','IoU'];values=[]
for j,(code,row) in enumerate(zip([2,3,1],source['classes'])):
 left=18+j*61;cw=44.5;center=left+cw/2
 txt(center,14,NAMES[code]+' roots',10.5,ha='center',bold=True)
 fig.add_artist(plt.Line2D([(center-9)/W,(center+9)/W],[1-17/H,1-17/H],color=COLORS[code],lw=1.5,solid_capstyle='round',transform=fig.transFigure))
 ax=fig.add_axes([left/W,1-(20+36)/H,cw/W,36/H])
 ys=np.arange(4)[::-1];a=np.array([100*row['V66_'+m] for m in metrics]);b=np.array([100*row['V90_'+m] for m in metrics])
 pale=.3*np.array(matplotlib.colors.to_rgb(COLORS[code]))+.7
 ax.barh(ys+.165,a,height=.255,color=pale,edgecolor='none',zorder=3)
 ax.barh(ys-.165,b,height=.255,color=COLORS[code],edgecolor='none',zorder=3)
 for vals,offset,prefix in [(a,.165,'V66'),(b,-.165,'V90')]:
  for y,val,metric in zip(ys,vals,metrics):
   ax.text(val+1.6,y+offset,f'{val:.1f}',ha='left',va='center',fontsize=8.5,fontweight='bold' if metric=='Dice' else 'normal',color='black',zorder=5)
   values.append({'class_code':code,'class':NAMES[code],'workflow':prefix,'metric':metric,'score_percent':float(val)})
 ax.set(xlim=(0,118),ylim=(-.6,3.6));ax.set_yticks(ys,metrics);ax.set_xticks([0,50,100]);ax.tick_params(axis='both',labelsize=8.5,length=2,width=.5,pad=2)
 ax.xaxis.grid(True,color='#E8EBEE',lw=.5,zorder=0);ax.set_axisbelow(True)
 ax.spines[['top','right','left']].set_visible(False)
 ax.spines['bottom'].set_color('#9AA3AB');ax.spines['bottom'].set_linewidth(.5)
 ax.tick_params(axis='y',length=0)
 for tick in ax.get_yticklabels():
  if tick.get_text()=='Dice':tick.set_fontweight('bold')
 txt(center,64.5,f'Dice +{row["Dice_delta_pp"]:.2f} pp',9,ha='center')
macro0=100*source['summaries']['V66 U-Net']['macro']['Dice'];macro1=100*source['summaries']['V90 reviewed']['macro']['Dice']
txt(98,70.3,f'Macro Dice: {macro0:.2f}% → {macro1:.2f}%    |    T2–T4 pooled',9.5,ha='center',bold=True)
fig.add_artist(plt.Line2D([3/W,187/W],[1-74/H,1-74/H],color='#D6DADD',lw=.6,transform=fig.transFigure))

txt(3,79.2,'B',12,bold=True);txt(11,79.2,'Same-field temporal comparison on original RGB',11.5,bold=True)
txt(98,84.7,'0353-2-B3 · identical 420 × 320 px registered ROI across T1–T4',9,ha='center')
LEFT,CW,GAP=13.5,41.5,2
PH=CW*(y1-y0)/(x1-x0)
for j,s in enumerate(['Original RGB','Reference','V66 U-Net','V90 reviewed']):txt(LEFT+j*(CW+GAP)+CW/2,90.4,s,9.5,ha='center',bold=True)
crop_records=[]
for i,t in enumerate(['T1','T2','T3','T4']):
 yy=94+i*(PH+2)
 txt(6,yy+PH/2,t,10,ha='center',bold=True)
 rgb=np.array(Image.open(ROOT/f'sources/RGB/{t}_RGB.png').convert('RGB'))[y0:y1,x0:x1].copy()
 labels={g:np.array(Image.open(ROOT/f'sources/{g}/{t}_classes.png'))[y0:y1,x0:x1].copy() for g in ['reference','V66','V90']}
 images=[rgb]+[overlay(rgb,labels[g]) for g in ['reference','V66','V90']]
 dest=ROOT/'exact_crops'/t;dest.mkdir(parents=True,exist_ok=True)
 Image.fromarray(rgb).save(dest/'Original_RGB.png')
 for g in labels:
  Image.fromarray(labels[g]).save(dest/(g+'_labels.png'))
  Image.fromarray(overlay(rgb,labels[g])).save(dest/(g+'_RGB_overlay.png'))
 for j,im in enumerate(images):
  ax=fig.add_axes([(LEFT+j*(CW+GAP))/W,1-(yy+PH)/H,CW/W,PH/H])
  ax.imshow(im,interpolation='nearest');ax.set(xlim=(-.5,419.5),ylim=(319.5,-.5));ax.set_xticks([]);ax.set_yticks([])
  for spine in ax.spines.values():spine.set_color('#5D6266');spine.set_linewidth(.4)
  if j==0:
   line,=ax.plot([16,116],[304,304],color='white',lw=1.6,solid_capstyle='butt')
   line.set_path_effects([patheffects.Stroke(linewidth=2.5,foreground='black'),patheffects.Normal()])
   ax.text(66,286,'100 px',fontsize=8.5,ha='center',va='bottom',color='black',bbox={'fc':'white','ec':'none','pad':.5})
 crop_records.append({'period':t,'ROI_xyxy':[x0,y0,x1,y1],'shape':list(rgb.shape),'RGB_array_sha256':hashlib.sha256(rgb.tobytes()).hexdigest(),'label_array_sha256':{g:hashlib.sha256(a.tobytes()).hexdigest() for g,a in labels.items()},'reference_class_counts':{str(int(c)):int((labels['reference']==c).sum()) for c in np.unique(labels['reference'])}})

legend=[Patch(fc=COLORS[c],ec='#777777' if c==4 else 'none',label=NAMES[c]) for c in [2,3,1,4,255]]
fig.legend(handles=legend,loc='center',bbox_to_anchor=(.52,1-233.1/H),ncol=5,frameon=False,fontsize=8.5,handlelength=1.1,columnspacing=1.25)
txt(98,239.5,'T1 is baseline; temporal-class metrics use T2–T4. Scale bars: 100 px.',8.5,ha='center')
for obj in fig.findobj(match=Text):obj.set_fontfamily('Times New Roman');obj.set_color('black')
stem='V66_V90_performance_same_field_T1-T4_SCI'
for ext in ['png','pdf']:fig.savefig(ROOT/(stem+'.'+ext),dpi=600,facecolor='white')
fig.savefig(ROOT/(stem+'.tiff'),dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)
Image.open(ROOT/(stem+'.png')).convert('RGB').save(ROOT/(stem+'.jpg'),'JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
with (ROOT/'plotted_metrics.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(values[0]));w.writeheader();w.writerows(values)
(ROOT/'figure_manifest.json').write_text(json.dumps({'figure_mm':[W,H],'raster_dpi':600,'color_scheme':'Muted coral / jade / slate blue','plot_style':'Slim paired bars, pale V66 and saturated V90, no outlines, Dice emphasized','colors':{str(c):v for c,v in COLORS.items()},'class_names':{str(c):n for c,n in NAMES.items()},'metric_scope':'T2–T4, typed root pixels only, common frozen reference B, 468203 pixels; development-position workflow agreement','model_names':{'V66':'V66 U-Net','V90':'Final learned/structural/manually reviewed V90 workflow'},'T1':'Baseline only; excluded from temporal scores','full_field_panels':False,'same_ROI_all_four_periods':True,'crop_records':crop_records,'verified_full_field_confusion':confusion,'macro_Dice_percent':[macro0,macro1],'overlay':'Exact foreground palette replacement only; background RGB unchanged; no dilation, smoothing or new registration/inference.'},indent=2)+'\n')
with fitz.open(ROOT/(stem+'.pdf')) as doc:doc[0].get_pixmap(matrix=fitz.Matrix(1.7,1.7),alpha=False).save(ROOT/'preview.png')
print('Created three-class performance comparison and matched T1–T4 original-RGB local overlays.')
