from pathlib import Path
import csv,json,shutil,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
from matplotlib.lines import Line2D
from matplotlib.text import Text
from matplotlib import font_manager
ROOT=Path('/workspace/work/V66_V90_boxplots_TimesNewRoman_20261105')
OLD=Path('/workspace/work/V66_V90_boxplots_20261105')
for name in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(ROOT/'fonts'/name))
assert font_manager.FontProperties(fname=ROOT/'fonts/Times New Roman.ttf').get_name()=='Times New Roman'
rows=list(csv.DictReader((OLD/'V66_V90_window_metrics.csv').open(encoding='utf-8-sig')))
for r in rows:
 for k in ['Precision','Recall','Dice','IoU']:r[k]=float(r[k])
windows=json.loads((OLD/'provenance.json').read_text())['windows']
classes=[(2,'Newly observed','新生根'),(3,'Extending','延伸根'),(1,'Persistent','持续根')]
# Six matched windows, with stages pooled before calculating the four metrics.
plt.rcParams.update({'font.family':'Times New Roman','font.size':8.5,'pdf.fonttype':42,'svg.fonttype':'none','axes.unicode_minus':False,'axes.linewidth':.7,'mathtext.fontset':'dejavusans'})
COLORS=['#4B9F90','#D2A04E'];HEADERS=['#8F6E64','#AD8577','#927783','#A28D6C'];MODELS=['V66 U-Net','V90 reviewed'];METRICS=['Precision','Recall','Dice','IoU'];LABELS=['New','Extending','Persistent'];stats=[]
fig,axs=plt.subplots(1,4,figsize=(7.5,3.35));fig.subplots_adjust(left=.075,right=.992,bottom=.25,top=.79,wspace=.18)
jitter=np.array([-.055,-.03,-.01,.015,.035,.06]);centers=[.95,3.35,5.75];half=.32
for q,(ax,metric) in enumerate(zip(axs,METRICS)):
 ax.add_patch(Rectangle((0,1.035),1,.14,transform=ax.transAxes,fc=HEADERS[q],ec='none',clip_on=False))
 ax.text(.5,1.105,metric,transform=ax.transAxes,ha='center',va='center',fontsize=9.5,color='white',fontweight='bold')
 ax.text(-.075,1.20,'abcd'[q],transform=ax.transAxes,fontsize=11,fontweight='bold',color='#26333D')
 for c,(code,en,cn) in enumerate(classes):
  vals=[]
  for m in MODELS:
   a=[next(r[metric] for r in rows if r['Window']==w['tile_id'] and r['Model']==m and r['Class']==en) for w in windows];vals.append(np.array(a))
   stats.append(dict(Metric=metric,Class=en,Model=m,n=len(a),median=float(np.median(a)),Q1=float(np.percentile(a,25)),Q3=float(np.percentile(a,75)),minimum=min(a),maximum=max(a)))
  pos=[centers[c]-half,centers[c]+half]
  bp=ax.boxplot(vals,positions=pos,widths=.49,patch_artist=True,showfliers=False,whis=1.5,medianprops=dict(color='#25313B',linewidth=1.1),boxprops=dict(linewidth=.85,color='#37424B'),whiskerprops=dict(linewidth=.75,color='#37424B'),capprops=dict(linewidth=.75,color='#37424B'),manage_ticks=False)
  for b,col in zip(bp['boxes'],COLORS):b.set_facecolor(col);b.set_alpha(.82)
  for i in range(6):
   xp=np.array(pos)+jitter[i]
   ax.plot(xp,[vals[0][i],vals[1][i]],color='#626D76',lw=.55,ls=(0,(1.2,1.8)),alpha=.72,zorder=3)
   ax.scatter(xp,[vals[0][i],vals[1][i]],s=5.5,color='#20262B',alpha=.9,linewidths=0,zorder=4)
  by=1.04;ax.plot([pos[0]-.08,pos[0]-.08,pos[1]+.08,pos[1]+.08],[by-.018,by,by,by-.018],color='#38434C',lw=.65)
  ax.text(centers[c],by+.025,'n = 6',ha='center',va='bottom',fontsize=8,color='#424D56')
 ax.set(xlim=(.1,6.6),ylim=(-.045,1.145));ax.set_xticks(centers,LABELS);ax.tick_params(axis='x',labelsize=8,length=0,pad=5);ax.tick_params(axis='y',labelsize=8,length=2.5,width=.65)
 ax.set_yticks([0,.25,.5,.75,1]);ax.set_yticklabels(['0','0.25','0.50','0.75','1.00']);ax.spines[['top','right']].set_visible(False);ax.spines[['bottom','left']].set_color('#7B858C')
 if q==0:ax.set_ylabel('Pixel-level score',fontsize=9,labelpad=4)
 else:ax.set_yticklabels([])
 ax.axhline(0,color='#EEF0F2',lw=.5,zorder=0)
fig.legend(handles=[Patch(fc=COLORS[0],ec='#37424B',label='V66 U-Net'),Patch(fc=COLORS[1],ec='#37424B',label='V90 reviewed'),Line2D([0],[0],color='#626D76',ls=(0,(1.2,1.8)),marker='o',markersize=2.2,lw=.6,label='Matched spatial window')],loc='lower center',bbox_to_anchor=(.53,.088),ncol=3,frameon=False,fontsize=8.5,handlelength=1.6,columnspacing=2.3)
fig.text(.53,.047,'Six fixed paired windows; T2–T4 pooled within each window',ha='center',va='center',fontsize=8,color='#68757E')
# Every visible text item is black and uses the registered Times New Roman family.
for obj in fig.findobj(match=Text):
 obj.set_color('#000000');obj.set_fontfamily('Times New Roman')
 if obj.get_text() and obj.get_fontsize()<8:obj.set_fontsize(8)
for ext in ['png','pdf','svg']:
 fig.savefig(ROOT/f'V66_V90_boxplots_TimesNewRoman.{ext}',dpi=600,facecolor='white')
fig.savefig(ROOT/'V66_V90_boxplots_TimesNewRoman.tiff',dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)
im=Image.open(ROOT/'V66_V90_boxplots_TimesNewRoman.png').convert('RGB');im.save(ROOT/'V66_V90_boxplots_TimesNewRoman.jpg','JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
for name in ['V66_V90_window_metrics.csv','V66_V90_boxplot_summary.csv','V66_V90_boxplot_data.xlsx','Figure_caption_CN_EN.txt','provenance.json']:
 shutil.copy2(OLD/name,ROOT/name)
assert hashlib.sha256((OLD/'V66_V90_window_metrics.csv').read_bytes()).digest()==hashlib.sha256((ROOT/'V66_V90_window_metrics.csv').read_bytes()).digest()
print('Rendered Times New Roman black type: body 8–9 pt, headers 9.5 pt, panel letters 11 pt; 190.5 mm final width.')
