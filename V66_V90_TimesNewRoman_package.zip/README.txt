V66 U-Net / V90 paired boxplots — Times New Roman, black text

Typography at the delivered 190.5-mm figure width:
- All text: actual Times New Roman, pure black (#000000).
- Body labels / sample counts / ticks: 8 pt.
- Legend: 8.5 pt; y-axis title: 9 pt.
- Metric headers: 9.5 pt bold; panel letters: 11 pt bold.
- Body text uses regular weight. Only panel letters and metric headers are bold.

The PDF was checked span-by-span: only TimesNewRomanPSMT and TimesNewRomanPS-BoldMT are embedded; every text span has RGB color 0; the minimum text size is 8 pt. PDF and SVG are vectors; JPG/PNG/TIFF are 600 dpi. SVG text remains editable.

Data are copied byte-for-byte from the preceding reference-style boxplot data. Each point represents one of six fixed 256×256 spatial windows, with T2–T4 confusion counts pooled within that window. This is a descriptive within-development-position comparison, not six independent biological replicates or an independent V90 test. No P values are added. V90 includes structural and manual refinement. The earlier table pooled the entire root region and has a different aggregation scope.

Figure source and the unchanged data/caption are included. Raw font binaries are not distributed. For re-rendering, supply regular and bold Times New Roman font files locally; the rendering source records the expected font filenames. Publication font/size rules vary by journal, so the supplied vector files can be resized to the target journal's final width.
