"""Four-period original RGB, original human masks and three V35 binary masks."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,patheffects
import fitz
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);args=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(args.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':9,'text.color':'black','pdf.fonttype':42})
meta=json.loads((ROOT/'source_provenance.json').read_text())
for r in meta['records']:
 a=np.array(Image.open(ROOT/r['source_crop_file']));assert hashlib.sha256(a.tobytes()).hexdigest()==r['crop_array_sha256']
GROUPS={'human':'Human annotation','unet':'U-Net','deeplab':'DeepLabV3+','segformer':'SegFormer-B0'}
W,H=190.5,134
LEFT,CW,GAP=12.5,33.4,1.5;PH=CW*320/420
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
def txt(x,y,s,size=9,ha='left',bold=False):
 return fig.text(x/W,1-y/H,s,ha=ha,va='center',fontsize=size,fontweight='bold' if bold else 'normal',color='black')
txt(W/2,5,'V35 · Matched local root segmentation',11.5,'center',True)
for j,title in enumerate(['Original RGB']+list(GROUPS.values())):txt(LEFT+j*(CW+GAP)+CW/2,13,title,9.5,'center',True)
(ROOT/'binary_results').mkdir(exist_ok=True);records=[]
for i,t in enumerate(['T1','T2','T3','T4']):
 yy=19+i*(PH+1.5);txt(5.5,yy+PH/2,t,10,'center',True)
 rgb=np.array(Image.open(ROOT/f'source_crops/{t}_RGB.png').convert('RGB'));images=[rgb];period=[]
 for key in GROUPS:
  mask=np.array(Image.open(ROOT/f'source_crops/{t}_{key}.png'));assert set(np.unique(mask)).issubset({0,255})
  out=np.where(mask>0,0,255).astype(np.uint8)
  file=f'binary_results/{t}_{key}_black_root_white_background.png';Image.fromarray(out).save(ROOT/file)
  images.append(out);period.append({'group':key,'foreground_pixels':int((mask>0).sum()),'file':file,'array_sha256':hashlib.sha256(out.tobytes()).hexdigest()})
 for j,im in enumerate(images):
  ax=fig.add_axes([(LEFT+j*(CW+GAP))/W,1-(yy+PH)/H,CW/W,PH/H])
  ax.imshow(im,cmap='gray',vmin=0,vmax=255,interpolation='nearest');ax.set(xlim=(-.5,419.5),ylim=(319.5,-.5));ax.set_xticks([]);ax.set_yticks([])
  for s in ax.spines.values():s.set_color('#D8DDE0');s.set_linewidth(.35)
  if j==0:
   line,=ax.plot([16,116],[304,304],color='white',lw=1.5,solid_capstyle='butt')
   line.set_path_effects([patheffects.Stroke(linewidth=2.3,foreground='black'),patheffects.Normal()])
   ax.text(66,284,'100 px',fontsize=8.5,ha='center',va='bottom',color='black',bbox={'fc':'white','ec':'none','pad':.4})
 records.append({'period':t,'ROI_xyxy':meta['ROI_xyxy'],'results':period})
txt(W/2,129.6,'Black: root foreground    ·    White: background',8.5,'center')
stem='V35_human_three_models_T1-T4_region3_SCI'
for ext in ['png','pdf']:fig.savefig(ROOT/(stem+'.'+ext),dpi=600,facecolor='white')
fig.savefig(ROOT/(stem+'.tiff'),dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)
Image.open(ROOT/(stem+'.png')).convert('RGB').save(ROOT/(stem+'.jpg'),'JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
with fitz.open(ROOT/(stem+'.pdf')) as doc:doc[0].get_pixmap(matrix=fitz.Matrix(1.8,1.8),alpha=False).save(ROOT/'preview.png')
(ROOT/'figure_manifest.json').write_text(json.dumps({'figure_mm':[W,H],'raster_dpi':600,'layout':'T1–T4 × Original RGB / Human annotation / U-Net / DeepLabV3+ / SegFormer-B0','source_version':'V35 binary predictions plus original preserved human masks before assisted reference revision','ROI_xyxy':meta['ROI_xyxy'],'same_ROI_all_four_periods':True,'full_field_panels':False,'display':'Black root foreground on white background for human/model columns, original RGB only in the first column; no colored RGB overlays.','font':'Black Times New Roman, 8.5–11.5 pt','records':records,'mask_geometry_unchanged':True,'new_training_registration_annotation_or_inference':False},indent=2)+'\n')
print('Created 4×5 local binary-segmentation figure with original human annotation.')
