from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
import fitz
ROOT=Path(__file__).resolve().parent
src=json.loads((ROOT/'source_provenance.json').read_text());m=json.loads((ROOT/'figure_manifest.json').read_text())
x0,y0,x1,y1=src['ROI_xyxy']
assert len(src['records'])==20 and src['human_annotation']['original_masks_preserved']
checks=0
for r in src['records']:
 a=np.array(Image.open(ROOT/r['source_crop_file']));assert a.shape[:2]==(320,420)
 assert hashlib.sha256(a.tobytes()).hexdigest()==r['crop_array_sha256']
 p=Path(r['source_file'])
 if p.exists():
  assert hashlib.sha256(p.read_bytes()).hexdigest()==r['source_sha256'];checks+=1
  assert np.array_equal(a,np.array(Image.open(p))[y0:y1,x0:x1])
assert not m['full_field_panels'] and m['same_ROI_all_four_periods']
for r in m['records']:
 for rec in r['results']:
  source=np.array(Image.open(ROOT/f'source_crops/{r["period"]}_{rec["group"]}.png'))
  out=np.array(Image.open(ROOT/rec['file']))
  assert set(np.unique(out)).issubset({0,255})
  assert np.array_equal(out==0,source>0)
  assert hashlib.sha256(out.tobytes()).hexdigest()==rec['array_sha256']
stem='V35_human_three_models_T1-T4_alternative_local_SCI'
with fitz.open(ROOT/(stem+'.pdf')) as doc:
 assert len(doc)==1
 fonts={r[3].split('+')[-1] for r in doc[0].get_fonts()};assert fonts=={'TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'}
 spans=[s for b in doc[0].get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
 assert all(s['color']==0 for s in spans)
 for s in spans:
  r=fitz.Rect(s['bbox']);assert r.x0>=0 and r.y0>=0 and r.x1<=doc[0].rect.width and r.y1<=doc[0].rect.height
exports={}
for ext in ['png','jpg','tiff']:
 with Image.open(ROOT/(stem+'.'+ext)) as im:
  assert im.width==4500 and abs(im.height-round(134/25.4*600))<=1
  assert im.convert('RGB').getpixel((0,0))==(255,255,255)
  exports[ext]={'pixels':list(im.size),'dpi':[float(v) for v in im.info.get('dpi',(0,0))]}
report={'original_human_masks_not_assisted_reference':True,'source_files_verified':20,'full_source_hash_checks':checks,'four_dates_same_ROI':True,'ROI_xyxy':src['ROI_xyxy'],'crop_pixels':[420,320],'figure_panels':20,'full_field_panels':False,'human_and_model_mask_geometry_unchanged':True,'black_foreground_white_background':True,'colored_RGB_overlays':False,'font_faces':sorted(fonts),'all_text_black':True,'all_text_within_page':True,'exports':exports,'no_training_registration_annotation_or_inference':True}
(ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
