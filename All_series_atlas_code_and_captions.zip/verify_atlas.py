from pathlib import Path
import csv,hashlib,json
import fitz

ROOT=Path(__file__).resolve().parent
pdf=ROOT/'All_series_T1_T4_RGB_atlas.pdf';doc=fitz.open(pdf)
manifest=json.loads((ROOT/'page_source_manifest.json').read_text())
active=list(csv.DictReader((ROOT/'provenance/dataset/current/active_positions.csv').open(encoding='utf-8-sig')))
assert len(doc)==len(manifest)==len(active)==18
all_text='';fonts=set();sizes=[];image_count=0;source_count=0;placeholders=0;pages=[]
for page,entry,expected in zip(doc,manifest,active):
 assert entry['position_id']==expected['position_id']
 text=page.get_text();all_text+=text
 assert entry['position_id'] in text and f'Figure {entry["page"]}.' in text
 assert all(f'T{t}' in text for t in [1,2,3,4])
 placeholders+=text.count('Not acquired')
 images=page.get_images(full=True);assert len(images)==2*len(entry['frames']);image_count+=len(images)
 spans=[s for b in page.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()]
 for s in spans:
  assert s['color']==0
  assert s['font'].split('+')[-1] in ['TimesNewRomanPSMT','TimesNewRomanPS-BoldMT']
  assert s['size']>=7.99
  bbox=fitz.Rect(s['bbox']);assert page.rect.contains(bbox),(entry['position_id'],s['text'],bbox,page.rect)
  fonts.add(s['font'].split('+')[-1]);sizes.append(s['size'])
 assert abs(page.rect.width/72*25.4-190.5)<.02
 assert abs(page.rect.height/72*25.4-entry['page_mm'][1])<.02
 for frame in entry['frames']:
  for key,hkey in [('original_path','original_SHA256'),('registered_RGB_path','registered_RGB_SHA256')]:
   path=ROOT/frame[key]
   with path.open('rb') as handle:
    h=hashlib.sha256()
    while data:=handle.read(1048576):h.update(data)
   assert h.hexdigest()==frame[hkey]
  q=frame['detail_polygon_original'];w,h=frame['original_size']
  assert all(-.6<=x<=w-.4 and -.6<=y<=h-.4 for x,y in q)
  source_count+=1
 pages.append({'page':entry['page'],'position_id':entry['position_id'],'original_frames':len(entry['frames']),'common_fields':len(entry['frames']),'page_mm':[page.rect.width/72*25.4,page.rect.height/72*25.4]})
assert source_count==66 and image_count==132 and placeholders==12
assert '0353-1-Z2' not in all_text and 'Q1-3-Z3' not in all_text
assert 'coarse, unverified candidate' in doc[13].get_text()
pairs=list(csv.DictReader((ROOT/'observed_date_pair_index.csv').open(encoding='utf-8-sig')))
assert len(pairs)==48 and sum(r['consecutive_periods']=='True' for r in pairs)==43
assert len({r['tube_id'] for r in active})==8
assert len(doc.get_toc())==29
report={'PDF_pages':18,'tube_groups':8,'image_series':18,'original_frames_shown':66,'saved_common_fields_shown':66,'image_panels':132,'missing_period_slots':6,'placeholder_panels':12,'observed_date_links':48,'consecutive_period_links':43,'gap_links_with_missing_period_labels':5,'all_132_source_file_checksums_match':True,'all_projected_detail_boxes_inside_originals':True,'all_PDF_text_black':True,'fonts':sorted(fonts),'font_size_pt':[min(sizes),max(sizes)],'all_text_inside_visible_pages':True,'canonical_Q1_1_Z2_used':True,'excluded_position_absent':True,'Q1_1_Z2_unverified_T2_T3_disclosed':True,'PDF_bytes':pdf.stat().st_size,'PDF_SHA256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'pages':pages}
(ROOT/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='pages'},indent=2))
