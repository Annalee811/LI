"""One captioned T1–T4 original/common-field plate per active image series."""
from pathlib import Path
import argparse,ast,csv,hashlib,io,json,sys
import numpy as np
from PIL import Image
import fitz
from pdf_text_mapping import normalize_ascii_tounicode

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'provenance/analysis-scripts'))
from dataset_identity import require_active_position
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--fonts-dir',type=Path,required=True)
p.add_argument('--output-dir',type=Path,default=ROOT)
a=p.parse_args();OUT=a.output_dir.resolve();OUT.mkdir(parents=True,exist_ok=True)
FONTS={'regular':a.fonts_dir/'Times New Roman.ttf','bold':a.fonts_dir/'Times New Roman Bold.ttf'}
fonts={k:fitz.Font(fontfile=str(v)) for k,v in FONTS.items()}
meta=ROOT/'provenance/dataset/current'
positions=list(csv.DictReader((meta/'active_positions.csv').open(encoding='utf-8-sig')))
frames=list(csv.DictReader((meta/'active_images.csv').open(encoding='utf-8-sig')))
registry=json.loads((ROOT/'provenance/geometry_registry_current.json').read_text())
originals=json.loads((ROOT/'originals_verification.json').read_text());rgbs=json.loads((ROOT/'RGB_verification.json').read_text())
index={(r['position_id'],r['period']):r for r in frames}
origindex={(r['position_id'],r['period']):r for r in originals}
rgbindex={(r['position_id'],r['period']):r for r in rgbs}
tree=ast.parse((ROOT/'provenance/original_figure_series.py').read_text())
specs=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SPECS' for t in n.targets)))
MM=72/25.4;PW,PH=190.5*MM,165*MM
CYAN=(.10,.55,.57);GOLD=(.82,.64,.22);GRAY=(.83,.85,.86)
doc=fitz.open();proof=[];captions=[];pairrows=[];sourceproof=[];toc=[];last_series=None;last_tube=None

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def text(page,x,y,s,size=9,bold=False,center=False):
 font=fonts['bold' if bold else 'regular'];xx=x*MM
 if center:xx-=font.text_length(s,fontsize=size)/2
 page.insert_text((xx,y*MM),s,fontname='TNRB' if bold else 'TNR',fontsize=size,color=(0,0,0))
def wrapped(s,width_pt,size):
 lines=[];line=''
 for word in s.split():
  test=(line+' '+word).strip()
  if line and fonts['regular'].text_length(test,fontsize=size)>width_pt:lines.append(line);line=word
  else:line=test
 if line:lines.append(line)
 return lines
def fit_image(page,path,slot):
 im=Image.open(path).convert('RGB');x,y,w,h=slot
 scale=min(w/im.width,h/im.height);ww,hh=im.width*scale,im.height*scale
 rect=fitz.Rect((x+(w-ww)/2)*MM,(y+(h-hh)/2)*MM,(x+(w+ww)/2)*MM,(y+(h+hh)/2)*MM)
 # Entire image retained. Only its PDF display copy is downsampled/compressed.
 native_wh=im.size;limit=(max(1,round(ww/25.4*600)),max(1,round(hh/25.4*600)))
 im.thumbnail(limit,Image.Resampling.LANCZOS);buffer=io.BytesIO();im.save(buffer,format='JPEG',quality=97,subsampling=0,optimize=True)
 page.insert_image(rect,stream=buffer.getvalue());page.draw_rect(rect,color=GRAY,width=.35)
 def transform(points):
  q=np.asarray(points,dtype=float)
  return [fitz.Point(rect.x0+(v[0]+.5)*rect.width/native_wh[0],rect.y0+(v[1]+.5)*rect.height/native_wh[1]) for v in q]
 return rect,transform,native_wh,im.size
def corners(box):
 x0,y0,x1,y1=box;return np.array([[x0-.5,y0-.5],[x1-.5,y0-.5],[x1-.5,y1-.5],[x0-.5,y1-.5]],float)
def project(points,matrix):
 v=np.c_[points,np.ones(len(points))]@np.array(matrix).T
 return v[:,:2]/v[:,2:]
def polygon(page,points,color,width=.8,dashed=False):
 points=list(points);shape=page.new_shape();shape.draw_polyline(points+[points[0]])
 shape.finish(color=color,width=width,dashes='[3 2] 0' if dashed else None);shape.commit()
def missing(page,slot):
 x,y,w,h=slot;r=fitz.Rect((x+1)*MM,(y+1)*MM,(x+w-1)*MM,(y+h-1)*MM)
 page.draw_rect(r,color=GRAY,fill=(.975,.975,.975),width=.45)
 text(page,x+w/2,y+h/2+1,'Not acquired',9,center=True)
def geometry(entry,pos):
 x0=max(r['box'][0] for r in entry['regions']);x1=min(r['box'][2] for r in entry['regions'])
 boxes={r['id']:[x0,r['box'][1],x1,r['box'][3]] for r in entry['regions']}
 offsets={};yy=0
 for r in entry['regions']:
  offsets[r['id']]=yy;b=boxes[r['id']];yy+=b[3]-b[1]+24
 if pos=='0353-2-B3':
  rid='A';stitched=[1219,232,1854,864];b=boxes[rid];native=[stitched[0]+b[0],stitched[1]+b[1],stitched[2]+b[0],stitched[3]+b[1]]
 else:
  rid,cx,cy,fraction=specs[pos];b=boxes[rid];bx,by,ex,ey=b;bw,bh=ex-bx,ey-by
  side=min(round(bw*fraction),round(bh*.88));assert side>=100
  x=min(max(round(bx+cx*bw-side/2),bx+2),ex-side-2);y=min(max(round(by+cy*bh-side/2),by+2),ey-side-2)
  native=[x,y,x+side,y+side];stitched=[x-bx,y-by+offsets[rid],x+side-bx,y+side-by+offsets[rid]]
 return boxes,offsets,rid,native,stitched,[x1-x0,yy-24]

for pi,position in enumerate(positions,1):
 pos=require_active_position(position['position_id']);entry=registry[pos];periods=entry['periods'];tube=position['tube_id'];series=pos.split('-')[0]
 assert pos==entry['position'] and len(periods) in [3,4]
 page=doc.new_page(width=PW,height=PH)
 for key,path in FONTS.items():page.insert_font(fontname='TNRB' if key=='bold' else 'TNR',fontfile=str(path))
 if series!=last_series:toc.append([1,series,pi]);last_series=series;last_tube=None
 if tube!=last_tube:toc.append([2,tube,pi]);last_tube=tube
 toc.append([3,pos,pi])
 text(page,5,8,f'{pos}  |  Original context and matched observation fields',11,bold=True)
 available=', '.join('T'+str(t) for t in periods);absent=['T'+str(t) for t in range(1,5) if t not in periods]
 text(page,5,14,f'Tube {tube}  /  acquired: {available}'+('  /  review required' if position['review_required']=='True' else ''),8.5)
 left,gap,cw=24,1.5,(190.5-24-5-3*1.5)/4
 for j in range(4):text(page,left+j*(cw+gap)+cw/2,22,f'T{j+1}',10,bold=True,center=True)
 text(page,5,39,'A',11,bold=True);text(page,5,46,'Original',8.5,bold=True);text(page,5,50,'context',8.5,bold=True)
 page.draw_line((5*MM,69*MM),(185.5*MM,69*MM),color=(.91,.92,.93),width=.4)
 boxes,offsets,rid,native_box,stitched_box,joined_wh=geometry(entry,pos)
 selected_region=next(r for r in entry['regions'] if r['id']==rid)
 common_h=min(35,cw*joined_wh[1]/joined_wh[0]);common_middle=72+common_h/2
 text(page,5,common_middle-5,'B',11,bold=True);text(page,5,common_middle+1,'Common',8.5,bold=True);text(page,5,common_middle+5,'field',8.5,bold=True)
 oneproof={'page':pi,'position_id':pos,'tube_id':tube,'available_periods':periods,'missing_periods':absent,'region_count':len(entry['regions']),'detail_region_id':rid,'detail_window_T1':native_box,'detail_window_stitched':stitched_box,'frames':[]}
 for j in range(4):
  t=j+1;key=f'T{t}';x=left+j*(cw+gap);slotA=(x,26,cw,40);slotB=(x,72,cw,common_h)
  if t not in periods:missing(page,slotA);missing(page,slotB);continue
  row=index[pos,key];orig=ROOT/origindex[pos,key]['file'];rgb=ROOT/rgbindex[pos,key]['file']
  assert sha(orig)==row['original_SHA256'] and sha(rgb)==row['registered_RGB_SHA256']
  rect,map_original,original_wh,display_whA=fit_image(page,orig,slotA)
  assert original_wh==(int(row['original_width']),int(row['original_height']))
  for r in entry['regions']:
   q=project(corners(boxes[r['id']]),r['matrices'][key]);polygon(page,map_original(q),CYAN,.85,r['review_required'])
  q=project(corners(native_box),selected_region['matrices'][key]);polygon(page,map_original(q),GOLD,.95)
  rectB,map_common,rgb_wh,display_whB=fit_image(page,rgb,slotB)
  assert list(rgb_wh)==joined_wh==[int(row['RGB_width']),int(row['RGB_height'])]
  for r in entry['regions']:
   b=boxes[r['id']];yy=offsets[r['id']];regionbox=[0,yy,joined_wh[0],yy+b[3]-b[1]]
   polygon(page,map_common(corners(regionbox)),CYAN,.65,r['review_required'])
  polygon(page,map_common(corners(stitched_box)),GOLD,.95)
  frame={'period':key,'original_path':str(orig.relative_to(ROOT)),'original_SHA256':row['original_SHA256'],'registered_RGB_path':str(rgb.relative_to(ROOT)),'registered_RGB_SHA256':row['registered_RGB_SHA256'],'original_size':original_wh,'common_size':rgb_wh,'display_original_size':display_whA,'display_common_size':display_whB,'detail_polygon_original':q.tolist(),'complete_original_field_shown':True,'complete_published_common_field_shown':True}
  oneproof['frames'].append(frame);sourceproof.append({'position_id':pos,**frame})
 # Common legend, without color-coded text.
 legend_y=72+common_h+6
 page.draw_line((24*MM,legend_y*MM),(31*MM,legend_y*MM),color=CYAN,width=.9)
 text(page,33,legend_y+1,'Observation region; dashed = review required',8)
 page.draw_line((105*MM,legend_y*MM),(112*MM,legend_y*MM),color=GOLD,width=.95)
 text(page,114,legend_y+1,'Same local window across periods',8)
 links=[]
 for earlier,later in zip(periods,periods[1:]):
  absent_between=['T'+str(t) for t in range(earlier+1,later)]
  link=f'T{earlier}–T{later}'+(' ('+', '.join(absent_between)+' unavailable)' if absent_between else '')
  links.append(link);pairrows.append({'position_id':pos,'tube_id':tube,'earlier_period':f'T{earlier}','later_period':f'T{later}','consecutive_periods':later-earlier==1,'missing_between':';'.join(absent_between),'PDF_page':pi})
 flagged=sum(r['review_required'] for r in entry['regions']);bands=len(entry['regions'])
 caption=(f'Figure {pi}. Temporal image correspondence for {pos}. (A) Complete original RGB context with the saved observation polygons. '
          f'(B) Corresponding common fields at the saved T1 pixel scale; '+(f'{bands} observation bands are joined in the archived order, with white non-data separator rows. ' if bands>1 else 'one observation band is shown. ')+
          'Cyan outlines identify observation regions; gold boxes mark an identical local window in the T1 reference coordinates, projected onto each original frame. '+
          'Observed-date links: '+', '.join(links)+'. '+
          ('Missing acquisition: '+', '.join(absent)+'. ' if absent else '')+
          (f'Review status: {flagged}/{bands} observation bands remain flagged (dashed). ' if flagged else '')+
          ('The T2–T3 link at Q1-1-Z2 remains a coarse, unverified candidate; the corrected identifier does not validate this link. ' if pos=='Q1-1-Z2' else '')+
          'Existing RGB and geometry were reused; no new registration was fitted.')
 caption_y=legend_y+8
 lines=wrapped(caption,180.5*MM,8.5);assert len(lines)<=11,(pos,len(lines))
 for i,line in enumerate(lines):text(page,5,caption_y+i*3.65,line,8.5)
 footer_y=caption_y+(len(lines)-1)*3.65+7
 text(page,185.5,footer_y,str(pi),8,center=True)
 crop_h=footer_y+3;assert crop_h<165
 page.set_cropbox(fitz.Rect(0,0,PW,crop_h*MM));oneproof['page_mm']=[190.5,crop_h]
 captions.append({'page':pi,'position_id':pos,'caption_en':caption,'caption_cn':f'图{pi}，{pos}系列（微根管{tube}）的原始RGB与匹配公共视野。A为各期完整原始RGB及已有观察区域定位框；B为已有T1尺度公共视野。青色实线为观察区域，虚线为仍需复核的区域；金色框为固定T1坐标的同一局部窗口。已采集时期：{available}。缺失时期：'+('、'.join(absent) if absent else '无')+'。'+('Q1-1-Z2的T2—T3粗匹配仍未验证。' if pos=='Q1-1-Z2' else '')+'全部沿用既有匹配结果，未重新估计配准。'})
 proof.append(oneproof);print('PAGE READY',pi,pos,'frames',len(oneproof['frames']),flush=True)

assert len(doc)==18 and len(sourceproof)==66 and len(pairrows)==48
doc.set_toc(toc);doc.set_metadata({'title':'All active minirhizotron series: original RGB and matched common fields','subject':'18 image series, 66 acquisitions, T1–T4, frozen correspondence geometry','creator':'Captioned atlas export','keywords':'minirhizotron, temporal correspondence, original RGB, common field'})
doc.subset_fonts();normalize_ascii_tounicode(doc);path=OUT/'All_series_T1_T4_RGB_atlas.pdf';doc.save(path,garbage=4,deflate=True);doc.close()
(OUT/'page_source_manifest.json').write_text(json.dumps(proof,indent=2));(OUT/'captions.json').write_text(json.dumps(captions,ensure_ascii=False,indent=2))
(OUT/'captions_CN_EN.txt').write_text('\n\n'.join(f'{r["position_id"]} — PDF page {r["page"]}\n{r["caption_en"]}\n{r["caption_cn"]}' for r in captions),encoding='utf-8')
with (OUT/'observed_date_pair_index.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(pairrows[0]));writer.writeheader();writer.writerows(pairrows)
(OUT/'build_summary.json').write_text(json.dumps({'PDF':path.name,'pages':18,'active_series':18,'tubes':8,'source_original_images':66,'published_common_field_images':66,'observed_date_links':48,'consecutive_T_links':sum(r['consecutive_periods'] for r in pairrows),'gap_links_explicitly_labeled':sum(not r['consecutive_periods'] for r in pairrows),'missing_T1_T4_slots':6,'canonical_id':'Q1-1-Z2','excluded_by_current_project_policy':['Q1-3-Z3'],'figure_template':'Four period columns; A original context + observation/detail boxes; B corresponding complete saved common field + same detail box; per-series caption.','originals_changed':False,'new_registration_fitted':False,'fonts':'Black Times New Roman, 8–11 pt','page_width_mm':190.5,'page_heights_mm':[q['page_mm'][1] for q in proof],'image_display_export':'Entire source fields retained; display copies at up to 600 dpi, JPEG quality 97. Original source files remain unchanged.','PDF_bytes':path.stat().st_size,'SHA256':sha(path)},indent=2))
print('PDF COMPLETE',len(proof),'pages',round(path.stat().st_size/2**20,2),'MiB',flush=True)
