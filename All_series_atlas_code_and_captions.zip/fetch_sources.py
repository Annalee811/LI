"""Fetch unchanged current registered RGB and checksum-verified missing originals."""
from pathlib import Path
import csv,json,hashlib,sys,urllib.request,urllib.parse,zipfile,shutil
from concurrent.futures import ThreadPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'provenance/analysis-scripts'))
from dataset_identity import require_active_position
META=ROOT/'provenance/dataset/current'
rows=list(csv.DictReader((META/'active_images.csv').open(encoding='utf-8-sig')))
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def originals():
 base=Path('/workspace/LI/results/microtube_registration/input/raw/V-变化');pending=[];records=[]
 for r in rows:
  pos=require_active_position(r['position_id']);dest=ROOT/'sources/originals'/pos;dest.mkdir(parents=True,exist_ok=True)
  matches=list((base/r['legacy_source_id']).glob(r['period']+'.*'))
  if matches and digest(matches[0])==r['original_SHA256']:
   target=dest/matches[0].name
   if not target.exists():target.symlink_to(matches[0].resolve())
   records.append({'position_id':pos,'period':r['period'],'file':str(target.relative_to(ROOT)),'sha256':digest(target),'origin':'Existing local original'})
  else:pending.append(r)
 if pending:
  for archive,pin in [('Q1.zip','de74de5504474af5ef4f6e1cc28265a87ac7039032593e465ff9128336d394e2'),('V-.zip','98c7aa632d160f7f89714da9f68d71dddc7f28c951102dac46d8a80951ff99d2')]:
   needed=[r for r in pending if (r['legacy_source_id'].startswith('Q1'))==(archive=='Q1.zip')]
   if not needed:continue
   path=ROOT/'source_cache'/archive;path.parent.mkdir(exist_ok=True)
   if not path.exists():
    req=urllib.request.Request('https://github.com/Annalee811/LI/releases/download/v-change-data/'+archive)
    with urllib.request.urlopen(req,timeout=60) as response,path.with_suffix('.part').open('wb') as out:shutil.copyfileobj(response,out)
    path.with_suffix('.part').replace(path)
   assert digest(path)==pin
   wanted={r['original_SHA256']:r for r in needed};found=set()
   with zipfile.ZipFile(path) as z:
    for item in z.infolist():
     if item.is_dir():continue
     name=item.filename
     if not(item.flag_bits&0x800):
      try:name=name.encode('cp437').decode('gbk')
      except (UnicodeEncodeError,UnicodeDecodeError):pass
     parts=Path(name).parts
     if len(parts)<2 or parts[-2] not in {r['legacy_source_id'] for r in needed}:continue
     data=z.read(item);h=hashlib.sha256(data).hexdigest()
     if h not in wanted:continue
     r=wanted[h];target=ROOT/'sources/originals'/r['position_id']/(r['period']+Path(name).suffix.lower());target.write_bytes(data);found.add(h)
     records.append({'position_id':r['position_id'],'period':r['period'],'file':str(target.relative_to(ROOT)),'sha256':digest(target),'origin':'Checksum-pinned '+archive+' source release'})
   assert found==set(wanted)
 assert len(records)==66
 (ROOT/'originals_verification.json').write_text(json.dumps(records,indent=2));print('ORIGINALS VERIFIED',len(records),flush=True)
 return records
def registered():
 pending=[];records=[]
 for r in rows:
  require_active_position(r['position_id']);dest=ROOT/'sources'/r['canonical_view_relative_path'];dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists() and digest(dest)==r['registered_RGB_SHA256']:
   records.append({'position_id':r['position_id'],'period':r['period'],'file':str(dest.relative_to(ROOT)),'sha256':digest(dest)});continue
  pending.append((r,dest))
 objects=[{'oid':r['registered_RGB_SHA256'],'size':int(r['registered_RGB_bytes'])} for r,p in pending]
 actions={}
 if objects:
  req=urllib.request.Request('https://github.com/Annalee811/LI.git/info/lfs/objects/batch',data=json.dumps({'operation':'download','transfers':['basic'],'objects':objects}).encode(),headers={'Content-Type':'application/vnd.git-lfs+json','Accept':'application/vnd.git-lfs+json'},method='POST')
  with urllib.request.urlopen(req,timeout=60) as response:actions={o['oid']:o for o in json.load(response)['objects']}
 def fetch(pair):
  r,dest=pair;obj=actions[r['registered_RGB_SHA256']];assert 'error' not in obj,(r['position_id'],r['period'],'Archive object unavailable')
  act=obj['actions']['download'];u=urllib.parse.urlparse(act['href']);assert u.scheme=='https' and u.hostname in ['github-cloud.githubusercontent.com','github-cloud.s3.amazonaws.com','lfs.github.com']
  req=urllib.request.Request(act['href'],headers=act.get('header',{}));part=dest.with_suffix('.part')
  with urllib.request.urlopen(req,timeout=60) as response,part.open('wb') as f:shutil.copyfileobj(response,f)
  assert part.stat().st_size==int(r['registered_RGB_bytes']) and digest(part)==r['registered_RGB_SHA256'];part.replace(dest)
  return {'position_id':r['position_id'],'period':r['period'],'file':str(dest.relative_to(ROOT)),'sha256':digest(dest)}
 with ThreadPoolExecutor(max_workers=5) as pool:
  for future in as_completed([pool.submit(fetch,p) for p in pending]):
   records.append(future.result())
   if len(records)%12==0:print('RGB VERIFIED',len(records),'/66',flush=True)
 assert len(records)==66
 (ROOT/'RGB_verification.json').write_text(json.dumps(records,indent=2));print('REGISTERED RGB VERIFIED',len(records),flush=True)
 return records
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=2) as pool:
  tasks=[pool.submit(originals),pool.submit(registered)]
  for future in as_completed(tasks):future.result()
 print('READY: 18 active series, 66 original frames and 66 archived registered RGBs. No new geometry estimated.',flush=True)
