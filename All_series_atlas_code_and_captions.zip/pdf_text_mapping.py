"""Keep shared Times New Roman glyphs searchable as the ASCII text supplied."""
import re

def normalize_ascii_tounicode(doc):
    # Some TNR glyphs alias space/NBSP, hyphen/soft-hyphen, and semicolon/Greek
    # question mark. PyMuPDF can choose the alias in its ToUnicode map. Correct
    # only these single-CID extraction mappings; glyphs and visual text stay intact.
    replacements={'00a0':'0020','00ad':'002d','037e':'003b'}
    seen=set();changes=0
    for page in doc:
        for font in page.get_fonts(full=True):
            kind,value=doc.xref_get_key(font[0],'ToUnicode')
            if kind!='xref':continue
            ref=int(value.split()[0])
            if ref in seen:continue
            seen.add(ref);raw=doc.xref_stream(ref).decode('ascii')
            def replace(match):
                return match.group(1)+'<'+replacements[match.group(2).lower()]+'>'+match.group(3)
            updated,count=re.subn(r'^([ \t]*<[0-9a-f]+>[ \t]+)<(00a0|00ad|037e)>([ \t]*)$',replace,raw,flags=re.M|re.I)
            if count:doc.update_stream(ref,updated.encode('ascii'));changes+=count
    return changes
