"""Small browsing PDF. Native PNG prediction archives preserve full resolution."""
from pathlib import Path
import csv,io
import fitz
from PIL import Image
W=Path(__file__).resolve().parent.parent;D=W/'delivery';F=Path('/workspace/work/root_workflow_real_assets_20261109/fonts');rows=list(csv.DictReader(open('/workspace/LI/dataset/current/active_images.csv',encoding='utf-8-sig')));positions=list(dict.fromkeys(r['position_id']for r in rows));doc=fitz.open();pages=[]
existing=D/'All_positions_temporal_RGB_preview.pdf'
if existing.exists():
 old=fitz.open(existing);found=[]
 for pg in old:
  lines=pg.get_text().splitlines();title=(lines[0] if lines else '').replace('\xad','-').replace('\xa0',' ');key=title.split(' | ')[0]
  if key in positions:found.append(key)
 if len(found)==len(old):doc.close();doc=old;pages=found
 else:old.close()
for pos in positions:
 if pos in pages:continue
 if not (D/'V90_transfer_candidates'/pos/'Prediction_and_validation_status.csv').exists():continue
 rr=[r for r in rows if r['position_id']==pos];ratio=int(rr[0]['RGB_height'])/int(rr[0]['RGB_width']);cw=200;ch=cw*ratio;top=78;left=56;gap=6;height=top+ch*2+5+64;page=doc.new_page(width=890,height=height);page.insert_font(fontname='TNR',fontfile=str(F/'Times New Roman.ttf'));page.insert_font(fontname='TNRB',fontfile=str(F/'Times New Roman Bold.ttf'));page.insert_text((left,24),f'{pos} | V90 transfer candidate',fontname='TNRB',fontsize=16);page.insert_text((left,43),'Matched-field registered RGB observations. Download native PNGs for full-resolution inspection.',fontname='TNR',fontsize=10)
 for col,t in enumerate(['T1','T2','T3','T4']):
  x=left+col*(cw+gap);page.insert_text((x+cw/2-7,67),t,fontname='TNRB',fontsize=12);r=next((r for r in rr if r['period']==t),None)
  for row in range(2):
   rect=fitz.Rect(x,top+row*(ch+5),x+cw,top+row*(ch+5)+ch)
   if r:
    src=Path('/workspace/work/all_series_RGB_PDF_20261105/sources')/r['canonical_view_relative_path']if row==0 else D/'V90_transfer_candidates'/pos/(t+'_RGB_temporal_candidate.png');im=Image.open(src).convert('RGB');im.thumbnail((1000,1000),Image.Resampling.LANCZOS);buf=io.BytesIO();im.save(buf,format='JPEG',quality=94,subsampling=0);page.insert_image(rect,stream=buf.getvalue())
   else:page.draw_rect(rect,color=None,fill=(.96,.96,.96));page.insert_text((x+65,rect.y0+ch/2),'Not acquired',fontname='TNR',fontsize=11)
 for row,text in enumerate(['Original RGB','Temporal labels']):page.insert_text((25,top+(row+.5)*(ch+5)+35),text,fontname='TNRB',fontsize=10,rotate=90)
 y=top+2*ch+23
 for x,label,color in [(left,'Persistent',(53/255,111/255,176/255)),(left+155,'Newly observed',(231/255,168/255,53/255)),(left+345,'Extending',(174/255,64/255,130/255)),(left+490,'T1 baseline',(.85,.85,.85))]:page.draw_rect(fitz.Rect(x,y-9,x+12,y+1),fill=color,color=None);page.insert_text((x+18,y),label,fontname='TNRB',fontsize=10)
 text='Candidate predictions; uncertainty masks and exclusive axis ownership are supplied in the image archives.'
 if pos=='Q1-1-Z2':text='Attention: T2/T3 localization is coarse/unverified; temporal interpretation requires validation.'
 page.insert_text((left,height-14),text,fontname='TNR',fontsize=9);pages.append(pos)
out=D/'All_positions_temporal_RGB_preview.pdf';temp=D/'preview_complete_temporary.pdf';doc.set_toc([[1,pos,i+1]for i,pos in enumerate(pages)]);doc.set_metadata({'title':'V90 temporal segmentation candidates: all current positions','subject':'Original registered RGB and automatic temporal labels; native PNG archives available separately'});doc.save(temp,garbage=4,deflate=True);doc.close();temp.replace(out);print('PREVIEW',len(pages),'pages',out.stat().st_size,'bytes')
