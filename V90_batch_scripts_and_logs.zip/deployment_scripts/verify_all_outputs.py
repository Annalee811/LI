from pathlib import Path
import csv,json,hashlib
import numpy as np
from PIL import Image
W=Path(__file__).resolve().parent.parent;D=W/'delivery';active=list(csv.DictReader(open('/workspace/LI/dataset/current/active_images.csv',encoding='utf-8-sig')));records=[]
for row in active:
 pos=row['position_id'];t=row['period'];folder=D/'V90_transfer_candidates'/pos;rgbp=Path('/workspace/work/all_series_RGB_PDF_20261105/sources')/row['canonical_view_relative_path'];assert hashlib.sha256(rgbp.read_bytes()).hexdigest()==row['registered_RGB_SHA256'];rgb=np.array(Image.open(rgbp));cl=np.array(Image.open(folder/(t+'_classes.png')));baseline=np.array(Image.open(W/'inputs_t045'/pos/(t+'_prior_classes.png')));mask=cl>0;assert cl.shape==rgb.shape[:2];assert set(np.unique(cl)).issubset({0,1,2,3,4});assert np.array_equal(mask,baseline>0)
 own=np.load(folder/(t+'_ownership.npz'));assert np.array_equal(own['axis']>=0,mask);assert np.array_equal(own['track_id']>0,mask);unc=np.array(Image.open(folder/(t+'_uncertainty.png')))>0;assert not unc[~mask].any();assert np.array_equal(own['uncertain'],unc);combined=np.array(Image.open(folder/(t+'_classes_with_uncertainty.png')));assert np.all(combined[unc]==255);assert np.array_equal(combined[~unc],cl[~unc]);overlay=np.array(Image.open(folder/(t+'_RGB_temporal_candidate.png')));assert overlay.shape==rgb.shape;assert np.array_equal(overlay[~mask],rgb[~mask]);assert t!='T1'or np.all(cl[mask]==4)
 check=json.loads((folder/'candidate_complete.json').read_text());assert check['actual_frozen_weights_forward'];assert check['learned_pair_head_used'];assert check['learned_root_state_used'];records.append(dict(position=pos,period=t,native_size=[cl.shape[1],cl.shape[0]],root_pixels=int(mask.sum()),uncertain_pixels=int(unc.sum()),RGB_background_unchanged=True,root_foreground_unchanged=True,exclusive_pixel_owner=True,missing_date_filled=False,classes_SHA256=hashlib.sha256((folder/(t+'_classes.png')).read_bytes()).hexdigest()))
 assert pos!='Q1-3-Z3'
print('VERIFIED',len(records),'native image outputs',flush=True)
report=dict(passed=True,frames=len(records),positions=len(set(r['position']for r in records)),source_tubes=len(set(r['tube_id']for r in active)),actual_frozen_V90_inference=True,manual_labels_at_inference=False,model_version='V90-transfer-candidate-v1',exact_original_preprocessor=False,external_accuracy_not_established=True,records=records)
(D/'Output_integrity_verification.json').write_text(json.dumps(report,indent=2));assert len(records)==66 and report['positions']==18
