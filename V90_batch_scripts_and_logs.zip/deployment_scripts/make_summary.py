from pathlib import Path
import csv,json,hashlib,shutil
import numpy as np
from PIL import Image
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
W=Path(__file__).resolve().parent.parent;D=W/'delivery';P=D/'V90_transfer_candidates'
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
active=rows(Path('/workspace/LI/dataset/current/active_images.csv'));records=[];seq=[]
for pos in dict.fromkeys(r['position_id']for r in active):
 folder=P/pos
 if not (folder/'Prediction_and_validation_status.csv').exists():continue
 rr=rows(folder/'Prediction_and_validation_status.csv')
 for r in rr:
  t=r['period'];cl=np.array(Image.open(folder/(t+'_classes.png')));unc=np.array(Image.open(folder/(t+'_uncertainty.png')))>0
  if pos=='Q1-1-Z2' and t!='T1':
   unc|=cl>0
   npz=folder/(t+'_ownership.npz');own=dict(np.load(npz))
   if not np.array_equal(own['uncertain'],unc):own['uncertain']=unc;np.savez_compressed(npz,**own)
   Image.fromarray(unc.astype(np.uint8)*255).save(folder/(t+'_uncertainty.png'));overlay=np.array(Image.open(folder/(t+'_RGB_temporal_candidate.png')));overlay[unc]=190;Image.fromarray(overlay).save(folder/(t+'_RGB_uncertainty_review.png'))
  white=np.full((*cl.shape,3),255,np.uint8);palette=np.array([[255,255,255],[53,111,176],[231,168,53],[174,64,130],[90,90,90]],np.uint8);white[cl>0]=palette[cl[cl>0]];Image.fromarray(white).save(folder/(t+'_roots_on_white.png'))
  q=cl.copy();q[unc]=255;Image.fromarray(q).save(folder/(t+'_classes_with_uncertainty.png'));r['uncertain_root_pixels']=int(unc.sum());r['accepted_fraction_of_roots']=float(((cl>0)&~unc).sum()/max((cl>0).sum(),1));r['input_review_required']=next(a['review_required']for a in active if a['position_id']==pos and a['period']==t);r['manual_annotation_role']='Evaluation only';records.append(r)
 with (folder/'Prediction_and_validation_status.csv').open('w',encoding='utf-8-sig',newline='')as f:
  wr=csv.DictWriter(f,fieldnames=list(rr[0]));wr.writeheader();wr.writerows(rr)
 seq.append(dict(position_id=pos,tube_id=next(r['tube_id']for r in active if r['position_id']==pos),periods=','.join(r['period']for r in rr),missing_periods=','.join(t for t in ['T1','T2','T3','T4']if not any(r['period']==t for r in rr)),frames=len(rr),status='V90 transfer candidate',manual_validation_status='Pending independent annotation' if pos!='0353-2-B3' else 'B3 developmental agreement only',registration_attention='T2/T3 coarse/unverified' if pos=='Q1-1-Z2' else 'See original dataset quality flag'))
for name,data in [('All_66_frames_status.csv',records),('All_18_sequences_status.csv',seq)]:
 with (D/name).open('w',encoding='utf-8-sig',newline='')as f:
  wr=csv.DictWriter(f,fieldnames=list(data[0])if data else ['status']);wr.writeheader();wr.writerows(data)
wb=Workbook();wb.remove(wb.active)
for title,data in [('Frame_predictions',records),('Position_status',seq)]:
 ws=wb.create_sheet(title)
 if data:
  ws.append(list(data[0]));[ws.append(list(r.values()))for r in data];ws.freeze_panes='C2';ws.auto_filter.ref=ws.dimensions
  for c in ws[1]:c.font=Font(name='Times New Roman',bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='23445B')
  for col in ws.columns:ws.column_dimensions[col[0].column_letter].width=min(45,max(14,max(len(str(c.value or ''))for c in col)+2))
ws=wb.create_sheet('B3_reference_agreement');data=json.loads((D/'B3_adapter_agreement.json').read_text());ws.append(['Model','Class','Precision','Recall','Dice','IoU','Scope'])
for name,res in data.items():
 for r in res['classes']:ws.append([name,{1:'Persistent',2:'Newly observed',3:'Extending'}[r['class_id']],r['Precision'],r['Recall'],r['Dice'],r['IoU'],res['scope']])
 ws.append([name,'Macro',None,None,res['macro_Dice'],None,res['scope']])
for row in ws.iter_rows(min_row=2):
 for cell in row[2:6]:
  if isinstance(cell.value,(int,float)):cell.number_format='0.00%'
wb.save(D/'V90_prediction_index_and_validation.xlsx');print('SUMMARY',len(seq),'positions',len(records),'frames')
