from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import csv,json,subprocess,sys,time,traceback
H=Path(__file__).resolve().parent;W=H.parent;BASE=W/'transfer_candidates';LOG=W/'batch_logs';LOG.mkdir(exist_ok=True)
rows=list(csv.DictReader(open('/workspace/LI/dataset/current/active_images.csv',encoding='utf-8-sig')));positions=list(dict.fromkeys(r['position_id']for r in rows));results=[]
def run(pos):
 work=BASE/pos;work.mkdir(parents=True,exist_ok=True)
 for i in range(180):
  if (W/'inputs_t045'/pos/'upstream_complete.json').exists():break
  time.sleep(5)
 else:return dict(position=pos,status='upstream_not_ready')
 try:
  commands=[]
  if not(work/'adapter_provenance.json').exists():commands.append([sys.executable,str(H/'build_graph_inputs.py'),'--position',pos,'--inputs',str(W/'inputs_t045'),'--output',str(work)])
  if not(work/'candidate_complete.json').exists():commands.append([sys.executable,str(H/'infer_candidate.py'),'--work',str(work)])
  commands.append([sys.executable,str(H/'export_candidate.py'),'--work',str(work),'--output',str(W/'delivery/V90_transfer_candidates')])
  for cmd in commands:
   stage=Path(cmd[1]).stem
   with open(LOG/(pos+'_'+stage+'.log'),'a')as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
  return dict(position=pos,status='candidate_exported',periods=[r['period']for r in rows if r['position_id']==pos])
 except Exception as e:return dict(position=pos,status='failed',error=str(e))
with ThreadPoolExecutor(max_workers=2)as ex:
 for future in as_completed([ex.submit(run,p)for p in positions if p!='0353-2-B3']):
  result=future.result();results.append(result);(W/'batch_status.json').write_text(json.dumps(results,indent=2));print(json.dumps(result),flush=True)
print('BATCH_FINISHED',len(results),flush=True)
