"""Exact five-metric tables for 18 sequences from the user-specified frozen workbook."""
from pathlib import Path
import argparse,csv,json,hashlib,math,sys
from collections import OrderedDict
from openpyxl import load_workbook,Workbook
from openpyxl.styles import Font,Alignment,Border,Side
from openpyxl.comments import Comment
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'provenance/analysis-scripts'))
from dataset_identity import require_active_position,tube_id
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);args=p.parse_args()
source=ROOT/'sources/All_microtube_root_traits.xlsx'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='ea74bf1853766e51fa3b30546d6893032e57e50ea991514c2735182a6fdb0e52'
workbook=load_workbook(source,data_only=True);it=workbook['All_72_cells'].values;headers=next(it)
raw=[dict(zip(headers,row)) for row in it];assert len(raw)==72
active=list(csv.DictReader((ROOT/'provenance/dataset/current/active_positions.csv').open(encoding='utf-8-sig')))
order=[require_active_position(r['position_id']) for r in active]
assert set(order)=={r['Observation_unit'] for r in raw} and len(order)==18
METRICS=['Skeleton length (10³ px)','Persistent (%)','New (%)','Extension (%)','E / Lprev (%)']
FIELDS=['Root_length_px','Persistent_share_current_pct','New_share_current_pct','Extension_share_current_pct','Extension_relative_previous_pct']
HEADERS=['Period','Skeleton length\n(10³ px)','Persistent\n(%)','New\n(%)','Extension\n(%)','E / Lprev\n(%)']
def number(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
def val(r,k):
 v=r[FIELDS[k]]
 return (float(v)/1000 if k==0 else float(v)) if number(v) else None
def fmt(v):return f'{v:.2f}' if v is not None else '—'
records=[];groups=OrderedDict();review={};notes={}
for seq in order:
 seqrows=sorted([r for r in raw if r['Observation_unit']==seq],key=lambda r:r['Period']);assert [r['Period'] for r in seqrows]==['T1','T2','T3','T4']
 assert all(r['Tube_ID']==tube_id(seq) for r in seqrows)
 groups[seq]=seqrows;review[seq]=any(str(r['Review_required']).lower()=='true' for r in seqrows)
 missing=[r['Period'] for r in seqrows if r['Acquisition_or_processing_status']=='该期图像缺失']
 unavailable=[r['Period'] for r in seqrows if r['Acquisition_or_processing_status']=='源文件不可用']
 details=[]
 if missing:details.append('Acquisition missing: '+', '.join(missing)+'.')
 if unavailable:details.append('Source results unavailable in the linked workbook: '+', '.join(unavailable)+'.')
 invalid=[r['Period'] for r in seqrows if r['Period']!='T1' and number(r['Root_length_px']) and not number(r['Persistent_share_current_pct'])]
 if invalid:details.append('Temporal shares unavailable at '+', '.join(invalid)+' because the immediately preceding period is unavailable.')
 if review[seq]:details.append('† Existing registration review flag retained.')
 if seq=='Q1-1-Z2':details.append('Its T2–T3 coarse correspondence remains unverified.')
 notes[seq]=' '.join(details)
 for r in seqrows:
  if number(r['Persistent_share_current_pct']):
   assert r['Adjacent_status']=='Available adjacent interval'
   assert abs(sum(r[k] for k in ['Persistent_share_current_pct','New_share_current_pct','Extension_share_current_pct'])-100)<1e-7
   for ck,lk in [('Persistent_share_current_pct','Persistent_adjacent_length_px'),('New_share_current_pct','New_adjacent_length_px'),('Extension_share_current_pct','Extension_adjacent_length_px')]:
    assert abs(r[ck]-100*r[lk]/r['Root_length_px'])<1e-7
   assert abs(r['Extension_relative_previous_pct']-100*r['Extension_adjacent_length_px']/r['Previous_root_length_px'])<1e-7
  records.append({'Observation unit':seq,'Source tube':r['Tube_ID'],'Material':r['Material'],'Period':r['Period'],**{m:val(r,k) for k,m in enumerate(METRICS)},'Acquisition/processing status':r['Acquisition_or_processing_status'],'Adjacent status':r['Adjacent_status'],'Registration review':str(r['Review_required']).lower()=='true'})
assert sum(number(r['Root_length_px']) for r in raw)==63
assert sum(number(r['Extension_relative_previous_pct']) for r in raw)==40
(ROOT/'extracted_values_full_precision.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
with (ROOT/'18_series_values_full_precision.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)

GENERAL=(
 'Individual sequence estimates are shown, without averaging across materials or adding an SD. '
 'Length is reported in 10³ native registered pixels; physical calibration is not confirmed. '
 'For T2, T3 and T4, temporal percentages refer to T1–T2, T2–T3 and T3–T4, respectively. '
 'Persistent, New and Extension are current-class length/current total length ×100%. '
 'E / Lprev is extension-class length/previous total length ×100%, not a time-normalized growth rate. '
 '“—” denotes baseline, missing acquisition or unavailable valid adjacent comparison; real zeros remain 0.00. '
 'The 18 observation sequences belong to 8 source tubes and are not 18 independent biological replicates. '
 'This linked workbook contains 63 usable length observations and 40 valid adjacent pairs; 6 unobserved periods and 3 unavailable source results remain missing. '
 'Existing V35/V66 U-Net model estimates and review flags are retained; these are not V90 measurements.')

def set_font(run,size=10.5,bold=False):
 run.font.name='Times New Roman';run.font.size=Pt(size);run.font.bold=bold;run.font.color.rgb=RGBColor(0,0,0)
 run._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'SimSun')
def paragraph(doc,text='',size=10.5,bold=False,after=3,keep=False):
 p=doc.add_paragraph();p.paragraph_format.space_after=Pt(after);p.paragraph_format.space_before=Pt(0);p.paragraph_format.keep_with_next=keep
 set_font(p.add_run(text),size,bold);return p
def make_doc():
 d=Document();section=d.sections[0];section.page_width=Cm(21);section.page_height=Cm(29.7);section.top_margin=Cm(1.8);section.bottom_margin=Cm(1.8);section.left_margin=Cm(2);section.right_margin=Cm(2)
 normal=d.styles['Normal'];normal.font.name='Times New Roman';normal.font.size=Pt(10.5);normal.font.color.rgb=RGBColor(0,0,0);normal.paragraph_format.space_after=Pt(0)
 foot=section.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.CENTER
 run=foot.add_run();set_font(run,9);field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');run._r.addnext(field)
 return d
def table_doc(d,header,rows,widths,merge_ids=False):
 t=d.add_table(rows=1,cols=len(header));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 props=t._tbl.tblPr;borders=OxmlElement('w:tblBorders')
 for side in ['top','left','bottom','right','insideH','insideV']:
  e=OxmlElement('w:'+side);e.set(qn('w:val'),'single' if side in ['top','bottom'] else 'nil');e.set(qn('w:sz'),'12' if side in ['top','bottom'] else '0');e.set(qn('w:color'),'000000');borders.append(e)
 props.append(borders)
 for col,cm in zip(t.columns,widths):col.width=Cm(cm)
 for j,s in enumerate(header):t.rows[0].cells[j].text=s
 for row in rows:
  cells=t.add_row().cells
  for j,s in enumerate(row):cells[j].text=str(s)
 for ri,row in enumerate(t.rows):
  cant=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(cant)
  for j,(cell,cm) in enumerate(zip(row.cells,widths)):
   cell.width=Cm(cm);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   mar=OxmlElement('w:tcMar')
   for side,twips in [('top',45),('bottom',45),('left',60),('right',60)]:
    e=OxmlElement('w:'+side);e.set(qn('w:w'),str(twips));e.set(qn('w:type'),'dxa');mar.append(e)
   cell._tc.get_or_add_tcPr().append(mar)
   for p in cell.paragraphs:
    p.paragraph_format.space_after=Pt(0);p.paragraph_format.space_before=Pt(0)
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER if ri==0 or j<(2 if merge_ids else 1) else WD_ALIGN_PARAGRAPH.RIGHT
    for run in p.runs:set_font(run,9.5 if ri==0 else 10.5,ri==0)
   if ri==0:
    bs=OxmlElement('w:tcBorders');e=OxmlElement('w:bottom');e.set(qn('w:val'),'single');e.set(qn('w:sz'),'6');e.set(qn('w:color'),'000000');bs.append(e);cell._tc.get_or_add_tcPr().append(bs)
 repeat=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(repeat)
 if merge_ids:
  for start in range(1,len(t.rows),4):
   label=rows[start-1][0];cell=t.cell(start,0).merge(t.cell(start+3,0));cell.text=label;cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   for p in cell.paragraphs:
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    for run in p.runs:set_font(run,9.5)
 return t

split=make_doc()
for i,(seq,rows) in enumerate(groups.items()):
 if i%3==0:
  if i:split.add_page_break()
  paragraph(split,'Root length and temporal traits of 18 observation sequences'+(' (continued)' if i else ''),12,True,after=5)
  if i==0:paragraph(split,GENERAL,8.5,after=8)
 label=f'Table {i+1}. {seq}'+('†' if review[seq] else '')+f' (source tube: {tube_id(seq)})'
 paragraph(split,label,10.5,True,after=3,keep=True)
 cells=[[r['Period']]+[fmt(val(r,k)) for k in range(5)] for r in rows]
 table_doc(split,HEADERS,cells,[1.4,3.5,3.0,2.5,3.0,3.6])
 if notes[seq]:paragraph(split,notes[seq],8.5,after=3)
 paragraph(split,'',8,after=8)
split.save(ROOT/'18_series_individual_three_line_tables.docx')

combined=make_doc()
for i,material in enumerate(['0353','A017','Q1']):
 if i:combined.add_page_break()
 paragraph(combined,f'Table {i+1}. Individual root traits across T1–T4: {material}',12,True,after=5)
 cells=[]
 for seq,rows in groups.items():
  if rows[0]['Material']!=material:continue
  for j,r in enumerate(rows):cells.append([(seq+('†' if review[seq] else '')) if j==0 else '',r['Period']]+[fmt(val(r,k)) for k in range(5)])
 table_doc(combined,['Observation\nunit']+HEADERS,cells,[3.0,1.6,2.7,2.4,2.2,2.4,2.7],merge_ids=True)
 paragraph(combined,GENERAL,8.5,after=3)
 local=' '.join(seq+': '+notes[seq] for seq,rs in groups.items() if rs[0]['Material']==material and notes[seq])
 if local:paragraph(combined,local,8.5,after=3)
combined.save(ROOT/'18_series_combined_three_line_tables.docx')

# Editable numeric workbook: display tables plus full-precision values/status.
x=Workbook();main=x.active;main.title='Combined_72_rows';main.append(['Observation unit','Period']+METRICS)
for record in records:main.append([record['Observation unit'],record['Period']]+[record[m] if record[m] is not None else '—' for m in METRICS])
thin=Side(style='thin',color='000000');thick=Side(style='medium',color='000000')
def excel_style(ws,header_row,last_row,cols,widths):
 ws.sheet_view.showGridLines=False;ws.freeze_panes=f'C{header_row+1}' if cols==7 else f'B{header_row+1}'
 for row in ws.iter_rows(min_row=header_row,max_row=last_row,min_col=1,max_col=cols):
  for cell in row:
   cell.font=Font(name='Times New Roman',size=11,color='000000',bold=cell.row==header_row)
   cell.alignment=Alignment(horizontal='center' if cell.row==header_row or cell.column==1 else 'right',vertical='center',wrap_text=cell.row==header_row)
   cell.border=Border(top=thick if cell.row==header_row else Side(),bottom=thin if cell.row==header_row else thick if cell.row==last_row else Side())
   if isinstance(cell.value,(int,float)):cell.number_format='0.00'
 for j,w in enumerate(widths,1):ws.column_dimensions[chr(64+j)].width=w
 ws.row_dimensions[header_row].height=34;ws.print_title_rows=f'{header_row}:{header_row}';ws.sheet_properties.pageSetUpPr.fitToPage=True;ws.page_setup.orientation='landscape' if cols==7 else 'portrait';ws.page_setup.paperSize=ws.PAPERSIZE_A4;ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0
excel_style(main,1,73,7,[22,12,25,20,18,20,23])
for seq,rows in groups.items():
 ws=x.create_sheet(seq);ws.merge_cells('A1:F1');ws['A1']=seq+('†' if review[seq] else '')+f' | source tube {tube_id(seq)}';ws['A1'].font=Font(name='Times New Roman',size=12,bold=True,color='000000')
 for j,s in enumerate(['Period']+METRICS,1):ws.cell(3,j,s)
 for j,r in enumerate(rows,4):
  ws.cell(j,1,r['Period'])
  for k in range(5):v=val(r,k);ws.cell(j,k+2,v if v is not None else '—')
 excel_style(ws,3,7,6,[12,26,22,20,22,25]);ws.merge_cells('A9:F9');ws['A9']=notes[seq] or 'T1 is the baseline; later temporal shares require a valid adjacent pair.';ws['A9'].alignment=Alignment(wrap_text=True);ws.row_dimensions[9].height=35;ws.print_area='A1:F10'
full=x.create_sheet('Full_precision_72');full.append(list(records[0]))
for r in records:full.append(list(r.values()))
full.freeze_panes='E2';full.auto_filter.ref=full.dimensions
defs=x.create_sheet('Definitions');defs.append(['Item','Definition']);defs.append(['Five requested metrics',', '.join(METRICS)]);defs.append(['Notes',GENERAL]);defs.append(['Frozen source',str(json.loads((ROOT/'sources/download_verification.json').read_text())[0]['url'])]);defs.append(['Publication fields','18 observation sequences nested within 8 source tubes.']);defs.append(['Precision','Display: two decimal places. Full_precision_72 retains unrounded extracted values.']);defs.column_dimensions['A'].width=27;defs.column_dimensions['B'].width=120
for row in defs:
 for cell in row:cell.alignment=Alignment(wrap_text=True,vertical='top');cell.font=Font(name='Times New Roman',size=11,color='000000')
x.save(ROOT/'18_series_root_traits_tables.xlsx')

# PDF previews are composed from the same extracted values, without rasterizing text.
pdfmetrics.registerFont(TTFont('TNR',str(args.fonts_dir/'Times New Roman.ttf')));pdfmetrics.registerFont(TTFont('TNRB',str(args.fonts_dir/'Times New Roman Bold.ttf')))
styles={n:ParagraphStyle(n,fontName=f,fontSize=s,leading=l,textColor=colors.black,spaceAfter=after) for n,f,s,l,after in [('title','TNRB',12,14,6),('caption','TNRB',10.5,12,4),('note','TNR',8.5,10.2,5),('header','TNRB',9.5,10.5,0)]}
def pdf_table(header,rows,widths,merge_ids=False):
 cellheads=[Paragraph(s.replace('\n','<br/>'),styles['header']) for s in header];t=Table([cellheads]+rows,colWidths=[c*28.3464567 for c in widths],repeatRows=1)
 instructions=[('FONTNAME',(0,1),(-1,-1),'TNR'),('FONTSIZE',(0,1),(-1,-1),10.5),('TEXTCOLOR',(0,0),(-1,-1),colors.black),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('ALIGN',(0,0),(-1,0),'CENTER'),('ALIGN',(0,1),(1 if merge_ids else 0,-1),'CENTER'),('ALIGN',(2 if merge_ids else 1,1),(-1,-1),'RIGHT'),('LINEABOVE',(0,0),(-1,0),1.5,colors.black),('LINEBELOW',(0,0),(-1,0),.75,colors.black),('LINEBELOW',(0,-1),(-1,-1),1.5,colors.black),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3)]
 if merge_ids:
  for start in range(1,len(rows)+1,4):instructions.append(('SPAN',(0,start),(0,start+3)))
 t.setStyle(TableStyle(instructions));return t
def page_number(canvas,doc):
 canvas.saveState();canvas.setFont('TNR',9);canvas.setFillColor(colors.black);canvas.drawCentredString(A4[0]/2,25,str(doc.page));canvas.restoreState()
story=[]
for i,(seq,rows) in enumerate(groups.items()):
 if i%3==0:
  if i:story.append(PageBreak())
  story.append(Paragraph('Root length and temporal traits of 18 observation sequences'+(' (continued)' if i else ''),styles['title']))
  if i==0:story.append(Paragraph(GENERAL,styles['note']))
 story.append(Paragraph(f'Table {i+1}. {seq}'+('†' if review[seq] else '')+f' (source tube: {tube_id(seq)})',styles['caption']))
 story.append(pdf_table(HEADERS,[[r['Period']]+[fmt(val(r,k)) for k in range(5)] for r in rows],[1.4,3.5,3.0,2.5,3.0,3.6]))
 if notes[seq]:story.append(Paragraph(notes[seq],styles['note']))
 story.append(Spacer(1,12))
SimpleDocTemplate(str(ROOT/'18_series_individual_three_line_tables.pdf'),pagesize=A4,leftMargin=2*28.3464567,rightMargin=2*28.3464567,topMargin=1.8*28.3464567,bottomMargin=1.8*28.3464567).build(story,onFirstPage=page_number,onLaterPages=page_number)
story=[]
for i,material in enumerate(['0353','A017','Q1']):
 if i:story.append(PageBreak())
 story.append(Paragraph(f'Table {i+1}. Individual root traits across T1–T4: {material}',styles['title']));rows=[]
 for seq,rs in groups.items():
  if rs[0]['Material']!=material:continue
  for j,r in enumerate(rs):rows.append([(seq+('†' if review[seq] else '')) if j==0 else '',r['Period']]+[fmt(val(r,k)) for k in range(5)])
 story.append(pdf_table(['Observation\nunit']+HEADERS,rows,[3.0,1.6,2.7,2.4,2.2,2.4,2.7],True));story.append(Spacer(1,6));story.append(Paragraph(GENERAL,styles['note']))
 local=' '.join(seq+': '+notes[seq] for seq,rs in groups.items() if rs[0]['Material']==material and notes[seq])
 if local:story.append(Paragraph(local,styles['note']))
SimpleDocTemplate(str(ROOT/'18_series_combined_three_line_tables.pdf'),pagesize=A4,leftMargin=2*28.3464567,rightMargin=2*28.3464567,topMargin=1.8*28.3464567,bottomMargin=1.8*28.3464567).build(story,onFirstPage=page_number,onLaterPages=page_number)
(ROOT/'table_manifest.json').write_text(json.dumps({'source_commit':'8b4fdb81b5938720e263d802426745c982c4479c','source_workbook_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_sheet':'All_72_cells','sequence_order':order,'source_tubes':sorted(set(r['Tube_ID'] for r in raw)),'requested_metrics':METRICS,'rows':72,'valid_length_values':63,'valid_adjacent_pairs':40,'missing_acquisitions':6,'unavailable_source_results':3,'rounding':'Two decimals for display; unrounded extracted values retained in JSON/CSV/Excel.','root_length_transform':'Root_length_px / 1000, unit 10³ px','other_metrics':'Copied directly from the original per-sequence workbook fields, with no new averaging.','model_scope':'Existing V35 binary and V66 temporal U-Net estimates; not V90.','tables_by_sequence':18,'combined_material_tables':3,'notes_by_sequence':notes},ensure_ascii=False,indent=2))
print('Created two editable Word variants, Excel, two PDF previews, and full-precision audit data for 18 sequences / 72 period cells.')
