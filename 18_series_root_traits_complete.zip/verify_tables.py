from pathlib import Path
from docx import Document
from docx.oxml.ns import qn
from openpyxl import load_workbook
import fitz,json

r=Path(__file__).resolve().parent
records=json.loads((r/'extracted_values_full_precision.json').read_text());manifest=json.loads((r/'table_manifest.json').read_text());metrics=manifest['requested_metrics']
fmt=lambda v:f'{v:.2f}' if v is not None else '—'
count=0
for name,expected_tables,offset in [('18_series_individual_three_line_tables.docx',18,1),('18_series_combined_three_line_tables.docx',3,2)]:
 d=Document(r/name);assert len(d.tables)==expected_tables;expectedrows=iter(records)
 for table in d.tables:
  borders=table._tbl.tblPr.find(qn('w:tblBorders'));assert borders is not None
  for side in ['top','bottom']:assert borders.find(qn('w:'+side)).get(qn('w:val'))=='single'
  for side in ['left','right','insideH','insideV']:assert borders.find(qn('w:'+side)).get(qn('w:val'))=='nil'
  for cell in table.rows[0].cells:assert cell._tc.get_or_add_tcPr().find(qn('w:tcBorders')).find(qn('w:bottom')).get(qn('w:val'))=='single'
  for row in table.rows[1:]:
   source=next(expectedrows);assert row.cells[offset-1].text==source['Period']
   assert [c.text for c in row.cells[offset:]]==[fmt(source[m]) for m in metrics]
   count+=5
 assert next(expectedrows,None) is None
 paragraphs=list(d.paragraphs)+[p for t in d.tables for row in t.rows for c in row.cells for p in c.paragraphs]
 for p in paragraphs:
  for run in p.runs:
   if run.text:assert run.font.name=='Times New Roman' and str(run.font.color.rgb)=='000000'
 print('WORD VERIFIED',name,expected_tables,'tables')
x=load_workbook(r/'18_series_root_traits_tables.xlsx',data_only=True);it=x['Full_precision_72'].values;hdr=next(it);rest=[dict(zip(hdr,row)) for row in it]
assert len(rest)==72
for a,b in zip(rest,records):
 for m in metrics:
  if b[m] is None:assert a[m] is None
  else:assert abs(a[m]-b[m])<1e-11
pdfs={}
for name,npages in [('18_series_individual_three_line_tables.pdf',6),('18_series_combined_three_line_tables.pdf',3)]:
 d=fitz.open(r/name);assert len(d)==npages,(name,len(d));fonts=set();minsize=100
 for p in d:
  spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for line in b['lines'] for s in line['spans'] if s['text'].strip()]
  assert all(s['color']==0 and p.rect.contains(fitz.Rect(s['bbox'])) for s in spans)
  fonts.update(s['font'] for s in spans);minsize=min(minsize,*[s['size'] for s in spans])
 assert all('TimesNewRoman' in f for f in fonts)
 d[0].get_pixmap(matrix=fitz.Matrix(1.7,1.7)).save(r/(name.replace('.pdf','_preview.png')))
 pdfs[name]={'pages':len(d),'fonts':sorted(fonts),'minimum_font_pt':minsize,'all_text_black_and_within_page':True}
report={'source_workbook_sha256':manifest['source_workbook_sha256'],'observation_sequences':18,'source_tubes':8,'period_cells':72,'valid_length_records':63,'valid_adjacent_pairs':40,'numeric_metric_values':sum(record[m] is not None for record in records for m in metrics),'DOCX_metric_cells_checked':count,'Word_tables_have_only_three_horizontal_rules':True,'no_vertical_or_body_grid_lines':True,'numeric_values_match_source_at_display_precision':True,'full_precision_Excel_verified':True,'PDF_previews':pdfs}
(r/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
