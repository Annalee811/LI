"""Verify exact data assets, archived metrics, publication fonts and exports."""
from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
import fitz
ROOT=Path(__file__).resolve().parent
m=json.loads((ROOT/'composition_manifest.json').read_text())
assets=json.loads((ROOT/'asset_manifest.json').read_text())
colors={int(k):np.array(v,dtype=np.uint8) for k,v in assets['class_colors'].items()}
for r in m['placed_scientific_panels']:
 a=np.array(Image.open(ROOT/r['file']).convert('RGB'))
 assert list(a.shape)==r['shape']
 assert hashlib.sha256(a.tobytes()).hexdigest()==r['array_sha256']
for t in ['T1','T2','T3','T4']:
 rgb=np.array(Image.open(ROOT/f'assets/{t}_RGB.png').convert('RGB'))
 labels=np.array(Image.open(ROOT/f'assets/{t}_V90_labels.png'))
 overlay=rgb.copy()
 for code,color in colors.items():overlay[labels==code]=color
 assert np.array_equal(overlay,np.array(Image.open(ROOT/f'assets/{t}_V90_overlay.png')))
 b=np.array(Image.open(ROOT/f'assets/{t}_UNet_binary.png'))
 assert set(np.unique(b))=={0,255} and np.all(b[:,:,0]==b[:,:,1]) and np.all(b[:,:,0]==b[:,:,2])
large=np.array(Image.open(ROOT/'assets/T3_V90_large_RGB.png'))
lab=np.array(Image.open(ROOT/'assets/T3_V90_large_labels.png'))
for code,color in colors.items():large[lab==code]=color
assert np.array_equal(large,np.array(Image.open(ROOT/'assets/T3_V90_large_overlay.png')))

full_checks=0
old=json.loads((ROOT/'asset_verification.json').read_text())
for r in old['checks']:
 p=Path(r['file'])
 if p.exists():
  assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'];full_checks+=1
  t=p.stem[:2]
  if '/RGB/' in str(p):
   expected=np.array(Image.open(p).convert('RGB'))[590:850,1530:1830]
   assert np.array_equal(expected,np.array(Image.open(ROOT/f'assets/{t}_RGB.png')))
  else:
   expected=np.array(Image.open(p))[590:850,1530:1830]>0
   assert np.array_equal(expected,np.array(Image.open(ROOT/f'assets/{t}_UNet_binary.png'))[:,:,0]>0)
original=Path('/workspace/work/UNet_comparison_tight_layout_20261108')
verification=json.loads((ROOT/'source_verification.json').read_text())
v90_checks=0
for r in verification['checks']:
 p=original/r['file']
 if '/V90/' in r['file'] and p.exists():
  assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'];v90_checks+=1
  t=p.stem[:2];expected=np.array(Image.open(p))[590:850,1530:1830]
  assert np.array_equal(expected,np.array(Image.open(ROOT/f'assets/{t}_V90_labels.png')))
  if t=='T3':
   expected=np.array(Image.open(p))[300:1050,1000:1800]
   assert np.array_equal(expected,np.array(Image.open(ROOT/'assets/T3_V90_large_labels.png')))

binary=json.loads((ROOT/'binary_metrics.json').read_text())[0]
assert round(binary['Dice'],4)==.8788 and round(binary['R2_identity'],4)==.8911
temporal=json.loads((ROOT/'source_comparison.json').read_text())['summaries']
assert round(temporal['V66 U-Net']['macro']['Dice'],4)==.7132
assert round(temporal['V90 reviewed']['macro']['Dice'],4)==.8118
for key in ['Persistent','Extension','New']:assert len(m['chart_values'][key])==3
assert np.allclose(np.array([m['chart_values'][k] for k in ['Persistent','Extension','New']]).sum(0),100)

stem='Root_workflow_three_column_TimesNewRoman_white'
with fitz.open(ROOT/(stem+'.pdf')) as doc:
 assert len(doc)==1
 fonts={f[3].split('+')[-1] for f in doc[0].get_fonts()}
 assert fonts=={'TimesNewRomanPSMT','TimesNewRomanPS-BoldMT','TimesNewRomanPS-ItalicMT'}
 spans=[s for b in doc[0].get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
 assert all(s['color']==0 for s in spans)
 assert min(s['size'] for s in spans)>=8.99
 for s in spans:
  assert fitz.Rect(s['bbox']).x0>=0 and fitz.Rect(s['bbox']).x1<=doc[0].rect.width
  assert fitz.Rect(s['bbox']).y0>=0 and fitz.Rect(s['bbox']).y1<=doc[0].rect.height
 report={'panels':len(m['placed_scientific_panels']),'exact_asset_arrays':True,'archived_full_RGB_binary_hashes_checked':full_checks,'archived_V90_maps_verified':v90_checks,'font_names':sorted(fonts),'all_vector_text_black':True,'font_range_pt':[min(s['size'] for s in spans),max(s['size'] for s in spans)],'PDF_pages':1,'within_page':True,'binary_Dice':.8788,'length_R2':.8911,'temporal_macro_Dice':[.7132,.8118],'chart_scope':m['chart_scope'],'white_background':True,'exports':{}}
 for ext in ['png','jpg','tiff']:
  with Image.open(ROOT/(stem+'.'+ext)) as im:
   assert im.width==5669
   assert abs(im.height-round(m['figure_mm'][1]/25.4*600))<=1
   assert im.convert('RGB').getpixel((0,0))==(255,255,255)
   report['exports'][ext]={'pixels':list(im.size),'dpi':[float(v) for v in im.info.get('dpi',(0,0))]}
 doc[0].get_pixmap(matrix=fitz.Matrix(1.8,1.8),alpha=False).save(ROOT/'preview.png')
(ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
