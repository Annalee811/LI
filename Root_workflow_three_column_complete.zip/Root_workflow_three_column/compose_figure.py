"""Assemble the supplied three-column workflow with verified scientific panels."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle,Polygon,FancyBboxPatch
from matplotlib.transforms import Affine2D
import fitz

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--fonts-dir',type=Path,required=True)
args=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf','Times New Roman Italic.ttf']:
 font_manager.fontManager.addfont(str(args.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':9.5,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'svg.fonttype':'none'})
NX,NY=1452,1083
W,H=240,240*NY/NX
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,NX),ylim=(NY,0));ax.set_axis_off()
base=np.array(Image.open(ROOT/'schematic_base.png').convert('RGB'))
assert base.shape[:2]==(NY,NX)
near=(base.min(2)>=242)&((base.max(2).astype(int)-base.min(2).astype(int))<=18)
rgba=np.dstack([base,np.where(near,0,255).astype(np.uint8)])
ax.imshow(rgba,extent=(0,NX,NY,0),interpolation='nearest',aspect='auto',zorder=0)
def white(r):
 x0,y0,x1,y1=r;ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fc='white',ec='none',zorder=5))
def text(r,s,size=10,bold=False,italic=False,ha='center',clear=True):
 if clear:white(r)
 x0,y0,x1,y1=r
 return ax.text((x0+x1)/2 if ha=='center' else x0+2,(y0+y1)/2,s,fontsize=size,fontweight='bold' if bold else 'normal',fontstyle='italic' if italic else 'normal',ha=ha,va='center',color='black',linespacing=1.06,zorder=9)

# Exact assets and their hashes are recorded independently of the illustrative base.
placed=[]
def record(name,role,array):
 placed.append({'file':'assets/'+name,'role':role,'shape':list(array.shape),'array_sha256':hashlib.sha256(array.tobytes()).hexdigest()})
def panel(name,r,role,z=6):
 a=np.array(Image.open(ROOT/'assets'/name).convert('RGB'))
 x0,y0,x1,y1=r
 white((x0-3,y0-3,x1+3,y1+3))
 # Fit to the field without stretching the scientific image.
 scale=min((x1-x0)/a.shape[1],(y1-y0)/a.shape[0]);ww=a.shape[1]*scale;hh=a.shape[0]*scale
 xx=(x0+x1-ww)/2;yy=(y0+y1-hh)/2
 ax.imshow(a,extent=(xx,xx+ww,yy+hh,yy),interpolation='nearest',aspect='auto',zorder=z)
 ax.add_patch(Rectangle((xx,yy),ww,hh,fill=False,ec='black',lw=.55,zorder=z+.1))
 record(name,role,a)
def perspective(name,points,role):
 a=np.array(Image.open(ROOT/'assets'/name).convert('RGB'));hh,ww=a.shape[:2]
 (x0,y0),(x1,y1),(x2,y2),(x3,y3)=points
 ax.add_patch(Polygon(points,closed=True,fc='white',ec='none',zorder=5))
 trans=Affine2D.from_values((x1-x0)/ww,(y1-y0)/ww,(x3-x0)/hh,(y3-y0)/hh,x0,y0)
 im=ax.imshow(a,extent=(0,ww,hh,0),transform=trans+ax.transData,interpolation='nearest',aspect='auto',zorder=6)
 im.set_clip_path(Polygon(points,closed=True,transform=ax.transData))
 ax.add_patch(Polygon(points,closed=True,fill=False,ec='black',lw=.55,zorder=7))
 record(name,role,a)

# Four original RGB crops at the same physical field throughout T1--T4.
for i,(t,y0,y1) in enumerate([('T1',229,359),('T2',398,528),('T3',565,695),('T4',732,862)]):
 panel(t+'_RGB.png',(347,y0,490,y1),'Four-period actual RGB')
 text((340,y1+2,496,y1+34),t+' '+['(Seedling)','(Heading)','(Maturity)','(Senescence)'][i],10)

# Common-field image stack: repeated dates indicate an image stack, not extra data.
white((39,775,323,1020))
for t,r in [('T1',(43,779,180,912)),('T2',(76,800,215,933)),('T3',(116,822,256,955)),('T4',(146,843,288,978)),('T4',(177,868,320,1017))]:
 panel(t+'_RGB.png',r,'RoMa/common-field RGB stack')
 if r[0] in [146,177]:
  ax.add_patch(Rectangle((r[0],r[1]),r[2]-r[0],r[3]-r[1],fill=False,ec='#5297C3',lw=1,zorder=8))

# The source template uses perspective inputs in the network illustration.
perspective('T2_RGB.png',[(538,334),(614,273),(614,422),(538,483)],'U-Net actual RGB input')
panel('T2_UNet_binary.png',(887,313,1013,456),'U-Net actual binary output')
for t,name,x in [('T1','T1_RGB.png',530),('T2','T2_RGB.png',656),('T3','T3_UNet_binary.png',783),('T4','T4_V90_overlay.png',909)]:
 perspective(name,[(x,820),(x+97,750),(x+97,904),(x,974)],'Temporal '+t+' actual input/output')

# Larger real V90 crop shows all three classes without synthesizing root geometry.
white((1054,309,1425,649))
panel('T3_V90_large_overlay.png',(1058,319,1421,645),'V90 T3 RGB overlay, larger representative crop')

# All labels are actual black Times New Roman vector text in the PDF.
text((25,5,1426,139),'Continuous Monitoring and Automated Classification\nof Root System Dynamics via Deep Learning',18,True)
text((17,164,494,208),'1. IMAGE ACQUISITION & ALIGNMENT',11.4,True)
text((572,164,975,208),'2. DEEP LEARNING WORKFLOW',11.5,True)
text((1038,161,1438,222),'3. TEMPORAL CLASSIFICATION\n& DYNAMICS',11.4,True)
white((18,429,137,484))
ax.text(78,447,'Elymus',fontstyle='italic',fontsize=10.5,ha='center',va='center',zorder=9)
species=fitz.Font(fontfile=str(args.fonts_dir/'Times New Roman Italic.ttf'))
width=species.text_length('sibiricus',fontsize=10.5)*NX/(W/25.4*72)
ax.text(22,471,'sibiricus',fontstyle='italic',fontsize=10.5,ha='left',va='center',zorder=9)
ax.text(22+width+4,471,'L.',fontsize=10.5,ha='left',va='center',zorder=9)
text((155,660,314,695),'Minirhizotron',10.5)
text((68,733,296,770),'RoMa Alignment',11.5,True)
text((20,983,146,1037),'RoMa\nAlignment',10.5)
text((351,923,496,990),'Common Field\nof View (FoV)',10)
text((635,451,857,514),'Root Segmentation\n(U-Net)',11)
white((813,237,1014,298))
ax.add_patch(FancyBboxPatch((815,239),197,57,boxstyle='round,pad=0,rounding_size=16',fc='white',ec='black',lw=.6,zorder=6))
text((821,240,1006,295),'U-Net Dice: 0.8788\nR²: 0.8911',10,clear=False)
text((540,680,1017,715),'ConvLSTM + Graph Attention Network (GAT)',11,True)
for t,x in [('T1',582),('T2',709),('T3',837),('T4',962)]:text((x-30,1014,x+30,1041),t,10.5)
white((1068,247,1417,295))
ax.add_patch(FancyBboxPatch((1070,249),345,44,boxstyle='round,pad=0,rounding_size=16',fc='white',ec='black',lw=.6,zorder=6))
text((1076,251,1409,291),'Macro Dice: 0.7132 → 0.8118',11,clear=False)
text((1068,296,1419,315),'V66 → V90 reviewed workflow',9)
for s,r in [('Newly Emerged Root',(1137,658,1417,695)),('Elongating Root',(1137,696,1417,731)),('Persistent Root',(1137,733,1417,769))]:text(r,s,11,ha='left')
for y,color in [(677,'#F5CC3C'),(714,'#69AD52'),(751,'#5297C3')]:
 white((1071,y-13,1134,y+13))
 ax.add_patch(FancyBboxPatch((1075,y-9),54,18,boxstyle='round,pad=0,rounding_size=9',fc=color,ec='none',zorder=7))

# Replace the sample chart with coherent, archived 0353 series means.
white((1050,784,1437,1050))
text((1053,785,1435,824),'Root dynamics in series 0353',11,True)
traits=json.loads((ROOT/'series_traits.json').read_text())
series={r['Metric']:r['y'][1:] for r in traits if r['Material']=='0353'}
chart=fig.add_axes([1110/NX,1-995/NY,298/NX,158/NY],facecolor='white')
xs=np.arange(3);bottom=np.zeros(3)
colors={'Persistent':'#5297C3','Extension':'#69AD52','New':'#F5CC3C'}
for key in ['Persistent','Extension','New']:
 vals=np.array(series[key]);chart.bar(xs,vals,bottom=bottom,color=colors[key],width=.63,ec='white',lw=.5)
 if key=='Persistent':
  for x,val,b in zip(xs,vals,bottom):chart.text(x,b+val/2,f'{val:.1f}',ha='center',va='center',fontsize=9,color='black')
 bottom+=vals
assert np.allclose(bottom,100)
chart.set(ylim=(0,100),xlim=(-.6,2.6),ylabel='Root length (%)')
chart.set_xticks(xs,['T2','T3','T4']);chart.set_yticks([0,50,100]);chart.tick_params(labelsize=9,length=2,width=.6,pad=2)
chart.set_ylabel('Root length (%)',fontsize=9.5,labelpad=4)
chart.spines[['right','top']].set_visible(False)
for s in ['left','bottom']:chart.spines[s].set_linewidth(.6)
text((1053,1022,1437,1052),'Means across six observation positions',9)

stem='Root_workflow_three_column_TimesNewRoman_white'
for ext in ['png','pdf']:fig.savefig(ROOT/(stem+'.'+ext),dpi=600,facecolor='white')
fig.savefig(ROOT/(stem+'.tiff'),dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)
Image.open(ROOT/(stem+'.png')).convert('RGB').save(ROOT/(stem+'.jpg'),'JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
(ROOT/'composition_manifest.json').write_text(json.dumps({'figure_mm':[W,H],'placed_scientific_panels':placed,'font':'Times New Roman, true regular/bold/italic; all text black','raster_dpi':600,'chart_scope':'0353 series mean across six observation positions, T2–T4; not B3-only','chart_values':series,'temporal_macro_Dice':[0.713237098784388,0.8117740562710996],'binary_Dice':0.8787985060232514,'binary_length_R2':0.8910977158236053,'no_training_registration_or_new_predictions':True,'classification_colors_are_classes_not_instance_ownership':True},indent=2))
with fitz.open(ROOT/(stem+'.pdf')) as doc:
 doc[0].get_pixmap(matrix=fitz.Matrix(1.8,1.8),alpha=False).save(ROOT/'preview.png')
print('Created three-column publication workflow with exact scientific assets.')
