from pathlib import Path
import ast,io,json,zipfile,urllib.request,bisect,hashlib,csv
import numpy as np
from PIL import Image
ROOT=Path('/workspace/work/V66_V90_comparison_20261105');OLD=Path('/workspace/work/V90_class_accuracy_20261105');META=Path('/workspace/work/materials_methods_20261103/sources');COMMIT=json.loads((META/'core_commit.json').read_text())['sha']
source=(META.parent/'read_metadata_ranges.py').read_text();node=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='Reader');env={'io':io,'bisect':bisect,'urllib':__import__('urllib'),'COMMIT':COMMIT};exec(compile(ast.Module(body=[node],type_ignores=[]),'<range_reader>','exec'),env);Reader=env['Reader']
manifest=json.loads((META/'core/resources/03_temporal_V66/manifest.json').read_text());expected={x['file']:x for x in manifest['files']};reader=Reader('03_temporal_V66',manifest);checks=[]
with zipfile.ZipFile(reader) as z:
 for t in ['T2','T3','T4']:
  s=f'assets/expected/unet/{t}_classes.png';e=expected[s];p=ROOT/'V66_unet'/f'{t}_classes.png';p.parent.mkdir(exist_ok=True)
  b=p.read_bytes() if p.exists() else z.read(s);assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'];p.write_bytes(b);checks.append(dict(stage='03_temporal_V66',file=s,sha256=e['sha256'],verified=True))
print('Verified V66 U-Net final class maps',flush=True)
# Independently verify both reused reference and V90 output against frozen manifests.
for stage,prefix in [('03_temporal_V66','assets/evaluation_reference'),('04_ConvLSTM_GAT_V90','assets/expected')]:
 m=json.loads((META/'core/resources'/stage/'manifest.json').read_text());lookup={x['file']:x for x in m['files']}
 for t in ['T2','T3','T4']:
  s=f'{prefix}/{t}_classes.png';p=OLD/'sources'/stage/s;assert hashlib.sha256(p.read_bytes()).hexdigest()==lookup[s]['sha256'];checks.append(dict(stage=stage,file=s,sha256=lookup[s]['sha256'],verified=True))
cm_by={};period_by={};rows=[];summaries={}
classes=[(2,'新生根','Newly observed'),(3,'延伸根','Extending'),(1,'持续根','Persistent')]
for model in ['V66 U-Net','V90 reviewed']:
 cm=np.zeros((3,4),np.int64);per={}
 for t in ['T2','T3','T4']:
  g=np.array(Image.open(OLD/f'sources/03_temporal_V66/assets/evaluation_reference/{t}_classes.png'))
  p=np.array(Image.open(ROOT/'V66_unet'/f'{t}_classes.png' if model=='V66 U-Net' else OLD/f'sources/04_ConvLSTM_GAT_V90/assets/expected/{t}_classes.png'))
  use=np.isin(g,[1,2,3]);assert np.isin(p[use],[0,1,2,3]).all();a=np.bincount((g[use].astype(np.int64)-1)*4+np.where(p[use]==0,3,p[use]-1),minlength=12).reshape(3,4);cm+=a;per[t]=a.tolist()
 assert cm.sum()==468203
 records=[]
 for code,cn,en in classes:
  i=code-1;tp=int(cm[i,i]);fp=int(cm[:,i].sum()-tp);fn=int(cm[i].sum()-tp)
  r=dict(model=model,class_code=code,class_cn=cn,class_en=en,reference_pixels=int(cm[i].sum()),TP=tp,FP=fp,FN=fn,Precision=tp/(tp+fp),Recall=tp/(tp+fn),Dice=2*tp/(2*tp+fp+fn),IoU=tp/(tp+fp+fn));rows.append(r);records.append(r)
 macro={k:float(np.mean([r[k] for r in records])) for k in ['Precision','Recall','Dice','IoU']}
 summaries[model]=dict(overall_root_accuracy=float(np.trace(cm[:,:3])/cm.sum()),macro=macro,evaluated_root_pixels=int(cm.sum()),missed_roots=int(cm[:,3].sum()))
 cm_by[model]=cm.tolist();period_by[model]=per
# Confirm current V90 table has exactly the same metrics as the prior verified extraction.
prior=json.loads((OLD/'V90_class_metrics.json').read_text())
assert abs(prior['overall_root_accuracy']-summaries['V90 reviewed']['overall_root_accuracy'])<1e-14
for r in rows:
 if r['model']=='V90 reviewed':
  a=next(x for x in prior['classes'] if x['class_code']==r['class_code']);assert abs(r['Dice']-a['F1_Dice'])<1e-14
comparison=[]
for code,cn,en in classes:
 a=next(r for r in rows if r['model']=='V66 U-Net' and r['class_code']==code);b=next(r for r in rows if r['model']=='V90 reviewed' and r['class_code']==code)
 comparison.append(dict(class_cn=cn,class_en=en,reference_pixels=a['reference_pixels'],V66_Dice=a['Dice'],V90_Dice=b['Dice'],Dice_delta_pp=100*(b['Dice']-a['Dice']),V66_Precision=a['Precision'],V90_Precision=b['Precision'],V66_Recall=a['Recall'],V90_Recall=b['Recall'],V66_IoU=a['IoU'],V90_IoU=b['IoU']))
result=dict(source_commit=COMMIT,scope='T2–T4, common frozen reference B, root pixels only; V90 final structural/reviewed workflow',classes=comparison,per_class=rows,summaries=summaries,confusion=cm_by,confusion_by_period=period_by)
(ROOT/'V66_V90_comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));(ROOT/'source_verification.json').write_text(json.dumps(checks,indent=2))
for name,data in [('V66_V90_per_class.csv',rows),('V66_V90_side_by_side.csv',comparison)]:
 with (ROOT/name).open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
print(json.dumps(result,ensure_ascii=False,indent=2))
