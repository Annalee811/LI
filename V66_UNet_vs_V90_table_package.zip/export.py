from pathlib import Path
import json,csv,zipfile
from docx import Document
from docx.shared import Cm,Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from openpyxl import Workbook,load_workbook
from openpyxl.styles import Font,Alignment,Border,Side
ROOT=Path('/workspace/work/V66_V90_comparison_20261105');v=json.loads((ROOT/'V66_V90_comparison.json').read_text());keys=['Precision','Recall','Dice','IoU'];models=['V66 U-Net','V90 reviewed'];rows=[]
for category in ['Newly observed','Extending','Persistent','Macro-average']:
 for m in models:
  a=next(r for r in v['per_class'] if r['model']==m and r['class_en']==category) if category!='Macro-average' else v['summaries'][m]['macro']
  rows.append({'Root class':category,'Model':m,**{k:a[k] for k in keys}})
with (ROOT/'V66_V90_comparison_percent.csv').open('w',newline='',encoding='utf-8-sig') as f:
 out=[{**{'Root class':r['Root class'],'Model':r['Model']},**{k+' (%)':100*r[k] for k in keys}} for r in rows];w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
d=Document();s=d.sections[0];s.page_width=Cm(21);s.page_height=Cm(29.7);s.top_margin=s.bottom_margin=s.left_margin=s.right_margin=Cm(2.5)
st=d.styles['Normal'];st.font.name='Times New Roman';st.font.size=Pt(11);st.paragraph_format.line_spacing=1.15;st._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'SimSun')
p=d.add_paragraph();p.add_run('Table 4. ').bold=True;p.add_run('Comparison of V66 U-Net and the final reviewed V90 workflow for temporal root classification using common frozen reference B.')
t=d.add_table(rows=1,cols=6);t.autofit=False;t.alignment=WD_TABLE_ALIGNMENT.CENTER;widths=[3,3.2,2.45,2.45,2.45,2.45]
for c,w in zip(t.columns,widths):c.width=Cm(w)
b=OxmlElement('w:tblBorders')
for side in ['top','bottom','left','right','insideH','insideV']:
 e=OxmlElement('w:'+side);e.set(qn('w:val'),'nil');b.append(e)
t._tbl.tblPr.append(b)
headers=['Root class','Workflow','Precision\n(%)','Recall\n(%)','Dice\n(%)','IoU\n(%)']
for c,x in zip(t.rows[0].cells,headers):c.text=x
for r in rows:
 for c,x in zip(t.add_row().cells,[r['Root class'],r['Model']]+[f'{r[k]*100:.2f}' for k in keys]):c.text=x
for start in [1,3,5,7]:c=t.cell(start,0).merge(t.cell(start+1,0));c.text=rows[start-1]['Root class']
for i,row in enumerate(t.rows):
 row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
 for j,c in enumerate(row.cells):
  c.width=Cm(widths[j]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
  margin=OxmlElement('w:tcMar')
  for side in ['top','bottom','left','right']:
   e=OxmlElement('w:'+side);e.set(qn('w:w'),'90' if side in ['top','bottom'] else '55');e.set(qn('w:type'),'dxa');margin.append(e)
  c._tc.get_or_add_tcPr().append(margin)
  if i==0 or i==8:
   bd=OxmlElement('w:tcBorders')
   for edge in (['top','bottom'] if i==0 else ['bottom']):
    e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'10' if edge=='top' or i==8 else '5');e.set(qn('w:color'),'000000');bd.append(e)
   c._tc.get_or_add_tcPr().append(bd)
  for p in c.paragraphs:
   p.alignment=WD_ALIGN_PARAGRAPH.LEFT if j in [0,1] else WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=1.05
   for rr in p.runs:rr.font.name='Times New Roman';rr.font.size=Pt(10);rr.bold=i==0
  if i>0 and j>=2:
   a=rows[((i-1)//2)*2];bb=rows[((i-1)//2)*2+1];r=rows[i-1]
   for rr in c.paragraphs[0].runs:rr.bold=r[keys[j-2]]==max(a[keys[j-2]],bb[keys[j-2]])
notes=[f'Overall root-region classification accuracy: V66 U-Net, {100*v["summaries"][models[0]]["overall_root_accuracy"]:.2f}%; V90 reviewed, {100*v["summaries"][models[1]]["overall_root_accuracy"]:.2f}%.',
'Note: Metrics are pooled over 468,203 typed root pixels from T2–T4 using the same frozen reference B; true background and the T1 baseline are excluded. Macro-average is the unweighted mean over the three classes. Bold values are higher within each class/workflow pair. V90 includes learned refinement, structural decoding and explicit manual review; this comparison does not isolate an architectural contribution. The revised reference includes U-Net-assisted foreground outlines, and results describe within-development-position reference agreement rather than independent cross-tube performance.']
for text in notes:
 p=d.add_paragraph(text);p.paragraph_format.space_before=Pt(7)
 for rr in p.runs:rr.font.size=Pt(9)
d.core_properties.title='V66 U-Net versus V90 reviewed workflow';d.core_properties.author='';d.save(ROOT/'V66_UNet_vs_V90_SCI_table.docx')
# Workbook gives the main table plus explicit Dice deltas and raw confusion matrices.
w=Workbook();s=w.active;s.title='Main_comparison';s.append(['Root class','Workflow']+keys)
for r in rows:s.append([r['Root class'],r['Model']]+[r[k] for k in keys])
for row in s.iter_rows(min_row=2,min_col=3):
 for c in row:c.number_format='0.00%'
s=w.create_sheet('Dice_changes');s.append(['Root class','V66 Dice','V90 Dice','Change (percentage points)'])
for a in v['classes']:s.append([a['class_en'],a['V66_Dice'],a['V90_Dice'],a['Dice_delta_pp']])
a=v['summaries'][models[0]]['macro']['Dice'];b=v['summaries'][models[1]]['macro']['Dice'];s.append(['Macro-average',a,b,100*(b-a)])
for row in s.iter_rows(min_row=2):
 row[1].number_format=row[2].number_format='0.00%';row[3].number_format='+0.00;-0.00;0.00'
s=w.create_sheet('Overall_accuracy');s.append(['Workflow','Overall root accuracy','Evaluated root pixels'])
for m in models:s.append([m,v['summaries'][m]['overall_root_accuracy'],468203]);s.cell(s.max_row,2).number_format='0.00%'
s=w.create_sheet('Confusion_counts');s.append(['Workflow','Reference class','Predicted persistent','Predicted new','Predicted extension','Missed'])
for m in models:
 for name,a in zip(['Persistent','Newly observed','Extending'],v['confusion'][m]):s.append([m,name]+a)
s=w.create_sheet('Provenance');s.append(['Item','Record'])
for a,b in [('Reference','Same frozen B, T2–T4, 468203 root pixels; baseline/background excluded'),('Source commit',v['source_commit']),('V90 scope','Final learned/structured/manually reviewed workflow'),('Interpretation','Within-development-position reference agreement; reference includes U-Net-assisted foreground outlines'),('Execution','Archived class maps only; no retraining or inference')]:s.append([a,b])
for s in w:
 s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
 for row in s:
  for c in row:c.font=Font(name='Times New Roman',size=11);c.alignment=Alignment(vertical='center')
 for c in s[1]:c.font=Font(name='Times New Roman',size=11,bold=True);c.border=Border(top=Side(style='thin'),bottom=Side(style='thin'))
 for col in s.columns:s.column_dimensions[col[0].column_letter].width=min(80,max(18,max(len(str(c.value or '')) for c in col)+2))
w.save(ROOT/'V66_UNet_vs_V90_metrics.xlsx')
assert load_workbook(ROOT/'V66_UNet_vs_V90_metrics.xlsx').worksheets[0]['E3'].value==v['summaries']['V90 reviewed']['macro']['Dice'] or abs(load_workbook(ROOT/'V66_UNet_vs_V90_metrics.xlsx').worksheets[0]['E3'].value-v['classes'][0]['V90_Dice'])<1e-14
check=Document(ROOT/'V66_UNet_vs_V90_SCI_table.docx');assert len(check.tables[0].rows)==9 and check.tables[0].cell(4,4).text=='54.57'
(ROOT/'README.txt').write_text('V66 U-Net / V90 reviewed comparison. All scores use exactly the same T2–T4 frozen common reference B (468,203 manually typed root pixels) and exclude true background and T1 baseline. Three V66 maps and the reused reference/V90 maps were checked against frozen resource SHA-256 values at commit '+v['source_commit']+'. No neural model training or inference was run.\n\nV90 is the final learned/structured/manually reviewed workflow; differences do not isolate ConvLSTM/GAT effects. The reference includes U-Net-assisted foreground outlines and was revised during development; these are within-position reference-agreement scores, not independent cross-tube accuracy. Dice improvements are descriptive percentage-point differences, not significance tests.\n')
with zipfile.ZipFile(ROOT/'V66_UNet_vs_V90_table_package.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ['V66_UNet_vs_V90_SCI_table.docx','V66_UNet_vs_V90_metrics.xlsx','V66_V90_comparison.json','V66_V90_per_class.csv','V66_V90_side_by_side.csv','V66_V90_comparison_percent.csv','source_verification.json','README.txt','compare.py','export.py']:z.write(ROOT/n,n)
print('Exported publication table, comparison workbook, CSV and source records.')
