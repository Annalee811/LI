"""Vector schematic of the implemented temporal root workflow.

Real RGB crops and a cached decoded mask are display examples only.
This script does not run registration, inference or training.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Rectangle,Circle,Ellipse

W=Path(__file__).resolve().parent
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--fonts',type=Path,default=Path('/workspace/work/root_workflow_real_assets_20261109/fonts'));args=ap.parse_args()
 for name in ['Times New Roman.ttf','Times New Roman Bold.ttf','Times New Roman Italic.ttf']:font_manager.fontManager.addfont(str(args.fonts/name))
 plt.rcParams.update({'font.family':'Times New Roman','font.size':8,'text.color':'black','axes.labelcolor':'black','pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white','mathtext.fontset':'custom','mathtext.rm':'Times New Roman','mathtext.it':'Times New Roman:italic','mathtext.bf':'Times New Roman:bold'})
 fig=plt.figure(figsize=(190/25.4,112/25.4),facecolor='white');ax=fig.add_axes([0,0,1,1]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
 C={'frozen':'#F2F4F5','frozen_edge':'#89949C','learned':'#EDF3F7','blue':'#3F7091','rule':'#F7F1F5','plum':'#806274','new':'#C58D31','line':'#4D555B'}
 boxes=[];texts=[]
 def text(x,y,s,size=8,weight='normal',ha='center',va='center',**kw):
  t=ax.text(x,y,s,fontsize=size,fontweight=weight,ha=ha,va=va,linespacing=1.3,color='black',**kw);texts.append(t);return t
 def box(x,y,w,h,kind='frozen',dashed=False,rounded=True):
  edge=C['blue']if kind=='learned'else C['plum']if kind=='rule'else C['frozen_edge'];face=C[kind]if kind in ['learned','rule','frozen']else'white'
  p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.003,rounding_size=0.008'if rounded else'square,pad=0',facecolor=face,edgecolor=edge,lw=.75,linestyle=(0,(3,2))if dashed else'solid',zorder=1)
  ax.add_patch(p);boxes.append(p);return p
 def arrow(points,color=None,dashed=False,width=.85):
  color=color or C['line']
  for a,b in zip(points[:-2],points[1:-1]):ax.plot([a[0],b[0]],[a[1],b[1]],color=color,lw=width,ls=(0,(3,2))if dashed else'-',zorder=2)
  a,b=points[-2:];p=FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=7.5,lw=width,color=color,linestyle=(0,(3,2))if dashed else'solid',zorder=3,shrinkA=0,shrinkB=0);ax.add_patch(p)
 def image(rgb,x,y,w):
  h=w*190/112;ax.imshow(rgb,extent=(x,x+w,y,y+h),interpolation='nearest',aspect='auto',zorder=2);ax.add_patch(Rectangle((x,y),w,h,fill=False,edgecolor='#879097',lw=.45,zorder=3));return h
 def line(points,color,lw=1.6,ls='solid',z=4):ax.plot(*np.array(points).T,color=color,lw=lw,ls=ls,solid_capstyle='round',solid_joinstyle='round',zorder=z)
 # Stage headings, aligned at the same baseline.
 for x,label,title,center in [(.014,'A','Inputs & priors',.125),(.270,'B','Learned network',.432),(.630,'C','Structural decoding',.719),(.835,'D','Outputs',.921)]:
  text(x,.955,label,11.5,'bold',ha='left');text(center,.955,title,8.5,'bold')
 # A: actual same-field images, all four dates.
 data=np.load(W/'Workflow_RGB_and_mask_cache.npz');thumb=.086
 for i,t in enumerate(['T1','T2','T3','T4']):
  row,col=divmod(i,2);x=.026+col*.105;y=.707-row*.192;h=image(data[t+'_RGB'],x,y,thumb);text(x+thumb/2,y+h+.014,t,7.2,'bold')
 text(.122,.493,'Aligned common field',7.3)
 box(.025,.315,.199,.133,'frozen');text(.1245,.424,'Frozen preprocessing',7.8,'bold')
 text(.1245,.369,'U-Net root masks\nV66 temporal prior\nRoot nodes, edges & frame maps',7.0)
 arrow([(.125,.478),(.125,.452)])
 # One shared feature bus feeds frame context and graph inputs.
 arrow([(.227,.382),(.250,.382),(.250,.715),(.290,.715)])
 arrow([(.250,.533),(.294,.533)]);ax.add_patch(Circle((.250,.533),.0024,fc=C['line'],ec='none',zorder=4))
 # B: full network; the recurrent+graph pair is an explicitly grouped module.
 outer=box(.277,.223,.302,.660,'white');outer.set_edgecolor('#BAC9D3')
 text(.428,.860,'Full model · shared frame CNN',7.8,'bold')
 box(.287,.411,.282,.424,'learned');text(.428,.811,'ConvLSTM + GAT joint module',8.0,'bold')
 text(.428,.773,'ConvLSTM: temporal memory',7.3)
 for i,t in enumerate(['T1','T2','T3','T4']):
  x=.295+i*.067;box(x,.681,.054,.066,'white');text(x+.027,.714,t,7.1,'bold')
  if i<3:arrow([(x+.054,.714),(x+.065,.714)],color=C['blue'],width=.75)
 text(.353,.657,'Temporal\ncontext',6.5)
 text(.495,.657,'Node sampling\n& fusion',6.5)
 arrow([(.428,.678),(.428,.631)],color=C['blue'])
 box(.298,.446,.260,.183,'white');text(.428,.606,'GAT: gated message passing',7.5,'bold')
 nodes=np.array([[.321,.509],[.345,.561],[.374,.512],[.405,.559],[.416,.489]])
 for a,b,lw in [(0,1,.7),(0,2,1.3),(1,2,1.4),(1,3,.55),(2,3,1.3),(2,4,.6),(3,4,1.4)]:line([nodes[a],nodes[b]],C['blue'],lw)
 for x,y in nodes:ax.add_patch(Ellipse((x,y),.012,.012*190/112,fc='#C7D9E5',ec=C['blue'],lw=.65,zorder=5))
 box(.455,.493,.086,.065,'learned');text(.498,.526,'Gate',7.5,'bold')
 arrow([(.453,.527),(.403,.527)],color=C['blue'],dashed=True,width=.8)
 text(.494,.579,'Identity affinity',6.5);text(.428,.461,'2 attention layers · shared identity features',6.6)
 # All supervised heads use the full neural features.
 arrow([(.428,.443),(.428,.359)],color=C['blue'])
 box(.290,.239,.276,.117,'learned');text(.428,.335,'Prediction heads',7.9,'bold')
 text(.428,.302,'Class refinement: P / N / E',7.2);text(.428,.270,'Identity links · root state · junction pairs',7.0)
 # C: a fixed neural forward provides evidence to both decoding stages.
 arrow([(.568,.297),(.607,.297),(.607,.689),(.632,.689)])
 arrow([(.607,.369),(.632,.369)],width=.75)
 text(.601,.773,'Fixed neural evidence',6.4,rotation=90)
 box(.636,.562,.158,.266,'rule');text(.715,.799,'Axis constraint',8.0,'bold')
 line([(.679,.741),(.686,.711),(.692,.683),(.697,.657)],C['blue'],2.0)
 line([(.691,.686),(.718,.710),(.746,.722)],C['new'],1.8)
 ax.add_patch(Ellipse((.691,.686),.008,.008*190/112,fc='white',ec=C['plum'],lw=.7,zorder=5))
 text(.715,.607,'Historical correspondence\nRoot-axis continuity',6.9)
 arrow([(.715,.559),(.715,.497)],color=C['plum'])
 box(.636,.239,.158,.255,'rule');text(.715,.468,'Junction constraint',7.8,'bold')
 line([(.670,.431),(.701,.398),(.752,.377)],C['blue'],1.8)
 line([(.671,.375),(.701,.398),(.746,.429)],C['new'],1.8)
 ax.add_patch(Ellipse((.701,.398),.012,.012*190/112,fc='white',ec=C['plum'],lw=.8,zorder=6))
 text(.715,.292,'Branch/crossing ownership\nLocal class consistency',6.8)
 # D: final mapping is explicitly after the three-class internal decoder.
 arrow([(.797,.366),(.819,.366),(.819,.774),(.841,.774)],color=C['plum'])
 box(.846,.711,.143,.117,'frozen');text(.9175,.803,'Two-class mapping',7.8,'bold');text(.9175,.755,'N → New\nP + E → Existing',7.2)
 arrow([(.918,.708),(.918,.692)])
 text(.918,.678,'RGB overlay · T2',7.2,'bold')
 rgb=data['T2_RGB'];mask=data['T2_final_class'];overlay=rgb.copy()
 for selected,name in [(mask==2,'new'),(np.isin(mask,[1,3]),'blue')]:
  col=np.array([int(C[name][j:j+2],16)for j in [1,3,5]]);overlay[selected]=np.rint(.9*col+.1*rgb[selected]).astype(np.uint8)
 assert np.array_equal(overlay[mask==0],rgb[mask==0])
 image(overlay,.844,.399,.146)
 # A native-pixel scale bar drawn with vector marks.
 bar=.146*50/256;line([(.851,.411),(.851+bar,.411)],'white',1.6);text(.851,.426,'50 px',6.0,ha='left',bbox={'facecolor':'white','edgecolor':'none','pad':.5,'alpha':.95})
 line([(.846,.375),(.862,.375)],C['new'],2.4);text(.867,.375,'New roots',7.0,'bold',ha='left')
 line([(.846,.350),(.862,.350)],C['blue'],2.4);text(.867,.350,'Existing roots',7.0,'bold',ha='left')
 box(.846,.239,.143,.079,'frozen');text(.918,.279,'Axis IDs\nConfidence flags',7.1)
 arrow([(.797,.280),(.842,.280)],color=C['plum'],width=.75)
 # A distinct supervision branch; targets do not enter the inference pathway.
 box(.025,.099,.541,.074,'white',dashed=True);text(.047,.136,'Training only',7.6,'bold',ha='left')
 text(.177,.136,'Class, identity, junction & root-state supervision',7.1,ha='left')
 arrow([(.428,.176),(.428,.219)],color=C['blue'],dashed=True,width=.8)
 for x,kind,label in [(.635,'frozen','Frozen'),(.759,'learned','Learned'),(.884,'rule','Rule-based')]:
  box(x,.123,.020,.027,kind);text(x+.025,.136,label,6.8,ha='left')
 text(.500,.045,'Offline sequence decoding: later frames may inform earlier states.  P: persistent; N: new; E: extending.',7.0)
 # Structural safeguards and export.
 fig.canvas.draw();renderer=fig.canvas.get_renderer();bad=[]
 for t in texts:
  bb=t.get_window_extent(renderer)
  if bb.x0<-.5 or bb.y0<-.5 or bb.x1>fig.bbox.width+.5 or bb.y1>fig.bbox.height+.5:bad.append(t.get_text())
 assert not bad,('Clipped text',bad)
 for ext in ['pdf','svg','png','jpg','tif']:
  kw={'dpi':600,'facecolor':'white'}
  if ext=='jpg':kw['pil_kwargs']={'quality':98,'subsampling':0}
  if ext=='tif':kw['pil_kwargs']={'compression':'tiff_lzw'}
  fig.savefig(W/f'V90_workflow_schematic.{ext}',**kw)
 fig.savefig(W/'Workflow_preview.png',dpi=220,facecolor='white');plt.close(fig)
 (W/'Diagram_checks.json').write_text(json.dumps({'figure_mm':[190,112],'raster_dpi':600,'font':'Times New Roman, black','background':'white','joint_module':'ConvLSTM + GAT','gate_location':'Inside GAT attention aggregation','three_class_internal_head':True,'two_class_mapping':'new=N; existing=P+E','Axis_and_Junction':'Fixed-rule decoding guided by Full neural outputs and learned features','offline_future_context_disclosed':True,'RGB_source':'Real B3 same-field crops, see Image_provenance.json','output_example':'Actual cached T2 mask after axis+junction decoding, grouped to two classes for display','root_geometry_modified':False,'source_images_or_models_modified':False,'training_or_inference_rerun':False,'all_text_within_canvas':True},indent=2))
 print('WORKFLOW_SCHEMATIC_COMPLETE',flush=True)
if __name__=='__main__':main()
