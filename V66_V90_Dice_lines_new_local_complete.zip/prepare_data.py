"""Prepare exact archived labels and one common RGB crop; no inference or relabelling."""
from pathlib import Path
import argparse,hashlib,json,shutil
import numpy as np
from PIL import Image
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source-dir',type=Path,required=True,help='Verified V66_V90_same_field source bundle root')
a=p.parse_args();root=Path(__file__).resolve().parent;src=a.source_dir
checks=json.loads((src/'source_verification.json').read_text())
for rec in checks['checks']:assert hashlib.sha256((src/rec['file']).read_bytes()).hexdigest()==rec['sha256']
shutil.copy2(src/'source_comparison.json',root/'source_comparison.json')
(root/'source_verification.json').write_text(json.dumps(checks,indent=2)+'\n')
roi=[1000,500,1480,760];x0,y0,x1,y1=roi
arrays={};crops=[];full=[];(root/'local_crops').mkdir(exist_ok=True)
for t in ['T1','T2','T3','T4']:
 rgb=np.array(Image.open(src/f'sources/RGB/{t}_RGB.png').convert('RGB'))
 crop=rgb[y0:y1,x0:x1].copy();assert crop.shape==(260,480,3)
 rel=f'local_crops/{t}_RGB.png';Image.fromarray(crop).save(root/rel)
 crops.append({'period':t,'group':'RGB','file':rel,'shape':list(crop.shape),'array_sha256':hashlib.sha256(crop.tobytes()).hexdigest()})
 for g in ['reference','V66','V90']:
  arr=np.array(Image.open(src/f'sources/{g}/{t}_classes.png'));key=g+'_'+t;arrays[key]=arr
  full.append({'key':key,'shape':list(arr.shape),'array_sha256':hashlib.sha256(arr.tobytes()).hexdigest()})
  crop=arr[y0:y1,x0:x1].copy();rel=f'local_crops/{t}_{g}_classes.png';Image.fromarray(crop).save(root/rel)
  crops.append({'period':t,'group':g,'file':rel,'shape':list(crop.shape),'array_sha256':hashlib.sha256(crop.tobytes()).hexdigest()})
np.savez_compressed(root/'evaluation_arrays.npz',**arrays)
manifest={'position':'0353-2-B3','ROI_xyxy':roi,'ROI_size':[480,260],'same_coordinates_all_periods':True,'selection':'Reference morphology and class coverage only; no ranking of V90 improvement. Candidate ROIs extending outside image boundaries were rejected.','reference':'Frozen evaluation B: manual temporal categories with pre-existing U-Net-assisted binary outline refinement.','V66':'Archived U-Net temporal head output','V90':'Final learned, structural-decoded and manually reviewed workflow; not neural-only output.','source_repository':'Annalee811/Temporal-segmentation-model','source_commit':checks['source_commit'],'full_label_arrays':full,'crops':crops,'T1':'Baseline, excluded from temporal scores.'}
(root/'data_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Verified 16 source file hashes; prepared 12 exact full label arrays and 16 local crops.')
