"""Verify genuine per-date Dice, shared field, unchanged labels/backgrounds and exports."""
from pathlib import Path
import json,hashlib,csv
import numpy as np
from PIL import Image
import fitz
R=Path(__file__).resolve().parent;d=json.loads((R/'data_manifest.json').read_text());f=json.loads((R/'figure_manifest.json').read_text());m=json.loads((R/'temporal_metrics.json').read_text());s=json.loads((R/'source_comparison.json').read_text());a=np.load(R/'evaluation_arrays.npz')
for rec in d['full_label_arrays']:assert hashlib.sha256(a[rec['key']].tobytes()).hexdigest()==rec['array_sha256']
for group,key in [('V66','V66 U-Net'),('V90','V90 reviewed')]:
 total=np.zeros((3,4),np.int64)
 for t in ['T2','T3','T4']:
  g=a['reference_'+t];p=a[group+'_'+t];v=(g>=1)&(g<=3)
  cm=np.bincount((g[v].astype(int)-1)*4+np.where((p[v]>=1)&(p[v]<=3),p[v].astype(int)-1,3),minlength=12).reshape(3,4)
  assert np.array_equal(cm,m['per_date_confusion'][group+'_'+t]);total+=cm
  for code in [2,3,1]:
   row=next(q for q in m['rows'] if q['workflow']==group and q['period']==t and q['class_code']==code)
   j=code-1;tp=int(cm[j,j]);fp=int(cm[:,j].sum()-tp);fn=int(cm[j].sum()-tp)
   assert (tp,fp,fn)==(row['TP'],row['FP'],row['FN'])
   if cm[j].sum()==0:assert row['Dice'] is None
   else:assert abs(row['Dice']-2*tp/(2*tp+fp+fn))<1e-12
 assert total.sum()==468203 and np.array_equal(total,s['confusion'][key])
for plot in f['plots']:
 for period,val in zip(plot['periods'],plot['Dice_percent']):
  row=next(q for q in m['rows'] if q['workflow']==plot['workflow'] and q['period']==period and q['class_code']==plot['class_code'])
  if row['Dice'] is None:assert val is None
  else:assert abs(row['Dice']*100-val)<1e-12
assert len(f['plots'])==6 and len(m['rows'])==18
with (R/'temporal_Dice.csv').open(encoding='utf-8-sig',newline='') as file:
 rows=list(csv.DictReader(file));assert len(rows)==18
 for row,q in zip(rows,m['rows']):
  assert row['workflow']==q['workflow'] and row['period']==q['period'] and int(row['class_code'])==q['class_code']
  if q['Dice'] is None:assert row['Dice']==''
  else:assert abs(float(row['Dice'])-q['Dice'])<1e-12
assert d['ROI_xyxy']==[1000,500,1480,760]==f['ROI_xyxy']
x0,y0,x1,y1=d['ROI_xyxy']
for rec in d['crops']:
 im=np.array(Image.open(R/rec['file']));assert list(im.shape)==rec['shape'] and im.shape[:2]==(260,480)
 assert hashlib.sha256(im.tobytes()).hexdigest()==rec['array_sha256']
 if rec['group']!='RGB':assert np.array_equal(im,a[rec['group']+'_'+rec['period']][y0:y1,x0:x1])
colors={int(k):np.array([int(v[i:i+2],16) for i in [1,3,5]],np.uint8) for k,v in f['colors'].items()}
for rec in f['local_overlays']:
 t=rec['period'];group=rec['group'];rgb=np.array(Image.open(R/f'local_crops/{t}_RGB.png'));lab=np.array(Image.open(R/f'local_crops/{t}_{group}_classes.png'));expect=rgb.copy()
 for code,col in colors.items():expect[lab==code]=col
 im=np.array(Image.open(R/rec['file']));assert np.array_equal(im,expect) and np.array_equal(im[lab==0],rgb[lab==0])
 assert hashlib.sha256(im.tobytes()).hexdigest()==rec['array_sha256']
assert f['image_panels']==16 and f['shared_RGB_columns']==f['shared_human_reference_columns']==1 and not f['full_field_panels']
with fitz.open(R/(f['stem']+'.pdf')) as doc:
 assert len(doc)==1;page=doc[0]
 fonts={r[3].split('+')[-1] for r in page.get_fonts()};assert fonts=={'TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'}
 spans=[s for b in page.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
 assert all(s['color']==0 for s in spans) and min(s['size'] for s in spans)>=8.99
 for s in spans:
  b=fitz.Rect(s['bbox']);assert b.x0>=0 and b.y0>=0 and b.x1<=page.rect.width and b.y1<=page.rect.height
 pdftext=page.get_text();assert pdftext.count('Original RGB')==pdftext.count('Human reference')==1
 assert 'n.a.' in pdftext
exports={}
for ext in ['jpg','png','tiff']:
 with Image.open(R/(f['stem']+'.'+ext)) as im:
  assert abs(im.width-round(220/25.4*600))<=1 and abs(im.height-round(186/25.4*600))<=1
  assert im.convert('RGB').getpixel((0,0))==(255,255,255)
  exports[ext]={'pixels':list(im.size),'dpi':[float(v) for v in im.info.get('dpi',[])]}
report={'three_class_line_plots':True,'two_workflows_per_plot':True,'real_per_date_Dice_values_verified':16,'unavailable_T4_extension_points':2,'no_zero_or_synthetic_Dice_for_absent_reference_class':True,'pooled_counts_preserved':True,'common_reference_root_pixels_T2_T4':468203,'full_label_arrays_hash_verified':12,'same_ROI_xyxy_all_dates':[1000,500,1480,760],'RGB_background_and_label_geometry_unchanged':True,'panels':16,'full_field_panels':False,'fonts':sorted(fonts),'black_text':True,'font_range_pt':[min(s['size'] for s in spans),max(s['size'] for s in spans)],'page_mm':[220,186],'all_text_within_page':True,'exports':exports,'new_training_registration_inference':False}
(R/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
