"""Three per-class temporal Dice plots with four-date shared-field RGB overlays."""
from pathlib import Path
import argparse,json,csv,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,patheffects
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.text import Text
import fitz
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);args=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(args.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':10,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'axes.linewidth':.6})
d=json.loads((R/'data_manifest.json').read_text());src=json.loads((R/'source_comparison.json').read_text());arr=np.load(R/'evaluation_arrays.npz')
for rec in d['full_label_arrays']:assert hashlib.sha256(arr[rec['key']].tobytes()).hexdigest()==rec['array_sha256']
COLORS={1:'#3F75C4',2:'#E69F35',3:'#B64E8B',4:'#FFFFFF',255:'#808890'}
NAMES={1:'Persistent',2:'Newly emerged',3:'Elongating'}
rows=[];confusions={};pooled={}
for group,key in [('V66','V66 U-Net'),('V90','V90 reviewed')]:
 total=np.zeros((3,4),np.int64)
 for t in ['T2','T3','T4']:
  g=arr['reference_'+t];pred=arr[group+'_'+t];v=(g>=1)&(g<=3)
  cc=np.where((pred[v]>=1)&(pred[v]<=3),pred[v].astype(int)-1,3)
  cm=np.bincount((g[v].astype(int)-1)*4+cc,minlength=12).reshape(3,4)
  confusions[group+'_'+t]=cm.tolist();total+=cm
  for code in [2,3,1]:
   j=code-1;tp=int(cm[j,j]);fp=int(cm[:,j].sum()-tp);fn=int(cm[j].sum()-tp);support=int(cm[j].sum())
   rows.append({'workflow':group,'period':t,'class_code':code,'class':NAMES[code],'reference_pixels':support,'TP':tp,'FP':fp,'FN':fn,'Dice':2*tp/(2*tp+fp+fn) if support>0 else None,'status':'evaluated' if support>0 else 'not evaluated: no reference positives'})
 assert total.sum()==468203 and np.array_equal(total,src['confusion'][key]);pooled[group]=total.tolist()
 for q in [q for q in src['per_class'] if q['model']==key]:
  j=q['class_code']-1;tp=int(total[j,j]);fp=int(total[:,j].sum()-tp);fn=int(total[j].sum()-tp)
  assert (tp,fp,fn)==(q['TP'],q['FP'],q['FN'])
  assert abs(2*tp/(2*tp+fp+fn)-q['Dice'])<1e-12
with (R/'temporal_Dice.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(R/'temporal_metrics.json').write_text(json.dumps({'scope':'Full archived field at each date, typed reference-root pixels only, common reference B; not ROI-only scores.','T1_excluded':True,'no_reference_positive_policy':'Dice not displayed for a class/date with zero reference support, regardless of predicted positives. False positives remain in counts and pooled scores.','rows':rows,'per_date_confusion':confusions,'pooled_confusion':pooled},indent=2)+'\n')
W,H=220,186
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
def txt(x,y,s,size=10,ha='left',bold=False):
 return fig.text(x/W,1-y/H,s,ha=ha,va='center',fontsize=size,fontweight='bold' if bold else 'normal',color='black')
txt(3,5.5,'A',13,bold=True);txt(11,5.5,'Temporal class agreement',12,bold=True)
fig.legend(handles=[Line2D([],[],color='#4F5965',ls='--',marker='o',mfc='white',ms=4,lw=1.3,label='V66'),Line2D([],[],color='#4F5965',ls='-',marker='o',mfc='#4F5965',ms=4,lw=1.3,label='V90')],loc='center',bbox_to_anchor=(.82,1-5.5/H),frameon=False,ncol=2,fontsize=10,handlelength=2,columnspacing=1.5)
plot_records=[]
for j,code in enumerate([2,3,1]):
 left=15+j*70;cw=54
 txt(left+cw/2,13.5,NAMES[code],11.5,ha='center',bold=True)
 ax=fig.add_axes([left/W,1-49/H,cw/W,31/H])
 ax.set(xlim=(1.8,4.2),ylim=(0,110));ax.set_xticks([2,3,4],['T2','T3','T4']);ax.set_yticks([0,50,100])
 if j==0:ax.set_ylabel('Dice (%)',fontsize=10,labelpad=2)
 ax.tick_params(axis='both',length=2.5,width=.5,pad=2,labelsize=10)
 ax.spines[['top','right']].set_visible(False);ax.spines['left'].set_color('#858B92');ax.spines['bottom'].set_color('#858B92')
 ax.yaxis.grid(True,color='#E2E5E8',lw=.55);ax.set_axisbelow(True)
 color=COLORS[code]
 for group in ['V66','V90']:
  rr=[next(r for r in rows if r['workflow']==group and r['class_code']==code and r['period']==t) for t in ['T2','T3','T4']]
  vals=[r['Dice']*100 if r['Dice'] is not None else np.nan for r in rr]
  c=.72*np.array(matplotlib.colors.to_rgb(color))+.28 if group=='V66' else color
  ax.plot([2,3,4],vals,color=c,ls='--' if group=='V66' else '-',marker='o',ms=4.5,mfc='white' if group=='V66' else c,mec=c,mew=1,lw=1.5,zorder=3)
  for x,v,t in zip([2,3,4],vals,['T2','T3','T4']):
   if np.isfinite(v):
    other=next(r['Dice']*100 for r in rows if r['workflow']!=group and r['class_code']==code and r['period']==t)
    above=v>=other
    ax.annotate(f'{v:.1f}',(x,v),xytext=(0,6 if above else -9),textcoords='offset points',ha='center',va='bottom' if above else 'top',fontsize=9,color='black')
  plot_records.append({'class_code':code,'workflow':group,'periods':['T2','T3','T4'],'Dice_percent':[float(v) if np.isfinite(v) else None for v in vals]})
 if code==3:ax.text(4,16,'n.a.',ha='center',va='center',fontsize=9,color='black')

txt(3,60,'B',13,bold=True);txt(11,60,'Matched local comparison',12,bold=True)
fig.legend(handles=[Patch(fc=COLORS[c],ec='none',label=NAMES[c]) for c in [2,3,1]],loc='center',bbox_to_anchor=(.731,1-60/H),ncol=3,frameon=False,fontsize=9.5,handlelength=.9,handletextpad=.45,columnspacing=1.1)
LEFT,CW,GAP=12,49,1.5;PH=CW*260/480
for j,n in enumerate(['Original RGB','Human reference','V66','V90']):txt(LEFT+j*(CW+GAP)+CW/2,68,n,10.5,ha='center',bold=True)
colors={c:(np.array(matplotlib.colors.to_rgb(v))*255).round().astype(np.uint8) for c,v in COLORS.items()}
records=[];(R/'local_overlays').mkdir(exist_ok=True)
for i,t in enumerate(['T1','T2','T3','T4']):
 yy=72+i*(PH+1.4);txt(5,yy+PH/2,t,10.5,ha='center',bold=True)
 rgb=np.array(Image.open(R/f'local_crops/{t}_RGB.png'));images=[rgb]
 for group in ['reference','V66','V90']:
  labels=np.array(Image.open(R/f'local_crops/{t}_{group}_classes.png'));im=rgb.copy()
  for c,v in colors.items():im[labels==c]=v
  assert np.array_equal(im[labels==0],rgb[labels==0]);images.append(im)
  rel=f'local_overlays/{t}_{group}_RGB_overlay.png';Image.fromarray(im).save(R/rel)
  records.append({'period':t,'group':group,'file':rel,'array_sha256':hashlib.sha256(im.tobytes()).hexdigest()})
 for j,im in enumerate(images):
  aa=fig.add_axes([(LEFT+j*(CW+GAP))/W,1-(yy+PH)/H,CW/W,PH/H]);aa.imshow(im,interpolation='nearest');aa.axis('off')
  if i==0 and j==0:
   line,=aa.plot([17,117],[245,245],color='white',lw=1.8,solid_capstyle='butt');line.set_path_effects([patheffects.Stroke(linewidth=2.6,foreground='black'),patheffects.Normal()])
   aa.text(67,229,'100 px',ha='center',va='bottom',fontsize=9,color='black',bbox={'fc':'white','ec':'none','pad':.5})
for obj in fig.findobj(match=Text):obj.set_fontfamily('Times New Roman');obj.set_color('black')
stem='V66_V90_three_Dice_lines_new_local_SCI'
for ext in ['png','pdf']:fig.savefig(R/(stem+'.'+ext),dpi=600,facecolor='white')
fig.savefig(R/(stem+'.tiff'),dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
with Image.open(R/(stem+'.png')) as im:im.convert('RGB').save(R/(stem+'.jpg'),'JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
manifest={'stem':stem,'figure_mm':[W,H],'dpi':600,'plots':plot_records,'colors':{str(k):v for k,v in COLORS.items()},'local_overlays':records,'ROI_xyxy':d['ROI_xyxy'],'same_ROI_four_periods':True,'image_panels':16,'shared_RGB_columns':1,'shared_human_reference_columns':1,'full_field_panels':False,'legend':'Two workflow styles and three class colors only','metric_scope':'Full-field typed reference-root pixels at each date, T2–T4, reference B; n.a. when reference class absent','new_training_inference_registration':False}
(R/'figure_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with fitz.open(R/(stem+'.pdf')) as doc:doc[0].get_pixmap(matrix=fitz.Matrix(1.7,1.7),alpha=False).save(R/'preview.png')
print('Exported compact 220 × 186 mm figure: three real per-date Dice comparisons + 16 local panels.')
