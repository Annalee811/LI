"""Lossless RGB overlays, categorical masks, single-owner maps and explicit uncertainty."""
from pathlib import Path
import csv,json,hashlib,pickle
import numpy as np
from scipy import ndimage as ndi
from PIL import Image
PALETTE=np.array([[255,255,255],[53,111,176],[231,168,53],[174,64,130],[245,245,245]],np.uint8)
def readcsv(p):
 return list(csv.DictReader(p.open(encoding='utf-8-sig'))) if p.exists() else []
def csvout(p,rows):
 if not rows:return
 with p.open('w',encoding='utf-8-sig',newline='')as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def export(work,delivery):
 work=Path(work);p=json.loads((work/'adapter_provenance.json').read_text());dest=Path(delivery)/p['position'];dest.mkdir(parents=True,exist_ok=True);snap=pickle.load(open(work/'axis/root_axis_snapshots.pkl','rb'));routes=readcsv(work/'axis/Junction_axis_ownership.csv');low=readcsv(work/'junction/Low_confidence_state_decisions.csv');audits=[];axisrows=readcsv(work/'junction/Every_axis_state_audit.csv');look={(r['period'],int(r['axis'])):r for r in axisrows};tracks={};nexttrack=1
 for ti,t in enumerate(p['periods']):
  rgb=np.array(Image.open(work/f'base/data/upper/{t}_RGB.png'));cl=np.array(Image.open(work/f'junction/full/{t}_classes.png'));owner=np.load(work/f'junction/ownership/{t}_axis_owner.npz')['axis'];mask=cl>0;assert np.array_equal(mask,owner>=0);uncertain=np.zeros(mask.shape,bool);uncertain_axes=[];assigned=set()
  # Conservative cross-period identity links; a second child cannot silently inherit the same older axis.
  for r in sorted(snap[t]['states'],key=lambda r:-r['prior_support']):
   ai=r['axis'];prior=(r['prior_period'],r['prior_axis']);key=(t,ai)
   if r['state']=='established' and prior in tracks and prior not in assigned:tracks[key]=tracks[prior];assigned.add(prior)
   else:
    tracks[key]=nexttrack;nexttrack+=1
    if r['state']=='established' and prior in assigned:uncertain_axes.append(ai)
   if r['state']=='uncertain':uncertain_axes.append(ai)
  for r in low:
   if r['period']==t:uncertain_axes.append(int(r['axis']))
  if uncertain_axes:uncertain|=np.isin(owner,np.array(uncertain_axes))
  # Junction cores keep an explicit review flag: the degree cue is an adapter approximation.
  tp=pickle.load(open(work/'joint/data/topology.pkl','rb'))['topos'][t]
  for h in tp['hubs']:
   if h.get('disabled'):continue
   pp=h['points'];uncertain[pp[:,1],pp[:,0]]=1
  uncertain=ndi.binary_dilation(uncertain,iterations=2)&mask
  if p['position']=='Q1-1-Z2' and ti>0:uncertain|=mask # Known coarse/unverified cross-date localization.
  labels=PALETTE[cl];overlay=rgb.copy();overlay[mask]=(.12*rgb[mask]+.88*labels[mask]).round().astype(np.uint8)
  Image.fromarray(overlay).save(dest/(t+'_RGB_temporal_candidate.png'));Image.fromarray(cl).save(dest/(t+'_classes.png'));with_unknown=cl.copy();with_unknown[uncertain]=255;Image.fromarray(with_unknown).save(dest/(t+'_classes_with_uncertainty.png'));Image.fromarray(np.where(mask[:,:,None],labels,255).astype(np.uint8)).save(dest/(t+'_roots_on_white.png'));Image.fromarray(uncertain.astype(np.uint8)*255).save(dest/(t+'_uncertainty.png'));review=overlay.copy();review[uncertain]=[190,190,190];Image.fromarray(review).save(dest/(t+'_RGB_uncertainty_review.png'))
  track=np.zeros(mask.shape,np.int32)
  present=np.unique(owner[mask]);lut=np.zeros(int(present.max())+1,np.int32)
  for ai in present:lut[ai]=tracks[(t,int(ai))]
  track[mask]=lut[owner[mask]]
  np.savez_compressed(dest/(t+'_ownership.npz'),axis=owner,track_id=track,uncertain=uncertain)
  audits.append(dict(position_id=p['position'],period=t,width=cl.shape[1],height=cl.shape[0],persistent_pixels=int((cl==1).sum()),new_pixels=int((cl==2).sum()),extension_pixels=int((cl==3).sum()),baseline_pixels=int((cl==4).sum()),uncertain_root_pixels=int(uncertain.sum()),inferred_axes=int(len(np.unique(owner[mask]))),actual_frozen_V90_forward=True,adapter='experimental_transfer_v1',manual_GT_available=p['position']=='0353-2-B3',external_Dice=None,external_IoU=None,needs_manual_validation=True,RGB_SHA256=p['RGB_hashes'][t],prediction_SHA256=hashlib.sha256((dest/(t+'_classes.png')).read_bytes()).hexdigest()))
  print('EXPORT',p['position'],t,'root',mask.sum(),'uncertain',uncertain.sum(),flush=True)
 for name in ['adapter_provenance.json','candidate_complete.json']:(dest/name).write_bytes((work/name).read_bytes())
 csvout(dest/'Prediction_and_validation_status.csv',audits);csvout(dest/'Temporal_axis_states.csv',readcsv(work/'axis/Axis_temporal_states.csv'))
 for q in [work/'axis/Unresolved_root_intervals.csv',work/'junction/Low_confidence_state_decisions.csv',work/'junction/Every_junction_event_audit.csv']:
  if q.exists():(dest/q.name).write_bytes(q.read_bytes())
 (dest/'README.txt').write_text('V90 frozen-weight transfer CANDIDATE; not the exact archived reviewed V90 pipeline.\nRead adapter_provenance.json before use. No independent accuracy is claimed.\nClasses:0 background,1 persistent,2 newly observed,3 extending,4 first-observation baseline.\nRGB_temporal_candidate: full native grid over original registered RGB.\nRGB_uncertainty_review: uncertain foreground is grey. Other version has all provisional class colors.\nOwnership is exclusive at every pixel. Track IDs are inferred links, not validated biological identities.\nFirst observation is baseline; missing dates are absent.\n')
 return audits
if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--work',required=True);ap.add_argument('--output',required=True);a=ap.parse_args();export(a.work,a.output)
