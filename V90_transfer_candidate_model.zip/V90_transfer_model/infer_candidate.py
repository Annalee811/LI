"""Apply the frozen V90 ConvLSTM/GAT, learned continuation and state heads to new graphs.
This transfer candidate has an explicit adapter provenance and is not advertised as exact V90 reproduction.
"""
import argparse,os,sys,json,pickle,subprocess,shutil
from pathlib import Path
import numpy as np,torch
from PIL import Image
from scipy.spatial import cKDTree
H=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('--work',type=Path,required=True);a=p.parse_args();w=a.work.resolve();prov=json.loads((w/'adapter_provenance.json').read_text());periods=prov['periods'];os.environ['ROOT_REPRO_WORK']=str(w);os.environ['ROOT_OBSERVED_PERIODS']=','.join(periods);os.environ['ROOT_POSITION']=prov['position'];sys.path.insert(0,str(H/'portable_core'));from model import LocalCorrector
 from train import PairHead
 from topology import matchings
 torch.set_num_threads(2);torch.set_num_interop_threads(1);g=dict(np.load(w/'local/data/unet/graph.npz'));e=dict(np.load(w/'local/data/unet/extra.npz'));fr=np.load(w/'local/data/unet/frames.npz')['frames'].astype(np.float32);ck=torch.load(w/'joint/joint_best.pt',weights_only=False,map_location='cpu');net=LocalCorrector();net.load_state_dict(ck['backbone']);net.native_width=prov['native_width'];net.native_height=prov['native_height'];net.eval()
 with torch.inference_mode():h,links,z=net(torch.from_numpy(fr),torch.from_numpy(g['x']),torch.from_numpy(g['pairs']),torch.from_numpy(g['attrs']),torch.from_numpy(g['phase']),torch.from_numpy(g['centers']),torch.from_numpy(e['geometry']))
 hn=h.numpy();zn=z.numpy();np.savez_compressed(w/'joint/joint_inference.npz',h=hn,embedding=zn,connection=links.sigmoid().numpy());print('FROZEN_V90_FORWARD',prov['position'],len(hn),flush=True)
 tp=pickle.load(open(w/'joint/data/topology.pkl','rb'));owners=dict(np.load(w/'local/data/unet/ownership.npz'));raw=np.load(w/'raw_graph.npz')['features'];rgb={t:np.array(Image.open(w/f'base/data/upper/{t}_RGB.png')).astype(np.float32)/255 for t in periods};trees={};directions={}
 for t in periods:
  pts=[];vv=[]
  for seg in tp['topos'][t]['segments']:
   q=seg['points'];l=q[np.maximum(np.arange(len(q))-5,0)];r=q[np.minimum(np.arange(len(q))+5,len(q)-1)];v=r-l;v=v/np.linalg.norm(v,axis=1).clip(1e-8)[:,None];pts.extend(q);vv.extend(v)
  trees[t]=cKDTree(np.array(pts));directions[t]=np.array(vv)
 groups=[];armsby={};features=[]
 for ti,t in enumerate(periods):
  armsby[t]=[]
  for j,hub in enumerate(tp['topos'][t]['hubs']):
   arms=hub['arms'];opts=matchings(len(arms))
   if not opts or any(len(v['body_points'])<4 for v in arms):continue
   aa=[]
   for arm in arms:
    q=arm['body_points'];node=np.unique(owners[t][q[:,1],q[:,0]]);node=node[node>=0]
    emb=zn[node].mean(0);emb/=max(np.linalg.norm(emb),1e-8);support=np.zeros(4)
    for tt in periods:
     dd,nn=trees[tt].query(q,k=4);align=np.abs((directions[tt][nn]*arm['direction']).sum(-1));support[int(tt[1:])-1]=float(((dd<=3.5)&(align>=.9)).any(1).mean())
    aa.append(dict(**arm,nodes=node,embedding=emb,width=float(raw[node,6].mean()),color=rgb[t][q[:,1],q[:,0]].mean(0),support=support))
   indices={}
   for i in range(len(aa)):
    for k in range(i+1,len(aa)):
     u,v=aa[i],aa[k];f=np.r_[np.abs(u['embedding']-v['embedding']),u['embedding']*v['embedding'],-arms[i]['direction']@arms[k]['direction'],np.linalg.norm(arms[i]['point']-arms[k]['point'])/16,abs(u['width']-v['width']),np.abs(u['color']-v['color']),u['support']+v['support'],np.abs(u['support']-v['support']),np.eye(4)[int(t[1:])-1]].astype(np.float32);indices[str(i)+','+str(k)]=len(features);features.append(f)
   groups.append(dict(period=t,hub=j,pair_indices=indices,options=opts));armsby[t].append((j,aa))
 pairnorm=np.load(H/'pair_normalization.npz' if (H/'pair_normalization.npz').exists() else H.parent/'model_source/assets/joint/data/pairs.npz');ff=np.array(features,np.float32).reshape(-1,len(pairnorm['mean']));xx=(ff-pairnorm['mean'])/pairnorm['std'];pair=PairHead(len(pairnorm['mean']));pair.load_state_dict(ck['pair']);pair.eval()
 with torch.inference_mode():score=pair(torch.from_numpy(xx)).numpy()
 np.save(w/'joint/joint_pair_logits.npy',score);np.savez_compressed(w/'joint/data/pairs.npz',raw=ff,mean=pairnorm['mean'],std=pairnorm['std'],x=xx);tp.update(groups=groups,arms=armsby);pickle.dump(tp,open(w/'joint/data/topology.pkl','wb'));(w/'joint/joint_training_results.json').write_text(json.dumps(dict(geometry_weight=2.,assignment_confidence=.9,calibration_source='Original B3 validation; frozen at deployment')));np.save(w/'local/data/spatial.npy',np.zeros((prov['native_height'],prov['native_width']),np.int8))
 (w/'branch/full').mkdir(parents=True,exist_ok=True)
 for t in periods:shutil.copy2(w/f'local/full/{t}_classes.png',w/f'branch/full/{t}_classes.png')
 for script in ['axis_consistency.py','junction_consistency.py']:
  subprocess.run([sys.executable,str(H/'portable_core'/script)],check=True)
 (w/'candidate_complete.json').write_text(json.dumps(dict(version=prov['version'],periods=periods,actual_frozen_weights_forward=True,learned_pair_head_used=True,learned_root_state_used=True,no_manual_review_support_transferred=True,exact_archived_preprocessor=False),indent=2));print('CANDIDATE_COMPLETE',prov['position'],flush=True)
if __name__=='__main__':main()
