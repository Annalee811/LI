"""Explicit frozen-weight V90 transfer adapter. Candidate, not an exact historical raw-to-graph recreation.
Known departures: skeleton partition is reconstructed; geometric degree cue is proxied;
the unreleased dense local-correction prepass is omitted. No annotations are inference inputs.
"""
import argparse,csv,json,os,sys,hashlib,shutil
from pathlib import Path
import numpy as np
from scipy import ndimage as ndi
from scipy.spatial import cKDTree
from PIL import Image
from skimage.morphology import skeletonize
from raw_nodes import partition
H=Path(__file__).resolve().parent;A=H.parent/'model_source/assets'
def normfit(raw,x):
 means=[];std=[]
 for u,y in zip(raw.T,x.T):
  a,b=np.linalg.lstsq(np.c_[u,np.ones(len(u))],y,rcond=None)[0];means.append(-b/a);std.append(1/a)
 return np.array(means,np.float32),np.array(std,np.float32)
def normalization():
 p=H/'normalization.npz'
 if p.exists():return dict(np.load(p))
 g=np.load(A/'local/data/unet/graph.npz');r=np.load(A/'raw_graph.npz');e=np.load(A/'local/data/unet/extra.npz');extra=np.load(H/'recovered_extra_raw.npy');m,s=normfit(r['features'],g['x'][:,:21]);m2,s2=normfit(extra,g['x'][:,21:]);gm,gs=normfit(e['raw_geometry'],e['geometry']);np.savez(p,mean=np.r_[m,m2],std=np.r_[s,s2],geometry_mean=gm,geometry_std=gs);return dict(np.load(p))
def cues(mask):
 sk=skeletonize(mask);degree=ndi.convolve(sk.astype(np.uint8),np.ones((3,3),np.uint8),mode='constant')-sk
 end=sk&(degree==1);jun=sk&(degree>=3)
 d,near=ndi.distance_transform_edt(~jun,return_indices=True) if jun.any() else (np.full(mask.shape,1e3),np.zeros((2,*mask.shape),int))
 ec=np.exp(-ndi.distance_transform_edt(~end)**2/128).astype(np.float32) if end.any() else np.zeros(mask.shape,np.float32)
 return sk,degree,ec,np.exp(-d*d/128).astype(np.float32),d,near

def build(position,inputs,out):
 rows=[r for r in csv.DictReader(open(os.environ.get('V90_INPUT_MANIFEST','/workspace/LI/dataset/current/active_images.csv'),encoding='utf-8-sig')) if r['position_id']==position];periods=[r['period']for r in rows];os.environ['ROOT_REPRO_WORK']=str(out);os.environ['ROOT_OBSERVED_PERIODS']=','.join(periods);sys.path.insert(0,str(H/'portable_core'));from topology import build as topology
 nrm=normalization();raws=[];stats=[];geo=[];centers=[];phases=[];natives=[];jflags=[];owners={};frames=[];topos={};offset=0;ngoffset=0;prev=None
 for ti,r in enumerate(rows):
  t=r['period'];f=inputs/position;rgbpath=Path(os.environ.get('V90_RGB_ROOT','/workspace/work/all_series_RGB_PDF_20261105/sources'))/r['canonical_view_relative_path'];assert hashlib.sha256(rgbpath.read_bytes()).hexdigest()==r['registered_RGB_SHA256'];rgb=np.array(Image.open(rgbpath).convert('RGB')).astype(np.float32)/255;p=np.load(f/(t+'_binary_probability.npy'));cl=np.array(Image.open(f/(t+'_prior_classes.png')));mask=cl>0;pr=np.load(f/(t+'_prior_probability.npz'))['probability'].astype(np.float32);h,w=mask.shape
  pts,ng,jun,ow,sk=partition(mask);N=len(pts);c=np.array([v.mean(0)for v in pts]);owner=ow.copy();owner[mask]+=offset;owners[t]=owner;topos[t]=topology(mask);cs,degree,ec,jc,jd,jnear=cues(mask);width=ndi.distance_transform_edt(mask).astype(np.float32)
  pdist=np.zeros(mask.shape,np.float32) if prev is None else ndi.distance_transform_edt(~prev[1]).astype(np.float32);delta=np.zeros_like(rgb) if prev is None else rgb-prev[0];pfexp=pr.transpose(1,2,0)
  # All 8 frame channels reproduced exactly on B3 (RGB, p, foreground, EDT/8, endpoint/junction cues).
  ff=np.dstack([rgb,p,mask,width/8,ec,jc]);frames.append(np.stack([np.array(Image.fromarray(ff[:,:,k].astype(np.float32)).resize((int(np.ceil(w/8)),int(np.ceil(h/8))),Image.Resampling.BILINEAR))for k in range(8)]).astype(np.float16))
  valid=ow>=0;lab=ow[valid];count=np.bincount(lab,minlength=N).clip(1);pixmeans=lambda v:np.bincount(lab,weights=v[valid],minlength=N)/count
  meanrgb=np.stack([pixmeans(rgb[:,:,j])for j in range(3)],1);stdrgb=np.sqrt(np.maximum(np.stack([pixmeans(rgb[:,:,j]**2)for j in range(3)],1)-meanrgb**2,0));diff=np.stack([pixmeans(delta[:,:,j])for j in range(3)],1);pm=np.stack([pixmeans(pfexp[:,:,j])for j in range(3)],1);ps=np.sqrt(np.maximum(np.stack([pixmeans(pfexp[:,:,j]**2)for j in range(3)],1)-pm**2,0));ent=-(pm*np.log(pm.clip(1e-6))).sum(1)
  chord=np.array([np.linalg.norm(v[-1]-v[0])for v in pts]);arc=np.array([np.linalg.norm(np.diff(v,axis=0),axis=1).sum()for v in pts]);tangent=np.array([(v[-1]-v[0])/max(np.linalg.norm(v[-1]-v[0]),1e-8)for v in pts]);one=np.tile(np.eye(4)[int(t[1:])-1],(N,1));raw=np.c_[c[:,0]/w,c[:,1]/h,chord/12,arc/16,tangent,pixmeans(width)/10,pixmeans(pdist)/32,meanrgb,stdrgb,diff,one].astype(np.float32)
  cc=c.round().astype(int);yy,xx=cc[:,1],cc[:,0];near_degree=degree[tuple(jnear)][yy,xx].astype(np.float32)/4;near_degree*=jd[yy,xx]<=15
  # Degree is the one unrecovered cue; proxy explicitly tracked in provenance and uncertainty.
  ge=np.c_[near_degree,np.exp(-jd[yy,xx]**2/72)*(jd[yy,xx]<=15),ec[yy,xx],np.minimum(pdist[yy,xx]/32,1)].astype(np.float32)
  raws.append(raw);stats.append(np.c_[pm,ps,ent].astype(np.float32));geo.append(ge);centers.append(c);phases.extend([ti]*N);natives.extend(ng+ngoffset);jflags.extend(jun);offset+=N;ngoffset+=int(ng.max())+1;prev=(rgb,mask,ec)
  (out/'base/data/upper').mkdir(parents=True,exist_ok=True);shutil.copy2(rgbpath,out/'base/data/upper'/f'{t}_RGB.png')
  for sub in ['base/unet/full','local/full']:(out/sub).mkdir(parents=True,exist_ok=True);Image.fromarray(cl).save(out/sub/(t+'_classes.png'))
  print('GRAPH_FRAME',position,t,N,flush=True)
 raw=np.concatenate(raws);features=np.c_[raw,np.concatenate(stats)].astype(np.float32);ge=np.concatenate(geo);c=np.concatenate(centers);phase=np.array(phases,np.int64);native=np.array(natives);pairs=set()
 for ti in range(len(periods)):
  ids=np.flatnonzero(phase==ti);tree=cKDTree(c[ids]);dd,ix=tree.query(c[ids],k=min(9,len(ids)),distance_upper_bound=32)
  for ii,near in enumerate(ix):
   for jj in near:
    if jj>=len(ids) or jj==ii:continue
    a,b=sorted([int(ids[ii]),int(ids[jj])]);pairs.add((a,b))
  for tj in range(ti):
   old=np.flatnonzero(phase==tj);dd,ix=cKDTree(c[old]).query(c[ids],k=min(4,len(old)),distance_upper_bound=32)
   if ix.ndim==1:ix=ix[:,None]
   for ii,near in enumerate(ix):
    for jj in near:
     if jj<len(old):pairs.add((int(old[jj]),int(ids[ii])))
 pairs=np.array(sorted(pairs),np.int64);a,b=pairs.T;delta=c[b]-c[a];dist=np.linalg.norm(delta,axis=1);actual=np.array([int(periods[v][1:])for v in phase]);attrs=np.c_[dist/32,delta/32,np.abs((raw[a,4:6]*raw[b,4:6]).sum(1)),np.abs(actual[b]-actual[a]),(native[a]==native[b])&(phase[a]==phase[b]),np.abs(raw[a,6]-raw[b,6]),np.minimum(dist,100)/100].astype(np.float32)
 dest=out/'local/data/unet';dest.mkdir(parents=True,exist_ok=True);np.savez_compressed(dest/'graph.npz',x=((features-nrm['mean'])/nrm['std']).astype(np.float32),pairs=pairs,attrs=attrs,phase=phase,centers=c.astype(np.float32));np.savez_compressed(dest/'extra.npz',geometry=((ge-nrm['geometry_mean'])/nrm['geometry_std']).astype(np.float32));np.savez_compressed(dest/'frames.npz',frames=np.stack(frames));np.savez_compressed(dest/'ownership.npz',**owners);np.savez_compressed(out/'raw_graph.npz',features=raw)
 import pickle
 (out/'joint/data').mkdir(parents=True,exist_ok=True)
 with open(out/'joint/data/topology.pkl','wb')as f:pickle.dump(dict(topos=topos,groups=[],arms={}),f)
 shutil.copy2(H/'weights/V90_joint_best.pt' if (H/'weights/V90_joint_best.pt').exists() else A/'joint/joint_best.pt',out/'joint/joint_best.pt')
 (out/'reference').mkdir(exist_ok=True);(out/'reference/reference_provenance.json').write_text(json.dumps(dict(no_reference_labels_used=True,scope='Deployment input provenance only',position=position)))
 shutil.copytree('/workspace/LI/analysis-scripts/dataset_identity.py',out/'analysis-scripts/dataset_identity.py') if False else None
 (out/'analysis-scripts').mkdir(exist_ok=True);policy=H/'identity_policy';shutil.copy2(policy/'dataset_identity.py' if policy.exists() else '/workspace/LI/analysis-scripts/dataset_identity.py',out/'analysis-scripts/dataset_identity.py');shutil.copytree(policy/'current' if policy.exists() else '/workspace/LI/dataset/current',out/'dataset/current',dirs_exist_ok=True)
 provenance=dict(version='V90-transfer-candidate-v1',position=position,periods=periods,graph_nodes=len(c),graph_edges=len(pairs),native_width=w,native_height=h,actual_frozen_V90_weights=True,no_manual_labels=True,adapter_exact_historical_parity=False,known_departures=['Reconstructed skeleton partition and neighbor selection','Geometric degree cue uses a nearest-junction pixel-degree proxy','Initial priors from frozen V66 head; archived local correction prepass unavailable','Missing-date sequences use observed frames only; support features record no evidence for absent dates'],accuracy_status='Requires independent manual validation',RGB_hashes={r['period']:r['registered_RGB_SHA256']for r in rows})
 (out/'adapter_provenance.json').write_text(json.dumps(provenance,indent=2));return provenance
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--position',required=True);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);build(a.position,a.inputs,a.output)
