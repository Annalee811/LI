"""Batch the portable candidate over independent registered positions; checkpoint each position."""
from pathlib import Path
import argparse,csv,json,subprocess,sys
H=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--rgb-root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.rgb_root=a.rgb_root.resolve();a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=True);positions=set()
 for t in ['T1','T2','T3','T4']:
  for suffix in ['.png','_RGB.png','.tif','.tiff','.jpg']:
   for p in a.rgb_root.rglob(t+suffix):
    if not p.is_relative_to(a.output):positions.add(p.parent)
 if not positions:raise ValueError('No T1..T4 RGB observation directories were found.')
 records=[]
 for folder in sorted(positions):
  pos=folder.name;cmd=[sys.executable,str(H/'predict_candidate.py'),'--rgb-dir',str(folder),'--position',pos,'--output',str(a.output/pos)]
  log=a.output/(pos+'_prediction.log')
  with log.open('a')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
  records.append(dict(input_directory=str(folder),position=pos,status='candidate_exported'if r.returncode==0 else'failed_see_log',log=str(log)))
  with(a.output/'Batch_prediction_status.csv').open('w',encoding='utf-8-sig',newline='')as f:w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
  print(pos,records[-1]['status'],flush=True)
 if any(r['status']!='candidate_exported'for r in records):raise SystemExit(1)
if __name__=='__main__':main()
