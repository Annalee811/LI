"""Portable RGB-series entry point. Experimental V90 transfer; matched field and registered RGBs required."""
from pathlib import Path
import argparse,csv,hashlib,json,os,subprocess,sys
from PIL import Image
H=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--rgb-dir',type=Path,required=True,help='One registered position: T1.png, T2.png, T3.png, T4.png; missing dates remain absent');ap.add_argument('--position',help='Position ID, defaults to directory name');ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();pos=a.position or a.rgb_dir.name
 if pos in ['', '.', '..'] or '/' in pos or chr(92) in pos:raise ValueError('Position must be a single directory name, without path separators.')
 config=json.loads((H/'deployment_config.json').read_text())
 for rel,sha in config['weights_SHA256'].items():
  if hashlib.sha256((H/rel).read_bytes()).hexdigest()!=sha:raise ValueError('Checkpoint hash mismatch: '+rel)
 sys.path.insert(0,str(H/'identity_policy'));import dataset_identity
 # Policy helper is packaged next to its original relative dataset/current hierarchy.
 dataset_identity.POLICY_PATH=H/'identity_policy/current/identity_policy.json';pos=dataset_identity.require_active_position(pos);a.rgb_dir=a.rgb_dir.resolve();a.output=a.output.resolve()
 if a.output.exists() and any(a.output.iterdir()) and not (a.output/'input_manifest.csv').exists():raise ValueError('Choose a new empty output directory, or a previous run containing input_manifest.csv.')
 a.output.mkdir(parents=True,exist_ok=True);rows=[];shapes=[]
 for t in ['T1','T2','T3','T4']:
  matches=[a.rgb_dir/f'{t}{suffix}'for suffix in ['.png','_RGB.png','.tif','.tiff','.jpg'] if (a.rgb_dir/f'{t}{suffix}').exists()]
  if len(matches)>1:raise ValueError(f'Ambiguous source files for {t}: {matches}')
  if not matches:continue
  src=matches[0];im=Image.open(src);shapes.append(im.size);rows.append(dict(position_id=pos,period=t,canonical_view_relative_path=src.name,registered_RGB_SHA256=hashlib.sha256(src.read_bytes()).hexdigest(),review_required=True))
 if len(rows)<2 or len(set(shapes))!=1 or min(shapes[0])<256:raise ValueError('Need 2–4 observations of the same registered field/grid, each side >=256 pixels. Missing dates are not synthesized.')
 manifest=a.output/'input_manifest.csv'
 if manifest.exists():
  old=list(csv.DictReader(manifest.open(encoding='utf-8-sig')))
  if [{k:str(v)for k,v in r.items()}for r in rows]!=old:raise ValueError('Existing output belongs to different inputs. Choose a new output directory.')
 else:
  with manifest.open('w',encoding='utf-8-sig',newline='')as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 env=os.environ.copy();env.update(V90_INPUT_MANIFEST=str(manifest),V90_RGB_ROOT=str(a.rgb_dir),V90_USE_VERIFIED_B3_CACHE='0')
 commands=[['upstream_predict.py','--position',pos,'--output',str(a.output/'priors')],['build_graph_inputs.py','--position',pos,'--inputs',str(a.output/'priors'),'--output',str(a.output/'work'/pos)],['infer_candidate.py','--work',str(a.output/'work'/pos)],['export_candidate.py','--work',str(a.output/'work'/pos),'--output',str(a.output/'predictions')]]
 print('V90 frozen-weight transfer CANDIDATE. Adapter departures and uncertainty are exported; no external accuracy claim.',flush=True)
 for cmd in commands:subprocess.run([sys.executable,str(H/cmd[0]),*cmd[1:]],env=env,check=True)
 print('PREDICTIONS',a.output/'predictions'/pos,flush=True)
if __name__=='__main__':main()
