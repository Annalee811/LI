"""Image-derived skeleton nodes; no labels or B3 coordinates used."""
import numpy as np
from scipy import ndimage as ndi
from skimage.morphology import skeletonize

def partition(mask):
 sk=skeletonize(mask);yx=np.argwhere(sk);lookup={tuple(p):i for i,p in enumerate(yx)};adj=[[]for _ in yx]
 for i,(y,x) in enumerate(yx):
  for dy,dx in [(0,1),(0,-1),(1,0),(-1,0),(1,1),(1,-1),(-1,1),(-1,-1)]:
   j=lookup.get((y+dy,x+dx))
   if j is None:continue
   if dy and dx and ((y+dy,x) in lookup or (y,x+dx) in lookup):continue
   adj[i].append(j)
 junction=np.array([len(v)>=3 for v in adj]);seen=set();groups=[];native=[];isjun=[];chain=0
 for start in [i for i in range(len(yx)) if not junction[i] and sum(not junction[j]for j in adj[i])<=1]+list(range(len(yx))):
  if junction[start] or start in seen:continue
  path=[];prev=-1;cur=start
  while cur not in seen:
   seen.add(cur);path.append(cur);nxt=[j for j in adj[cur] if not junction[j] and j!=prev and j not in seen]
   if not nxt:break
   prev,cur=cur,nxt[0]
  for off in range(0,len(path),12):groups.append(yx[path[off:off+12]][:,::-1]);native.append(chain);isjun.append(False)
  chain+=1
 for start in np.flatnonzero(junction):
  if int(start) in seen:continue
  todo=[int(start)];points=[];seen.add(int(start))
  while todo:
   i=todo.pop();points.append(i)
   for j in adj[i]:
    if junction[j] and j not in seen:seen.add(j);todo.append(j)
  groups.append(yx[points][:,::-1]);native.append(chain);isjun.append(True);chain+=1
 at=np.full(mask.shape,-1,np.int32)
 for i,p in enumerate(groups):at[p[:,1],p[:,0]]=i
 _,near=ndi.distance_transform_edt(at<0,return_indices=True);owner=at[tuple(near)];owner[~mask]=-1
 return groups,np.array(native),np.array(isjun),owner,sk
