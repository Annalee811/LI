"""Three material panels, each containing the five requested root-trait means."""
from pathlib import Path
import argparse,csv,hashlib,json,sys
import numpy as np
from PIL import Image
from openpyxl import load_workbook,Workbook
from openpyxl.styles import Font,Alignment
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.text import Text

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'provenance/analysis-scripts'))
from dataset_identity import require_active_position
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);args=p.parse_args()
for name in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(args.fonts_dir/name))
plt.rcParams.update({'font.family':'Times New Roman','font.size':8.5,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'svg.fonttype':'none','axes.linewidth':.65,'axes.unicode_minus':False})
source=ROOT/'sources/All_microtube_root_traits.xlsx'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='ea74bf1853766e51fa3b30546d6893032e57e50ea991514c2735182a6fdb0e52'
w=load_workbook(source,data_only=True)
def sheet(name):
 it=w[name].values;h=next(it);return h,[dict(zip(h,row)) for row in it]
headers,raw=sheet('All_72_cells');summary_headers,summary=sheet('Full_precision')
for r in raw:require_active_position(r['Observation_unit'])
assert len(raw)==72 and len(summary)==12
specs=[
 ('Skeleton length','Mean_root_length_1000px','Root_length_px','#222222','o','-', 'left'),
 ('Persistent','Persistent_share_current_pct_mean','Persistent_share_current_pct','#D7838C','s','-', 'right'),
 ('New','New_share_current_pct_mean','New_share_current_pct','#75BED8','^','-', 'right'),
 ('Extension','Extension_share_current_pct_mean','Extension_share_current_pct','#E6AA75','D','-', 'right'),
 ('E / Lprev','Extension_relative_previous_pct_mean','Extension_relative_previous_pct','#785EA8','v','--', 'right')]
def valid(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and np.isfinite(v)
audit=[]
for r in summary:
 subset=[q for q in raw if q['Material']==r['Material'] and q['Period']==r['Period']]
 assert len(subset)==6
 assert sum(valid(q['Root_length_px']) for q in subset)==r['n_length']
 assert sum(valid(q['Extension_relative_previous_pct']) for q in subset)==r['n_interval']
 for label,field,individual_field,*_ in specs:
  vals=[q[individual_field]/1000 if label=='Skeleton length' else q[individual_field] for q in subset if valid(q[individual_field])]
  if vals:assert abs(float(np.mean(vals))-r[field])<1e-10
  else:assert not valid(r[field])
  audit.append({'Material':r['Material'],'Period':r['Period'],'Metric':label,'Mean':float(r[field]) if valid(r[field]) else None,'Axis':'left' if label=='Skeleton length' else 'right','Unit':'10³ px' if label=='Skeleton length' else '%','nL':r['n_length'],'nI':r['n_interval'],'source_field':field})
assert sum(q['Mean'] is not None for q in audit)==48

W,H=190.5,101
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white');handles=[];line_meta=[]
for i,(material,left) in enumerate(zip(['0353','A017','Q1'],[14,75,136])):
 ax=fig.add_axes([left/W,1-62/H,41/W,48/H]);right=ax.twinx()
 ax.set(xlim=(.85,4.15),ylim=(0,65));right.set_ylim(0,100)
 ax.set_xticks([1,2,3,4],['T1','T2','T3','T4']);ax.set_yticks([0,20,40,60]);right.set_yticks([0,25,50,75,100])
 for which in [ax,right]:
  which.tick_params(axis='both',labelsize=8.5,length=2.3,width=.65,pad=2,color='black',labelcolor='black')
  which.spines['top'].set_visible(False)
 for side in ['left','bottom']:ax.spines[side].set_color('black');ax.spines[side].set_linewidth(.65)
 ax.spines['right'].set_visible(False);right.spines['left'].set_visible(False);right.spines['bottom'].set_visible(False);right.spines['right'].set_color('black');right.spines['right'].set_linewidth(.65)
 rows=sorted([r for r in summary if r['Material']==material],key=lambda r:r['Period'])
 for j,(label,field,individual_field,color,marker,style,axis) in enumerate(specs):
  vals=np.array([r[field] if valid(r[field]) else np.nan for r in rows],float);target=ax if axis=='left' else right
  line,=target.plot([1,2,3,4],vals,color=color,marker=marker,linestyle=style,lw=1.45 if j==0 else 1.3,markersize=4.5,markeredgewidth=.85,markerfacecolor='white' if j in [0,4] else color,markeredgecolor=color,label=label,zorder=4 if j==0 else 3)
  if style=='--':line.set_dashes([3,2])
  if i==0:handles.append(line)
  line_meta.append({'Material':material,'Metric':label,'Axis':axis,'x':[1,2,3,4],'y':[float(v) if np.isfinite(v) else None for v in vals]})
 ax.set_xlabel('Period',fontsize=9,labelpad=4)
 fig.text((left-8.8)/W,1-8/H,'abc'[i],fontsize=11,fontweight='bold',va='center',ha='left')
 fig.text((left+20.5)/W,1-8/H,material,fontsize=11,fontweight='bold',va='center',ha='center')
 counts=', '.join(f'{r["n_length"]}/'+(str(r['n_interval']) if r['Period']!='T1' else '—') for r in rows)
 fig.text((left+20.5)/W,1-77/H,'nL/nI: '+counts,fontsize=8,ha='center',va='center')
fig.text(3.1/W,1-38/H,'Skeleton length (10³ px)',rotation=90,ha='center',va='center',fontsize=9)
fig.text(188/W,1-38/H,'Temporal traits (%)',rotation=270,ha='center',va='center',fontsize=9)
fig.legend(handles=handles,labels=[s[0] for s in specs],ncol=5,loc='center',bbox_to_anchor=(.52,1-87/H),frameon=False,fontsize=8.5,handlelength=2.3,columnspacing=1.6,handletextpad=.55)
fig.text(.52,1-96/H,'Series means. Black: left axis; colors: right axis. nL/nI: length observations / adjacent pairs.',fontsize=8,ha='center',va='center')
for t in fig.findobj(match=Text):t.set_color('black');t.set_fontfamily('Times New Roman')
stem='Three_series_five_metric_line_charts'
for ext in ['png','pdf','svg']:fig.savefig(ROOT/f'{stem}.{ext}',dpi=600,facecolor='white')
fig.savefig(ROOT/f'{stem}.tiff',dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
Image.open(ROOT/f'{stem}.png').convert('RGB').save(ROOT/f'{stem}.jpg','JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
with (ROOT/'plotted_means_long.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(audit[0]));writer.writeheader();writer.writerows(audit)
(ROOT/'plotted_lines.json').write_text(json.dumps(line_meta,indent=2))
(ROOT/'source_summary_full_precision.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
x=Workbook();s=x.active;s.title='Plotted_means';outheaders=['Material','Period','nL','nI']+[s[0] for s in specs];s.append(outheaders)
for r in summary:s.append([r['Material'],r['Period'],r['n_length'],r['n_interval']]+[r[spec[1]] if valid(r[spec[1]]) else None for spec in specs])
for name,head,rs in [('Underlying_72_cells',headers,raw),('Source_summary',summary_headers,summary)]:
 s=x.create_sheet(name);s.append(head)
 for r in rs:s.append([r[h] for h in head])
for s in x:
 s.freeze_panes='C2';s.auto_filter.ref=s.dimensions
 for c in s[1]:c.font=Font(name='Times New Roman',size=11,bold=True,color='000000');c.alignment=Alignment(wrap_text=True)
 for col in s.columns:s.column_dimensions[col[0].column_letter].width=24
x.save(ROOT/'Three_series_five_metric_plot_data.xlsx')
(ROOT/'plot_metadata.json').write_text(json.dumps({'figure_mm':[W,H],'layout':'Exactly three horizontal material panels: 0353, A017, Q1; five metric trajectories in each panel.','aggregation':'Original Full_precision means from the linked workbook, independently checked against the 18 sequence-level records.','left_axis':'Skeleton length (10³ px), fixed 0–65 in all panels','right_axis':'Persistent, New, Extension and E/Lprev (%), fixed 0–100 in all panels','T1_temporal_classes':'Missing/undefined; no zero substituted.','root_length_support':'All available length observations at each material/period','temporal_support':'Only valid adjacent pairs at each material/period; not necessarily the same fields as length means.','counts_in_plot':'nL/nI values listed in T1–T4 order','uncertainty':'Means only; source SD available in the data workbook, no inferential bars or tests.','units':'Native pixel lengths and interval percentages; not calibrated mm or mm/day.','source_tubes':8,'sequence_IDs':18,'valid_length_observations':63,'valid_adjacent_pairs':40,'source_workbook_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_commit':'8b4fdb81b5938720e263d802426745c982c4479c','model_scope':'Source V35 binary / V66 temporal U-Net estimates; not V90.','input_records_changed':False,'training_or_registration_run':False},indent=2))
print('Created exactly three joined panels, five mean curves per panel, 48 measured mean points; left length/right percentage axes.')
