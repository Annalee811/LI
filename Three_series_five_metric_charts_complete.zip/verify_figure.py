from pathlib import Path
import csv,json,hashlib
import numpy as np
from openpyxl import load_workbook
from PIL import Image
import fitz

ROOT=Path(__file__).resolve().parent
source=ROOT/'sources/All_microtube_root_traits.xlsx'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='ea74bf1853766e51fa3b30546d6893032e57e50ea991514c2735182a6fdb0e52'
w=load_workbook(source,data_only=True);it=w['Full_precision'].values;h=next(it);source_rows=[dict(zip(h,row)) for row in it]
spec={'Skeleton length':'Mean_root_length_1000px','Persistent':'Persistent_share_current_pct_mean','New':'New_share_current_pct_mean','Extension':'Extension_share_current_pct_mean','E / Lprev':'Extension_relative_previous_pct_mean'}
audit=list(csv.DictReader((ROOT/'plotted_means_long.csv').open(encoding='utf-8-sig')))
assert len(audit)==60 and sum(r['Mean']!='' for r in audit)==48
for r in audit:
 row=next(q for q in source_rows if q['Material']==r['Material'] and q['Period']==r['Period'])
 expected=row[spec[r['Metric']]]
 if isinstance(expected,(int,float)):assert float(r['Mean'])==expected
 else:assert r['Mean']==''
 assert int(r['nL'])==row['n_length'] and int(r['nI'])==row['n_interval']
 assert r['Axis']==('left' if r['Metric']=='Skeleton length' else 'right')
lines=json.loads((ROOT/'plotted_lines.json').read_text());assert len(lines)==15
for material in ['0353','A017','Q1']:
 ls=[l for l in lines if l['Material']==material];assert len(ls)==5 and {l['Metric'] for l in ls}==set(spec)
 for l in ls:
  assert l['x']==[1,2,3,4]
  for i,value in enumerate(l['y'],1):
   q=next(r for r in audit if r['Material']==material and r['Metric']==l['Metric'] and r['Period']==f'T{i}')
   assert value is None if q['Mean']=='' else value==float(q['Mean'])
  if l['Metric']!='Skeleton length':assert l['y'][0] is None
pdf=fitz.open(ROOT/'Three_series_five_metric_line_charts.pdf');assert len(pdf)==1
p=pdf[0];assert not p.get_images()
spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for line in b['lines'] for s in line['spans'] if s['text'].strip()]
assert all(s['color']==0 for s in spans)
assert all(s['font'] in ['TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'] for s in spans)
assert min(s['size'] for s in spans)>=7.99
assert all(p.rect.contains(fitz.Rect(s['bbox'])) for s in spans)
assert abs(p.rect.width/72*25.4-190.5)<.01 and abs(p.rect.height/72*25.4-101)<.01
sizes={}
for ext in ['jpg','png','tiff']:
 im=Image.open(ROOT/f'Three_series_five_metric_line_charts.{ext}')
 assert im.size==(4500,2385)
 assert all(abs(float(d)-600)<.1 for d in im.info['dpi'])
 sizes[ext]={'pixels':im.size,'dpi':[float(d) for d in im.info['dpi']]}
report={'material_panels':3,'metric_curves_per_panel':5,'total_curves':15,'planned_mean_cells':60,'plotted_numeric_means':48,'undefined_T1_percentage_values':12,'all_means_and_counts_match_frozen_workbook':True,'correct_left_length_right_percentage_axis_assignments':True,'no_imputation_or_normalization':True,'all_text_black':True,'fonts':sorted(set(s['font'] for s in spans)),'font_range_pt':[min(s['size'] for s in spans),max(s['size'] for s in spans)],'all_text_inside_page':True,'vector_PDF':True,'figure_mm':[190.5,101],'raster_exports':sizes}
(ROOT/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
p.get_pixmap(matrix=fitz.Matrix(2.6,2.6)).save(ROOT/'preview.png')
