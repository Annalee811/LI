"""Freeze original training normalization and make a label-free variable-history deployment copy."""
from pathlib import Path
import json,hashlib,re,shutil
import numpy as np
from PIL import Image
R=Path('/workspace/LI');OUT=R/'results/all_genotype_root_quantification_20261030';SRC=Path('/workspace/Temporal-segmentation-model/04_ConvLSTM_GAT_V90');BASE=R/'results/B3_temporal_upload18_noGAT_v66_20261028'

def main():
 a=SRC/'assets';g=dict(np.load(a/'local/data/unet/graph.npz'));raw=np.load(a/'raw_graph.npz')['features'];N=len(raw);stats=np.zeros((N,7),np.float32);owners=np.load(a/'local/data/unet/ownership.npz')
 for ti,t in enumerate(['T1','T2','T3','T4']):
  flat=np.flatnonzero(owners[t]>=0);n=owners[t].ravel()[flat];cnt=np.bincount(n,minlength=N)
  if ti:
   q=np.load(BASE/'unet/full'/(t+'_probability.npz'))['probability'].astype(np.float32);q/=q.sum(0).clip(1e-7);p=q.reshape(3,-1).T[flat]
  else:p=np.full((len(flat),3),1/3,np.float32)
  mu=np.stack([np.bincount(n,weights=p[:,k],minlength=N)/cnt.clip(1) for k in range(3)],1);v=np.stack([np.bincount(n,weights=p[:,k]**2,minlength=N)/cnt.clip(1) for k in range(3)],1)-mu**2;ix=g['phase']==ti
  stats[ix,:3]=mu[ix];stats[ix,3:6]=np.sqrt(v[ix].clip(0));stats[ix,6]=-(mu[ix]*np.log(mu[ix].clip(1e-7))).sum(1)
 x=np.c_[raw,stats];train=g['node_split']==0;mu=x[train].mean(0);sd=x[train].std(0);sd[sd<1e-4]=1
 error=float(np.max(np.abs((x-mu)/sd-g['x'])));assert error<1e-4,error
 e=dict(np.load(a/'local/data/unet/extra.npz'));ex=e['raw_geometry'];em=ex[train].mean(0);es=ex[train].std(0);es[es<1e-4]=1
 eerror=float(np.max(np.abs((ex-em)/es-e['geometry'])));assert eerror<1e-5,eerror
 np.savez_compressed(OUT/'frozen_normalization.npz',node_mean=mu,node_std=sd,geometry_mean=em,geometry_std=es)
 dst=OUT/'inference_core';dst.mkdir(exist_ok=True)
 names=['attention.py','backbone.py','model.py','topology.py','engine.py','decode.py','branch_review.py','axis_consistency.py','junction_consistency.py']
 for name in names:
  text=(SRC/'core'/name).read_text()
  text=text.replace("PERIODS = ['T1', 'T2', 'T3', 'T4']","from paths import PERIODS").replace("PERIODS=['T1','T2','T3','T4']","from paths import PERIODS")
  # Threshold was selected only on original B3 validation targets; freeze it for new subjects.
  start=text.find(' va,vb=graph[\'pairs\'].T;vi=')
  if name in ['engine.py','decode.py'] and start>=0:
   end=text.index(" identity_threshold=best[1]",start)+len(" identity_threshold=best[1]")
   text=text[:start]+" identity_threshold=.40000000000000013"+text[end:]
  if name=='backbone.py':
   text=text.replace('for t in range(4):','for t in range(len(frames)):')
  # Four support slots refer to actual acquisition stages; missing observations supply no evidence, not fake frames.
  if name in ['engine.py','decode.py']:
   text=text.replace("from paths import ROOT,OUT,LAST,BASE,PERIODS,js,csvout,sha","from paths import ROOT,OUT,LAST,BASE,PERIODS,ORIGINAL_PHASE,encode_support,js,csvout,sha")
   text=text.replace("'support':", "'support':")
   text=text.replace('np.array(pv)))','encode_support(pv)))').replace('np.eye(4)[ti]','np.eye(4)[ORIGINAL_PHASE[ti]]')
   text=text.replace('abs(ti-tj)','abs(ORIGINAL_PHASE[ti]-ORIGINAL_PHASE[tj])')
  text=text.replace('if ti<3','if ti<len(PERIODS)-1').replace('range(ti+1,4)','range(ti+1,len(PERIODS))')
  (dst/name).write_text(text)
 # The decoder's helper dependencies contain no training code or target access.
 (dst/'train.py').write_text('''import numpy as np\nimport torch\nfrom torch import nn\nclass PairHead(nn.Module):\n def __init__(self,n):\n  super().__init__();self.net=nn.Sequential(nn.Linear(n,64),nn.LayerNorm(64),nn.ELU(),nn.Linear(64,32),nn.ELU(),nn.Linear(32,1))\n def forward(self,x):return self.net(x)[:,0]\ndef group_score(group,logit,raw,geometry_weight):\n return np.array([float(logit[[group['pair_indices'][str(i)+','+str(j)] for i,j in op]].sum()+geometry_weight*raw[[group['pair_indices'][str(i)+','+str(j)] for i,j in op],96].sum()) for op in group['options']])\n''')
 (dst/'dataset_identity.py').write_text((R/'analysis-scripts/dataset_identity.py').read_text().replace("POLICY_PATH = Path(__file__).resolve().parents[1] / 'dataset/current/identity_policy.json'","POLICY_PATH = Path('/workspace/LI/dataset/current/identity_policy.json')"))
 (dst/'paths.py').write_text('''from pathlib import Path\nimport os,json,csv,hashlib\nimport numpy as np\nWORK=Path(os.environ['ROOT_REPRO_WORK']).resolve();ROOT=WORK;OUT=WORK/'joint';LAST=WORK/'local';BASE=WORK/'base'\nPERIODS=json.loads(os.environ['ROOT_REPRO_PERIODS']);ORIGINAL_PHASE=[int(t[1:])-1 for t in PERIODS]\ndef encode_support(v):\n out=np.zeros(4);out[ORIGINAL_PHASE]=v;return out\ndef sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()\ndef js(p,v):\n p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\\n')\ndef csvout(p,rows):\n p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)\n if not rows:return\n with p.open('w',encoding='utf-8-sig',newline='') as f:\n  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)\n''')
 proof=dict(node_normalization_original_B3_max_difference=error,geometry_normalization_original_B3_max_difference=eerror,node_features=28,geometry_features=4,local_edit_threshold=.45000000000000007,temporal_identity_threshold=.40000000000000013,geometry_weight=2.,assignment_confidence=.9,models_retrained=False,B3_manual_review_mask_applied_to_other_units=False,missing_image_policy='Only actually observed frames enter ConvLSTM; missing adjacent pairs remain NA')
 (OUT/'deployment_precheck.json').write_text(json.dumps(proof,indent=2)+'\n');print('NORMALIZATION_VERIFIED',proof,flush=True)
if __name__=='__main__':main()
