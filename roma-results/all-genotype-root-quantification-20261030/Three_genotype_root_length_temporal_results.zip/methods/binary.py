"""Apply the frozen V35 U-Net to each available complete-width RGB observation."""
import argparse,csv,hashlib,json,sys,time
from pathlib import Path
import numpy as np
from PIL import Image
from skimage.morphology import skeletonize
R=Path('/workspace/LI');OUT=R/'results/all_genotype_root_quantification_20261030';CODE=Path('/workspace/Temporal-segmentation-model/02_root_background');sys.path.insert(0,str(CODE))
from infer import predictor
import torch

def js(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def writecsv(p,rows):
 with p.with_suffix('.tmp').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 p.with_suffix('.tmp').replace(p)
def skeleton_length(sk):
 h=int((sk[:,:-1]&sk[:,1:]).sum());v=int((sk[:-1]&sk[1:]).sum())
 d1=int((sk[:-1,:-1]&sk[1:,1:]&~(sk[:-1,1:]|sk[1:,:-1])).sum());d2=int((sk[:-1,1:]&sk[1:,:-1]&~(sk[:-1,:-1]|sk[1:,1:])).sum())
 return h+v+np.sqrt(2)*(d1+d2)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--limit',type=int);ap.add_argument('--threads',type=int,default=2);a=ap.parse_args()
 rows=json.loads((OUT/'input_audit.json').read_text())['images'];infer,close=predictor('unet',a.threads);records=[]
 han=np.hanning(256).astype(np.float32);blend=np.maximum(han[:,None]*han[None,:],.02);processed=0
 for i,r in enumerate(rows):
  folder=OUT/'binary'/r['position_id'];meta=folder/(r['period']+'_measurement.json');folder.mkdir(parents=True,exist_ok=True)
  if meta.exists():records.append(json.loads(meta.read_text()));continue
  if r['source'] is None:continue
  start=time.monotonic();im=Image.open(r['source']['path']).convert('RGB');im=im.resize((r['normalized_width'],r['normalized_height']),Image.Resampling.LANCZOS);rgb=np.array(im);h,w=rgb.shape[:2]
  xs=list(range(0,w-255,192));ys=list(range(0,h-255,192))
  if xs[-1]!=w-256:xs.append(w-256)
  if ys[-1]!=h-256:ys.append(h-256)
  xy=[(x,y) for y in ys for x in xs];total=np.zeros((h,w),np.float32);weight=total.copy()
  for offset in range(0,len(xy),2):
   coords=xy[offset:offset+2];ims=np.stack([rgb[y:y+256,x:x+256] for x,y in coords]).astype(np.float32)/255
   for (x,y),q in zip(coords,infer(ims)):total[y:y+256,x:x+256]+=q*blend;weight[y:y+256,x:x+256]+=blend
  p=total/weight;gate=p>=.5;sk=skeletonize(gate);length=skeleton_length(sk)
  np.savez_compressed(folder/(r['period']+'_probability.npz'),probability=p.astype(np.float16));Image.fromarray(gate.astype(np.uint8)*255).save(folder/(r['period']+'_root_mask.png'));Image.fromarray(sk.astype(np.uint8)*255).save(folder/(r['period']+'_skeleton.png'))
  preview=rgb.copy();preview[gate]=np.rint(.2*rgb[gate]+.8*np.array([0,190,120])).astype(np.uint8);pv=Image.fromarray(preview);pv.thumbnail((800,800));pv.save(folder/(r['period']+'_overlay.jpg'),quality=91)
  item=dict(genotype=r['genotype'],observation_unit=r['position_id'],original_tube_id=r['tube_id'],period=r['period'],normalized_width=w,normalized_height=h,source_width=r['native_width'],source_height=r['native_height'],root_length_normalized_px=float(length),root_foreground_pixels=int(gate.sum()),root_foreground_fraction=float(gate.mean()),source_SHA256=r['original_SHA256'],checkpoint_SHA256=json.loads((CODE/'assets/weights/unet/selection.json').read_text())['checkpoint_SHA256'],threshold=.5,measurement='8-neighbor skeleton edge length; orthogonal bridges suppress duplicate diagonals; no mask dilation or component removal',actual_model_forward=True)
  js(meta,item);records.append(item);writecsv(OUT/'Root_length_observation_pixels.csv',records);processed+=1
  js(OUT/'binary_status.json',dict(completed=len(records),expected=len(rows),current_unit=r['position_id'],current_period=r['period'],missing_originals=sum(x['source'] is None for x in rows)))
  print('BINARY',len(records),'/',len(rows),r['position_id'],r['period'],'length_px',round(length,2),'foreground',round(gate.mean(),4),'seconds',round(time.monotonic()-start,1),flush=True)
  if a.limit and processed>=a.limit:break
 close()
 if records:writecsv(OUT/'Root_length_observation_pixels.csv',records)
 print('DONE',len(records),'of',len(rows),flush=True)
if __name__=='__main__':main()
