"""Validate actual inference products and assemble a reviewable data package (no logs)."""
import csv,hashlib,json,sys,zipfile,platform,importlib.metadata
from collections import Counter
from pathlib import Path
import numpy as np
from PIL import Image
R=Path('/workspace/LI');OUT=R/'results/all_genotype_root_quantification_20261030';HERE=Path(__file__).resolve().parent

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def rows(name):return list(csv.DictReader((OUT/name).open(encoding='utf-8-sig')))
def main():
 status=json.loads((OUT/'summary_status.json').read_text());audit=json.loads((OUT/'input_audit.json').read_text());units={p['position_id'] for p in audit['positions']}
 assert len(units)==18 and Counter(p.split('-')[0] for p in units)=={'0353':6,'A017':6,'Q1':6}
 assert 'Q1-3-Z3' not in units and '0353-1-Z2' not in units
 measured=0;checked_maps=0;done_units=0
 for r in audit['images']:
  p=OUT/'binary'/r['position_id']/(r['period']+'_measurement.json')
  if not p.exists():continue
  m=json.loads(p.read_text());assert m['actual_model_forward'] is True;assert m['source_SHA256']==r['original_SHA256'];assert m['normalized_width']==2550;assert m['root_length_normalized_px']>=0
  measured+=1
 for u in sorted(units):
  p=OUT/'temporal'/u/'unit_complete.json'
  if not p.exists():continue
  d=json.loads(p.read_text());done_units+=1
  assert d['learned_ConvLSTM_GAT_applied'] and not d['new_annotation_or_manual_ID_input'] and not d['B3_manual_review_mask_applied']
  acquired=next(x['observed_periods'].split(';') for x in audit['positions'] if x['position_id']==u);assert d['periods']==acquired
  boxes=[reg['box_T1_xyxy'] for reg in d['regions']]
  for i,a in enumerate(boxes):
   for b in boxes[i+1:]:assert max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))==0,(u,'overlapping observation bands')
  for reg in d['regions']:
   folder=p.parent/'regions'/reg['region']
   for t in acquired:
    a=np.array(Image.open(folder/(t+'_classes.png')));b=np.array(Image.open(folder/(t+'_baseline_classes.png')))
    assert np.array_equal(a>0,b>0),(u,t,'foreground changed')
    assert set(np.unique(a))<={0,4} if t==acquired[0] else set(np.unique(a))<={0,1,2,3}
    checked_maps+=1
  for tr in d['transitions']:
   if tr['rates_percent'] is not None:
    assert abs(sum(tr['rates_percent'].values())-100)<1e-7
    assert abs(sum(tr['lengths_px'].values())-tr['total_classified_root_length_px'])<1e-7
   else:assert tr['status']=='missing_acquisition'
 ls=rows('Root_length_genotype_mean.csv');ts=rows('Temporal_rates_genotype_mean.csv');detail=rows('Temporal_rates_details.csv')
 assert len(ls)==12 and len(ts)==9 and len(detail)==54
 expected={'0353':[6,6,6],'A017':[6,4,4],'Q1':[4,3,4]}
 for g,nn in expected.items():assert [int(t['Acquired_adjacent_pairs']) for t in ts if t['Genotype']==g]==nn
 for t in ts:
  valid=[v for v in detail if v['Genotype']==t['Genotype'] and v['Interval']==t['Interval'] and v['New_rate_percent']!='']
  assert len(valid)==int(t['Processed_pairs'])
  for k in ['New_rate_percent','Persistent_rate_percent','Extension_rate_percent']:
   if valid:assert abs(float(t[k])-np.mean([float(v[k]) for v in valid]))<1e-7
 assert measured==status['binary_images_complete'] and done_units==status['temporal_units_complete']
 if not status['physical_calibration_confirmed']:assert all(x['Mean_total_root_length_mm']=='' for x in ls)
 with zipfile.ZipFile(OUT/'Genotype_root_lengths_and_temporal_rates.xlsx') as z:assert z.testzip() is None
 check=dict(validated=True,binary_images=measured,temporal_units=done_units,temporal_class_maps=checked_maps,foreground_preserved=True,nonoverlapping_temporal_bands=True,rate_sums_equal_100=True,means_are_unweighted_observation_means=True,missing_dates_not_imputed=True,physical_calibration_confirmed=status['physical_calibration_confirmed'],independent_field_accuracy_evaluation=False)
 (OUT/'validation.json').write_text(json.dumps(check,indent=2)+'\n')
 assets=Path('/workspace/Temporal-segmentation-model')
 refs=[assets/'02_root_background/assets/weights/unet/best_model.pt',assets/'03_temporal_V66/assets/weights/unet/best_temporal_head.pt',assets/'04_ConvLSTM_GAT_V90/assets/local/best.pt',assets/'04_ConvLSTM_GAT_V90/assets/joint/joint_best.pt',assets/'04_ConvLSTM_GAT_V90/assets/joint/data/pairs.npz',OUT/'frozen_normalization.npz',R/'roma-results/all-series-localization-v2/localization_registry.json',R/'roma-results/0353-1/0353-1-Z2/root-guided-localization-v3/geometry_audit.json']
 manifest=[]
 for p in refs:
  if not p.exists():
   if p.name=='best_model.pt':continue
   raise FileNotFoundError(p)
  manifest.append(dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p)))
 for p in sorted(HERE.glob('*.py')):
  if p.name!='publish.py':manifest.append(dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p)))
 (OUT/'model_and_method_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
 versions={}
 for name in ['numpy','scipy','Pillow','scikit-image','torch','torchvision','opencv-python','opencv-python-headless']:
  try:versions[name]=importlib.metadata.version(name)
  except importlib.metadata.PackageNotFoundError:pass
 (OUT/'software_environment.json').write_text(json.dumps(dict(python=sys.version,platform=platform.platform(),packages=versions,device='CPU',torch_threads_per_worker=2,training_performed=False),indent=2)+'\n')
 public_audit=dict(grouping=audit['grouping'],positions=audit['positions'],images=[{k:v for k,v in r.items() if k!='source'}|{'source_available':r['source'] is not None} for r in audit['images']],missing_source_files=audit['missing_source_files'])
 (OUT/'source_availability.json').write_text(json.dumps(public_audit,indent=2)+'\n')
 calibration='物理标定尚未确认。毫米列留空；请确认完整扫描宽度及是否横向裁剪，不能把导出的100 dpi当作CI-600扫描标定。' if not status['physical_calibration_confirmed'] else '毫米换算使用calibration.json中明确确认的完整扫描宽度。'
 missing='；'.join(x['position']+' '+x['period'] for x in audit['missing_source_files']) or '无'
 text=f'''# 三种质根长与时序分类统计

本批次实际完成根系分割 {measured}/66 张，时序推理 {done_units}/18 个观测单元。所有数值来自真实冻结模型前向推理，没有重新训练，也没有补造缺失图像。本数据包的状态以 summary_status.json 为准。

## 表格

- Genotype_root_lengths_and_temporal_rates.xlsx：中文种质平均表、英文平均表、逐观测单元明细和方法说明。
- 根长_种质平均.csv：T1–T4逐种质算术平均根长。
- 时序类别根长占比_种质平均.csv：T1–T2、T2–T3、T3–T4逐种质三类根长占比。
- Root_length_details.csv / Temporal_rates_details.csv：逐观测单元、原始管号、缺拍状态和配准复核标记。

每个种质按用户要求设6个观测重复，先逐单元计算后求算术平均。保留原始管号及位置映射，不将同管不同位置声明为独立生物学重复。本表仅作描述性汇总，未进行显著性检验。

## 根长

冻结的V35 U-Net（验证选择第77轮，阈值0.5）处理完整RGB图像。宽度统一2550像素，保持纵横比，以256×256窗口、192像素步长和Hann加权重建概率图。不对掩膜增粗、删小连通域或修改宽度。根长为骨架中唯一8邻接边长度之和，横竖边长1，斜边长√2；存在正交桥接时不重复加入斜边。

{calibration}

若确认完整扫描宽度为215.9 mm，则每个2550像素宽归一化像素对应215.9/2550 mm，根长毫米值为像素根长乘以该比例。该条件式不作为已确认标定值使用。

全图总根长来自完整扫描图；时序占比来自配准后共同观测区域。二者空间范围不同，不能直接把全图根长乘时序占比当作对应类别的全图根长。

## 时序占比

使用冻结V66 U-Net时序头（第37轮）及V90的已学习ConvLSTM、GAT、局部修正器、连接配对器和结构一致性模块，针对每个新序列重新构图。局部器选择第100轮、联合模块选择第78轮。原训练均值和标准差冻结，阈值来自原验证集，不利用新区域人工标签。B3特定手工复核掩膜不移植到其他区域。

共同观测区保持T1坐标尺度。超过原模型2541×1108工作尺寸的区域采用重叠分块推理，中心优先拼接；只作空间无效区填充，不补造缺失日期。各共同观测带互不重叠，汇总时不重复计算根长。

颜色：持续紫色，新生绿色，延伸黄色；T1蓝色仅表示初始根系，不将首期根系强行分为三类。类别图编码0背景、1持续、2新生、3延伸、4初始根系。

新生/持续/延伸占比 = 当前相邻期共同观测区中该类别骨架根长 ÷ 三类骨架根长之和 ×100%。三类合计100%。这里的“率”是长度组成百分比，不是每日生长速率，也不是以此前一期根长为分母的存活概率。种质平均为各有效观测单元百分比的算术平均，不按根像素数加权。

只把真实拍摄的日期送入ConvLSTM。缺拍T3时不伪造T3，也不输出T2–T3或T3–T4的零值。缺拍序列的彩色图使用上一真实观测期作为条件，不代表缺失相邻期的时序结果。现有相邻拍摄对数：0353为6/6/6，A017为6/4/4，Q1为4/3/4。若源文件暂未恢复，已拍摄对数与已处理对数仍分别列明。

## 数据可用性与复核

暂未恢复的原始源图：{missing}。

已完成输出属于模型估计，不是新样本经独立人工验证的准确率。沿用现有冻结配准；review_required标记保留，Q1-1-Z2的T2–T3连接仍需复核，不能将候选定位当作独立配准真值。

Three_genotype_root_length_temporal_results.zip提供全部表格、实际二元掩膜、骨架、修正前后的时序类别图及校验记录。彩色叠加预览分别放在Root_binary_RGB_previews.zip和Root_temporal_RGB_previews.zip中，每个ZIP都可独立解压。详细中间张量和运行日志不纳入数据包。validation.json记录结果一致性检查，SHA256SUMS.txt校验本包文件，model_and_method_SHA256.json记录模型与方法来源。因当前原始图像不全且物理标定待确认，本包不能表述为18个完整四期序列的最终毫米根长结果。

## 方法复核与继续计算

methods中的脚本对应本次实际推理及汇总，沿用既有LI和Temporal-segmentation-model工作区、源图、配准几何及权重；本结果包不另行复制原始图像及模型权重。脚本顶部工作区路径用于定位这些明确依赖，在其他机器需设置为相应路径。处理顺序为audit.py、binary.py、freeze_inference.py、temporal.py、summarize.py、report.py。binary.py和temporal.py保留已完成的实际输出，可在补齐源图后继续计算，不能把缺失状态替换为零。物理标定确认后，写入calibration.json的full_scan_width_mm及标定来源，再运行summarize.py和report.py即可更新毫米列，无需重新训练模型。
'''
 (OUT/'README.md').write_text(text)
 files={}
 for pattern in ['*.csv','*.xlsx','README.md','summary_status.json','validation.json','source_availability.json','deployment_precheck.json','model_and_method_SHA256.json','software_environment.json','frozen_normalization.npz','calibration.json']:
  for p in OUT.glob(pattern):files[p.name]=p
 previews={folder:{} for folder in ['binary','temporal']}
 for folder in ['binary','temporal']:
  for p in sorted((OUT/folder).rglob('*')):
   if not p.is_file() or p.suffix not in ['.png','.jpg','.json']:continue
   if p.suffix=='.jpg':
    previews[folder]['predictions/'+str(p.relative_to(OUT))]=p
    continue
   if 'tile_audits' in p.parts and p.name not in ['done.json','consistency_verification.json']:continue
   files['predictions/'+str(p.relative_to(OUT))]=p
 for p in sorted(HERE.glob('*.py')):
  if p.name!='publish.py':files['methods/'+p.name]=p
 for folder,entries in previews.items():
  preview_path=OUT/('Root_'+folder+'_RGB_previews.zip')
  with zipfile.ZipFile(preview_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   for name,p in sorted(entries.items()):z.write(p,name)
   z.write(OUT/'README.md','README.md');z.writestr('SHA256SUMS.txt',''.join(sha(p)+'  '+name+'\n' for name,p in sorted(entries.items())))
  with zipfile.ZipFile(preview_path) as z:assert z.testzip() is None
 sums=''.join(sha(p)+'  '+name+'\n' for name,p in sorted(files.items()))
 archive=OUT/'Three_genotype_root_length_temporal_results.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,p in sorted(files.items()):z.write(p,name)
  z.writestr('SHA256SUMS.txt',sums)
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None
 print(json.dumps(dict(**check,archive=str(archive),archive_bytes=archive.stat().st_size,archive_SHA256=sha(archive))))
if __name__=='__main__':main()
