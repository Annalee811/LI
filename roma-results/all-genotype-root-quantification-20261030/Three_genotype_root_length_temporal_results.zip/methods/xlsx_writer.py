import zipfile
from xml.sax.saxutils import escape
def workbook(path, sheets):
    """Small standards-based XLSX; numeric values are not formatted strings."""
    ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'

    def col(i):
        s = ''
        while i:
            i, k = divmod(i - 1, 26)
            s = chr(65 + k) + s
        return s
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        ct = '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        for i in range(len(sheets)):
            ct += f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        z.writestr('[Content_Types].xml', ct + '</Types>')
        z.writestr('_rels/.rels', '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        wb = f'<?xml version="1.0"?><workbook xmlns="{ns}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
        rels = '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        for i, (name, rows) in enumerate(sheets, 1):
            wb += f'<sheet name="{escape(name)}" sheetId="{i}" r:id="rId{i}"/>'
            rels += f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>'
            headers = list(rows[0])
            data = [headers] + [[r.get(k) for k in headers] for r in rows]
            xml = f'<?xml version="1.0"?><worksheet xmlns="{ns}"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols><col min="1" max="1" width="31" customWidth="1"/><col min="2" max="{len(headers)}" width="21" customWidth="1"/></cols><sheetData>'
            for ri, row in enumerate(data, 1):
                xml += f'<row r="{ri}">'
                for ci, v in enumerate(row, 1):
                    addr = col(ci) + str(ri)
                    if isinstance(v, (int, float)) and (not isinstance(v, bool)):
                        xml += f'<c r="{addr}" s="{(2 if isinstance(v, float) else 0)}"><v>{v}</v></c>'
                    else:
                        xml += f'''<c r="{addr}" t="inlineStr" s="{(1 if ri == 1 else 0)}"><is><t>{escape('' if v is None else str(v))}</t></is></c>'''
                xml += '</row>'
            xml += f'</sheetData><autoFilter ref="A1:{col(len(headers))}{len(data)}"/></worksheet>'
            z.writestr(f'xl/worksheets/sheet{i}.xml', xml)
        z.writestr('xl/workbook.xml', wb + '</sheets></workbook>')
        rels += f'<Relationship Id="rId{len(sheets) + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'
        z.writestr('xl/_rels/workbook.xml.rels', rels)
        z.writestr('xl/styles.xml', f'<?xml version="1.0"?><styleSheet xmlns="{ns}"><numFmts count="1"><numFmt numFmtId="164" formatCode="0.000000"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        import xml.etree.ElementTree as ET
        for name in z.namelist():
            ET.fromstring(z.read(name))
