"""Descriptive six-observation-unit means; no imputation or independent-replicate claims."""
import csv,json,math,zipfile,hashlib
from pathlib import Path
import numpy as np
R=Path('/workspace/LI');OUT=R/'results/all_genotype_root_quantification_20261030'
def writecsv(name,rows):
 p=OUT/name
 with p.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
 audit=json.loads((OUT/'input_audit.json').read_text());images=audit['images'];positions=audit['positions'];cpath=OUT/'calibration.json';cal=json.loads(cpath.read_text()) if cpath.exists() else None;scale=cal.get('full_scan_width_mm')/2550 if cal else None
 measurements={};details=[]
 for r in images:
  p=OUT/'binary'/r['position_id']/(r['period']+'_measurement.json');m=json.loads(p.read_text()) if p.exists() else None
  if m:measurements[r['position_id'],r['period']]=m
  details.append(dict(Genotype=r['genotype'],Observation_unit=r['position_id'],Original_tube=r['tube_id'],Period=r['period'],Status='completed' if m else 'source_unavailable' if r['source'] is None else 'processing',Total_root_length_px=m['root_length_normalized_px'] if m else None,Total_root_length_mm=m['root_length_normalized_px']*scale if m and scale else None,Normalized_width_px=2550,Normalized_height_px=m['normalized_height'] if m else None))
 writecsv('Root_length_details.csv',details);summary=[]
 for geno in ['0353','A017','Q1']:
  pp=[p['position_id'] for p in positions if p['position_id'].startswith(geno+'-')];assert len(pp)==6
  for t in ['T1','T2','T3','T4']:
   expected=[r for r in images if r['position_id'] in pp and r['period']==t];vals=[measurements[p,t]['root_length_normalized_px'] for p in pp if (p,t) in measurements]
   summary.append(dict(Genotype=geno,Period=t,Requested_observation_units=6,Acquired_images=len(expected),Processed_images=len(vals),Missing_acquisitions=6-len(expected),Unrestored_source_images=sum(r['source'] is None for r in expected),Mean_total_root_length_px=float(np.mean(vals)) if vals else None,Mean_total_root_length_mm=float(np.mean(vals))*scale if vals and scale else None,Calibration_status='confirmed_full_scan_width' if scale else 'physical_calibration_pending'))
 writecsv('Root_length_genotype_mean.csv',summary)
 interval_details=[];complete=0
 for p in positions:
  unit=p['position_id'];f=OUT/'temporal'/unit/'unit_complete.json';d=json.loads(f.read_text()) if f.exists() else None;observed=p['observed_periods'].split(';');src=[r for r in images if r['position_id']==unit];source_missing=any(r['source'] is None for r in src)
  if d:complete+=1
  for a,b in [('T1','T2'),('T2','T3'),('T3','T4')]:
   entry=next((v for v in d['transitions'] if v['interval']==a+'-'+b),None) if d else None
   status=entry['status'] if entry else 'missing_acquisition' if a not in observed or b not in observed else 'source_unavailable' if source_missing else 'processing'
   rates=entry.get('rates_percent') if entry else None;lengths=entry.get('lengths_px') if entry else None
   interval_details.append(dict(Genotype=unit.split('-')[0],Observation_unit=unit,Original_tube=p['tube_id'],Interval=a+'-'+b,Status=status,History_complete_four_periods=len(observed)==4,New_rate_percent=rates['new'] if rates else None,Persistent_rate_percent=rates['persistent'] if rates else None,Extension_rate_percent=rates['extension'] if rates else None,New_root_length_T1px=lengths['new'] if lengths else None,Persistent_root_length_T1px=lengths['persistent'] if lengths else None,Extension_root_length_T1px=lengths['extension'] if lengths else None,Registration_review_required=p['review_required']))
 writecsv('Temporal_rates_details.csv',interval_details);rates_summary=[]
 for geno in ['0353','A017','Q1']:
  for interval in ['T1-T2','T2-T3','T3-T4']:
   rr=[v for v in interval_details if v['Genotype']==geno and v['Interval']==interval];good=[v for v in rr if v['New_rate_percent'] is not None];expected=sum(v['Status']!='missing_acquisition' for v in rr)
   m={k:float(np.mean([v[k] for v in good])) if good else None for k in ['New_rate_percent','Persistent_rate_percent','Extension_rate_percent']}
   if good:assert abs(sum(m.values())-100)<1e-7
   rates_summary.append(dict(Genotype=geno,Interval=interval,Requested_observation_units=6,Acquired_adjacent_pairs=expected,Processed_pairs=len(good),Missing_acquisition_pairs=6-expected,Unrestored_source_pairs=sum(v['Status']=='source_unavailable' for v in rr),Pending_model_pairs=sum(v['Status']=='processing' for v in rr),Registration_review_pairs=sum(str(v['Registration_review_required']).lower()=='true' for v in good),**m))
 writecsv('Temporal_rates_genotype_mean.csv',rates_summary)
 cn_lengths=[dict(种质=r['Genotype'],时期=r['Period'],计划重复数=6,实际拍摄数=r['Acquired_images'],已处理数=r['Processed_images'],平均根长_像素=r['Mean_total_root_length_px'],平均根长_毫米=r['Mean_total_root_length_mm'],标定状态='已确认' if scale else '待确认扫描宽度及有无裁剪') for r in summary]
 cn_rates=[dict(种质=r['Genotype'],相邻时期=r['Interval'],计划重复数=6,有效拍摄对数=r['Acquired_adjacent_pairs'],已处理对数=r['Processed_pairs'],新生根长占比_百分比=r['New_rate_percent'],持续根长占比_百分比=r['Persistent_rate_percent'],延伸根长占比_百分比=r['Extension_rate_percent'],待复核配准对数=r['Registration_review_pairs']) for r in rates_summary]
 writecsv('根长_种质平均.csv',cn_lengths);writecsv('时序类别根长占比_种质平均.csv',cn_rates)
 protocol=[['Item','Definition'],['Binary model','Frozen V35 U-Net selected epoch77, threshold0.5; actual forward on every available image'],['Full-scan normalization','2550px complete image width; original aspect retained; no mask dilation or component cleaning'],['Root length','Unique8-neighbor skeleton edge length; diagonal edges excluded when an orthogonal bridge exists'],['Physical calibration','Pending scanner-width/cropping confirmation' if not scale else 'Confirmed complete scan width '+str(cal['full_scan_width_mm'])+'mm'],['Temporal model','V66 temporal head and frozen V90 ConvLSTM/GAT/local/connection/structural modules; fresh prediction-only graph per image sequence'],['Human annotations at new inference','None; B3-specific manual review masks are not transferred'],['Temporal field','Existing common observation bands; original region review flags retained; candidate registration is not independent validation'],['Rate definition','Category skeleton length / sum of persistent,new,extension skeleton lengths in the current adjacent-pair common field ×100'],['Genotype mean','Arithmetic mean of per-observation measurements or percentages; no pooling by root-pixel count'],['Replicates','Six observation units per genotype at user request. Original tube IDs retained; no claim of six independent biological tubes'],['Missing dates','NA; no fabricated image, zero-filled observation, or substituted acquisition. Actual available histories only'],['Validation status','Model-derived phenotypes; no external manual segmentation or temporal accuracy labels for these new fields']]
 try:
  import openpyxl
  from openpyxl.styles import Font,PatternFill,Alignment
  wb=openpyxl.Workbook();wb.remove(wb.active)
  for title,rows in [('根长_种质平均',cn_lengths),('时序占比_种质平均',cn_rates),('Root_length_means',summary),('Root_length_details',details),('Temporal_rate_means',rates_summary),('Temporal_rate_details',interval_details)]:
   ws=wb.create_sheet(title);ws.append(list(rows[0]))
   for row in rows:ws.append([row[k] for k in rows[0]])
   ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
   for c in ws[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='25536B');c.alignment=Alignment(wrap_text=True)
   for col in ws.columns:ws.column_dimensions[col[0].column_letter].width=min(38,max(16,max(len(str(c.value or '')) for c in col)+2))
   for row in ws.iter_rows(min_row=2):
    for c in row:
     if isinstance(c.value,float):c.number_format='0.0000'
  ws=wb.create_sheet('Methods_and_units')
  for row in protocol:ws.append(row)
  ws.column_dimensions['A'].width=30;ws.column_dimensions['B'].width=110
  for row in ws.iter_rows():
   for c in row:c.alignment=Alignment(wrap_text=True,vertical='top')
  wb.save(OUT/'Genotype_root_lengths_and_temporal_rates.xlsx')
 except ImportError:
  from xlsx_writer import workbook
  workbook(OUT/'Genotype_root_lengths_and_temporal_rates.xlsx',[('根长_种质平均',cn_lengths),('时序占比_种质平均',cn_rates),('Root_length_means',summary),('Root_length_details',details),('Temporal_rate_means',rates_summary),('Temporal_rate_details',interval_details),('Methods_and_units',[dict(Item=r[0],Definition=r[1]) for r in protocol[1:]])])
 status=dict(binary_images_complete=len(measurements),binary_images_expected=len(images),source_images_unrestored=len(audit['missing_source_files']),temporal_units_complete=complete,temporal_units_expected=len(positions),physical_calibration_confirmed=scale is not None,temporal_inference_complete_for_available_sources=complete==sum(not any(r['source'] is None for r in images if r['position_id']==p['position_id']) for p in positions))
 (OUT/'summary_status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
if __name__=='__main__':main()
