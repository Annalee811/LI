"""Fresh label-free graph inputs and original V90 learned/structural inference on one tile."""
import os,sys,json,pickle,shutil,subprocess,time,importlib.util
from pathlib import Path
import numpy as np
from PIL import Image
from scipy import ndimage as ndi
from scipy.spatial import cKDTree
from skimage.morphology import skeletonize
import torch
R=Path('/workspace/LI');ROOT=R/'results/all_genotype_root_quantification_20261030';ASSET=Path('/workspace/Temporal-segmentation-model/04_ConvLSTM_GAT_V90/assets');WORK=Path(sys.argv[1]).resolve();PERIODS=json.loads(os.environ['ROOT_REPRO_PERIODS']);ORIGINAL=[int(t[1:])-1 for t in PERIODS]
os.environ['ROOT_REPRO_WORK']=str(WORK);sys.path.insert(0,str(ROOT/'inference_core'))
from model import LocalCorrector
from backbone import pool_groups
from topology import build,matchings
from train import PairHead
from paths import js,encode_support
SPEC=importlib.util.spec_from_file_location('original_native_chunks',R/'analysis-scripts/0353-2-B3_segmentation_pilot/temporal_gat_new_growth_v68/prepare.py');CH=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(CH)
torch.set_num_threads(2);torch.set_num_interop_threads(1)
H,W=1108,2541

def topo_features(mask):
 sk=skeletonize(mask);deg=ndi.convolve(sk.astype(np.uint8),np.ones((3,3),np.uint8),mode='constant')-sk
 def prox(v):return np.exp(-ndi.distance_transform_edt(~v)**2/128).astype(np.float32) if v.any() else np.zeros(mask.shape,np.float32)
 return prox(sk&(deg==1)),prox(sk&(deg>=3)),ndi.distance_transform_edt(mask).clip(0,8).astype(np.float32)/8

def candidates(a,gate,prior,owner,groups,geom,ti):
 if ti==0:return np.zeros((H,W),bool),np.zeros((H,W,2),np.float32)
 sk=skeletonize(gate);deg=ndi.convolve(sk.astype(np.uint8),np.ones((3,3),np.uint8),mode='constant')-sk;d=ndi.distance_transform_edt(~(sk&(deg>=3)));conn=(a==3)&(d<=4);island=np.zeros((H,W),bool)
 hist=np.zeros((len(groups),3),np.int64);valid=owner>=0;np.add.at(hist,(owner[valid],a[valid].astype(np.int64)-1),1);chain_hist=np.zeros((groups.max()+1,3),np.int64);np.add.at(chain_hist,groups,hist)
 def padded(sl):return np.s_[max(0,sl[0].start-3):min(H,sl[0].stop+3),max(0,sl[1].start-3):min(W,sl[1].stop+3)]
 for c,other in [(2,3),(3,2),(3,1)]:
  lab,num=ndi.label(a==c,np.ones((3,3),bool));sizes=np.bincount(lab.ravel());arc=np.bincount(lab[sk],minlength=num+1);boxes=ndi.find_objects(lab)
  for k in np.flatnonzero((sizes>0)&(sizes<=72)&(arc<=16)):
   if not k:continue
   sl=boxes[k-1];yy,xx=np.where(lab[sl]==k);yy+=sl[0].start;xx+=sl[1].start;chains=np.unique(groups[owner[yy,xx]]);big=padded(sl);near=ndi.binary_dilation(lab[big]==k,iterations=3);same=np.isin(groups[owner[big].clip(0)],chains)&gate[big]
   if ((a[big]==other)&near&same).sum()>=3 and chain_hist[chains,other-1].sum()>=3*len(yy):island[yy,xx]=True
 pd=ndi.distance_transform_edt(~prior);bridges=np.zeros_like(gate);lab,num=ndi.label(a==3,np.ones((3,3),bool));sizes=np.bincount(lab.ravel());arc=np.bincount(lab[sk],minlength=num+1);boxes=ndi.find_objects(lab)
 for k in np.flatnonzero((sizes>0)&(sizes<=180)&(arc<=32)&(arc>=2)):
  if not k:continue
  sl=boxes[k-1];yy,xx=np.where((lab[sl]==k)&sk[sl]);yy+=sl[0].start;xx+=sl[1].start;xy=np.c_[xx,yy]
  if len(xy)<2:continue
  vec=np.linalg.svd(xy-xy.mean(0),full_matrices=False)[2][0];p=xy@vec;lo,hi=xy[p.argmin()],xy[p.argmax()]
  if np.linalg.norm(lo-hi)<2:continue
  big=padded(sl);oy,ox=np.where((a[big]==1)&ndi.binary_dilation(lab[big]==k,iterations=3));oy+=big[0].start;ox+=big[1].start;q=np.c_[ox,oy]
  if not len(q):continue
  left=(np.linalg.norm(q-lo,axis=1)<=4)&((q-lo)@vec<1);right=(np.linalg.norm(q-hi,axis=1)<=4)&((q-hi)@vec>-1)
  if left.any() and right.any() and (pd[sl][lab[sl]==k]<=2.5).mean()>=.8:bridges[sl]|=lab[sl]==k
 arms=geom[owner.clip(0),0];attachment=gate&(d<=2)&(ndi.distance_transform_edt(a!=2)<=8)&(arms>.625)&(arms<.875)
 kind=np.stack([conn|attachment,island|bridges],-1).astype(np.float32);return conn|attachment|island|bridges,kind

def main():
 import hashlib
 scratch=Path('/tmp/root_quantification_graphs')/hashlib.sha256(str(WORK).encode()).hexdigest()[:18];scratch.mkdir(parents=True,exist_ok=True)
 for name in ['local','base','joint','branch','axis','junction','reference']:
  source=WORK/name;target=scratch/name
  if source.exists() and not source.is_symlink():
   if target.exists():shutil.rmtree(target)
   shutil.move(str(source),str(target))
  else:target.mkdir(exist_ok=True)
  if not source.exists():source.symlink_to(target,target_is_directory=True)
 start=time.monotonic();data=np.load(WORK/'input.npz');rgb={t:data[t+'_RGB'] for t in PERIODS};prob={t:data[t+'_root_probability'].astype(np.float32) for t in PERIODS};gates={t:data[t+'_root_mask'].astype(bool) for t in PERIODS};pbase={t:data[t+'_temporal_probability'].astype(np.float32) for t in PERIODS};base={t:data[t+'_classes'] for t in PERIODS};data.close();(WORK/'input.npz').unlink()
 if any(skeletonize(gates[t]).sum()<12 for t in PERIODS):raise RuntimeError('Insufficient predicted skeleton support for V90 graph deployment; no synthetic nodes were inserted')
 norm=np.load(ROOT/'frozen_normalization.npz');node_features=[];centers=[];tangents=[];phase=[];chains=[];owners={};nodes=[];nativeedges=[];pixels={};frames=[];N=0
 for ti,t in enumerate(PERIODS):
  prev=PERIODS[max(0,ti-1)];parts,ch,owner=CH.native_chunks(gates[t]);owner[gates[t]]+=N;owners[t]=owner;flat=np.flatnonzero(gates[t]);nid=owner.ravel()[flat];order=np.argsort(nid,kind='stable');ordered=flat[order];cnt=np.bincount(nid-N,minlength=len(parts));ends=np.cumsum(cnt);beg=np.r_[0,ends[:-1]]
  color=rgb[t].astype(np.float32)/255;oldcolor=rgb[prev].astype(np.float32)/255;pd=ndi.distance_transform_edt(~gates[prev]);wd=ndi.distance_transform_edt(gates[t]);bychain={}
  for j,q in enumerate(parts):
   ix=ordered[beg[j]:ends[j]];pix=color.reshape(-1,3)[ix];pp=oldcolor.reshape(-1,3)[ix];p=q.astype(float);center=p.mean(0);vec=p[-1]-p[0];length=np.linalg.norm(vec);vec=vec/max(length,1)
   if length==0:vec=np.array([1.,0.])
   arc=np.linalg.norm(np.diff(p,axis=0),axis=1).sum();width=float(wd.ravel()[ix].mean()) if len(ix) else 1
   node_features.append([center[0]/2541,center[1]/1108,length/12,arc/16,vec[0],vec[1],width/10,float(pd.ravel()[ix].mean())/32 if len(ix) else 1,*(pix.mean(0) if len(pix) else [0]*3),*(pix.std(0) if len(pix) else [0]*3),*((pix-pp).mean(0) if len(pix) else [0]*3),*np.eye(4)[ORIGINAL[ti]]]);centers.append(center);tangents.append(vec);phase.append(ti);chains.append(int(ch[j]));nodes.append(q);bychain.setdefault(int(ch[j]),[]).append(N+j)
  for ids in bychain.values():nativeedges.extend(zip(ids[:-1],ids[1:]))
  N+=len(parts);pixels[t]=dict(pixel=flat,node=nid);print('GRAPH_CHUNKS',t,len(parts),flush=True)
 raw=np.array(node_features,np.float32);centers=np.array(centers);tangents=np.array(tangents);phase=np.array(phase);chains=np.array(chains);pairs={tuple(sorted(map(int,p))) for p in nativeedges}
 for ti in range(len(PERIODS)):
  ids=np.flatnonzero(phase==ti);tree=cKDTree(centers[ids]);dd,nn=tree.query(centers[ids],k=min(7,len(ids)))
  for u,ds,vs in zip(ids,dd,nn):
   for d,j in zip(np.atleast_1d(ds),np.atleast_1d(vs)):
    if d<=26 and u!=ids[j]:pairs.add(tuple(sorted((int(u),int(ids[j])))))
  if ti:
   prev=np.flatnonzero(phase==ti-1);dd,nn=cKDTree(centers[prev]).query(centers[ids],k=min(4,len(prev)))
   for u,ds,vs in zip(ids,dd,nn):
    for d,j in zip(np.atleast_1d(ds),np.atleast_1d(vs)):
     if d<=22:pairs.add(tuple(sorted((int(u),int(prev[j])))))
 pairs=np.array(sorted(pairs),np.int64);u,v=pairs.T;delta=centers[v]-centers[u];samepath=(phase[u]==phase[v])&(chains[u]==chains[v]);orig=np.array(ORIGINAL)[phase]
 attrs=np.c_[np.linalg.norm(delta,axis=1)/32,delta/32,np.abs((tangents[u]*tangents[v]).sum(1)),np.abs(orig[u]-orig[v]),samepath.astype(float),np.abs(raw[u,6]-raw[v,6]),np.minimum(np.linalg.norm(delta,axis=1),100)/100].astype(np.float32)
 folder=WORK/'local/data/unet';folder.mkdir(parents=True,exist_ok=True);stats=np.zeros((N,7),np.float32);pf={};topof={t:topo_features(gates[t]) for t in PERIODS};extra=np.zeros((N,4),np.float32)
 for ti,t in enumerate(PERIODS):
  prev=PERIODS[max(0,ti-1)];flat=pixels[t]['pixel'];nid=pixels[t]['node'];yy,xx=np.divmod(flat,W);counts=np.bincount(nid,minlength=N);pr=pbase[t].reshape(3,-1).T[flat];pr/=pr.sum(1).clip(1e-7)[:,None]
  mu=np.stack([np.bincount(nid,weights=pr[:,k],minlength=N)/counts.clip(1) for k in range(3)],1);var=np.stack([np.bincount(nid,weights=pr[:,k]**2,minlength=N)/counts.clip(1) for k in range(3)],1)-mu**2;ids=phase==ti;stats[ids,:3]=mu[ids];stats[ids,3:6]=np.sqrt(var[ids].clip(0));stats[ids,6]=-(mu[ids]*np.log(mu[ids].clip(1e-7))).sum(1)
  color=rgb[t].astype(np.float32)/255;oldcolor=rgb[prev].astype(np.float32)/255;tp,jp,wd=topof[t];off=np.c_[xx-centers[nid,0],yy-centers[nid,1]]/12;pd=ndi.distance_transform_edt(~gates[prev]).clip(0,32).astype(np.float32)/32
  pf[t]=np.c_[np.log(pr.clip(1e-5)),off,color.reshape(-1,3)[flat],np.abs(color-oldcolor).reshape(-1,3)[flat],pd.ravel()[flat],topof[prev][0].ravel()[flat],tp.ravel()[flat],jp.ravel()[flat]].astype(np.float32)
  frame=np.concatenate([color,prob[t][...,None],gates[t][...,None].astype(np.float32),wd[...,None],tp[...,None],jp[...,None]],-1);frames.append(np.stack([np.array(Image.fromarray(frame[:,:,c]).resize((318,139),Image.Resampling.BILINEAR)) for c in range(8)]).astype(np.float16))
  sk=skeletonize(gates[t]);deg=ndi.convolve(sk.astype(np.uint8),np.ones((3,3),np.uint8),mode='constant')-sk;jn=sk&(deg>=3);tip=sk&(deg==1);_,near=ndi.distance_transform_edt(~jn,return_indices=True);td=ndi.distance_transform_edt(~tip);cache={};gy,gx=np.ogrid[-10:11,-10:11];d=np.hypot(gx,gy);ann=(d>=3)&(d<=10);outer=d>=8
  for n in np.flatnonzero(ids):
   x,y=np.rint(centers[n]).astype(int);jx,jy=int(near[1,y,x]),int(near[0,y,x]);dist=np.hypot(jx-x,jy-y)
   if dist<=15 and jn.any():
    key=(jx,jy)
    if key not in cache:
     patch=np.zeros((21,21),bool);x0,x1=max(0,jx-10),min(W,jx+11);y0,y1=max(0,jy-10),min(H,jy+11);patch[y0-jy+10:y1-jy+10,x0-jx+10:x1-jx+10]=sk[y0:y1,x0:x1];lab,num=ndi.label(patch&ann,np.ones((3,3)));cache[key]=sum(k>0 for k in np.unique(lab[outer]))
    extra[n,0]=min(cache[key],6)/4;extra[n,1]=np.exp(-dist*dist/72)
   extra[n,2]=np.exp(-td[y,x]**2/128)
  extra[ids,3]=np.bincount(nid,weights=pf[t][:,11],minlength=N)[ids]/counts[ids].clip(1)
  np.savez_compressed(folder/(t+'_pixels.npz'),pixel=flat,node=nid,pf=pf[t]);p=WORK/'base/data/upper'/(t+'_RGB.png');p.parent.mkdir(parents=True,exist_ok=True);Image.fromarray(rgb[t]).save(p);p=WORK/'base/unet/full'/(t+'_classes.png');p.parent.mkdir(parents=True,exist_ok=True);Image.fromarray(base[t]).save(p)
 x=((np.c_[raw,stats]-norm['node_mean'])/norm['node_std']).astype(np.float32);geometry=((extra-norm['geometry_mean'])/norm['geometry_std']).astype(np.float32)
 graph=dict(x=x,pairs=pairs,attrs=attrs,phase=phase,centers=centers,target=np.full(len(pairs),-1,np.int64),split=np.full(len(pairs),-1,np.int8),node_split=np.full(N,-1,np.int8),root_target=np.full(N,-1,np.int32))
 np.savez_compressed(folder/'graph.npz',**graph);np.savez_compressed(folder/'ownership.npz',**owners);np.savez_compressed(WORK/'raw_graph.npz',features=raw);np.save(WORK/'local/data/spatial.npy',np.full((H,W),-1,np.int8))
 # Preserve exactly the original endpoint-bridge candidate construction, without identity targets.
 spec=importlib.util.spec_from_file_location('deploy_route',R/'analysis-scripts/0353-2-B3_segmentation_pilot/unet_junction_upload24_v76/routing.py');route=importlib.util.module_from_spec(spec)
 import types
 oldprep=sys.modules.get('prepare');sys.modules['prepare']=types.SimpleNamespace(GEO=None,js=js);route.PERIODS=PERIODS;exec(compile(Path(spec.origin).read_text().replace("['T1','T2','T3','T4']",'PERIODS'),spec.origin,'exec'),route.__dict__);route.build_routing(folder,dict(features=raw),'unet',graph['node_split'],graph['root_target'])
 if oldprep is None:sys.modules.pop('prepare',None)
 else:sys.modules['prepare']=oldprep
 graph=dict(np.load(folder/'graph.npz'));groups=np.load(folder/'routing.npz')['native_group'];pairs=graph['pairs'];attrs=graph['attrs'];frames=np.stack(frames).astype(np.float32)
 model=LocalCorrector();ck=torch.load(ASSET/'local/best.pt',map_location='cpu',weights_only=True);model.load_state_dict(ck['state_dict']);model.eval();args=[torch.from_numpy(v) for v in [frames,x,pairs,attrs,phase.astype(np.int64),centers.astype(np.float32),geometry]]
 with torch.inference_mode():h,_,_=model(*args)
 for ti,t in enumerate(PERIODS):
  out=base[t].copy();prev=PERIODS[max(0,ti-1)];eligible,kind=candidates(out,gates[t],gates[prev],owners[t],groups,extra,ti);px=pixels[t];ix=np.flatnonzero(eligible.ravel()[px['pixel']]);anchor=out.ravel()[px['pixel']].astype(np.int64)-1
  if len(ix):
   feat=np.c_[pf[t],np.eye(3)[anchor] if ti else np.zeros((len(anchor),3)),kind.reshape(-1,2)[px['pixel']]].astype(np.float32)
   with torch.inference_mode():log,e=model.local_logits(h,torch.from_numpy(px['node'][ix]),torch.from_numpy(feat[ix]));pp=log.softmax(1);confidence=pp.max(1).values*e.sigmoid();label=pp.argmax(1);allow=(feat[ix,18]<=.5)|(label.numpy()!=2);take=(confidence.numpy()>=.45000000000000007)&allow
   out.ravel()[px['pixel'][ix[take]]]=label.numpy()[take]+1
  p=WORK/'local/full'/(t+'_classes.png');p.parent.mkdir(parents=True,exist_ok=True);assert np.array_equal(out>0,gates[t]);Image.fromarray(out).save(p)
 print('LOCAL_FORWARD_COMPLETE',N,'nodes',len(pairs),'edges',flush=True)
 ck=torch.load(ASSET/'joint/joint_best.pt',map_location='cpu',weights_only=True);model.load_state_dict(ck['backbone']);model.eval()
 with torch.inference_mode():h,link,z=model(*args)
 top={t:build(gates[t]) for t in PERIODS};trees={};tangents2={}
 for t,tp in top.items():
  pts=[];vec=[]
  for s in tp['segments']:
   p=s['points'];l=p[np.maximum(np.arange(len(p))-5,0)];r=p[np.minimum(np.arange(len(p))+5,len(p)-1)];v=r-l;v=v/np.linalg.norm(v,axis=1).clip(1e-8)[:,None];pts.extend(p);vec.extend(v)
  trees[t]=cKDTree(np.array(pts));tangents2[t]=np.array(vec)
 def support(tt,pts,vec):
  dd,nn=trees[tt].query(pts,k=4);return float(((dd<=3.5)&(np.abs((tangents2[tt][nn]*vec).sum(-1))>=.9)).any(1).mean())
 features=[];groups2=[];armrecords={};armnodes=[];armptr=[0];pa=[];pb=[]
 for ti,t in enumerate(PERIODS):
  armrecords[t]=[]
  for ji,hub in enumerate(top[t]['hubs']):
   arms=hub['arms'];n=len(arms)
   if n not in [3,4] or any(len(aa['body_points'])<4 for aa in arms):continue
   aa=[];armids=[]
   for arm in arms:
    p=arm['body_points'];ns=np.unique(owners[t][p[:,1],p[:,0]]);ns=ns[ns>=0];armids.append(len(armptr)-1);armnodes.extend(ns);armptr.append(len(armnodes));emb=z[ns].mean(0).numpy();emb/=max(np.linalg.norm(emb),1e-8)
    aa.append(dict(embedding=emb,width=float(raw[ns,6].mean()),color=(rgb[t][p[:,1],p[:,0]].astype(np.float32)/255).mean(0),support=encode_support([support(tt,p,arm['direction']) for tt in PERIODS]),rid=-1,nodes=ns,**arm))
   local={}
   for i in range(n):
    for j in range(i+1,n):
     a,b=aa[i],aa[j];local[str(i)+','+str(j)]=len(features);pa.append(armids[i]);pb.append(armids[j]);features.append(np.r_[np.abs(a['embedding']-b['embedding']),a['embedding']*b['embedding'],-a['direction']@b['direction'],np.linalg.norm(a['point']-b['point'])/16,abs(a['width']-b['width']),np.abs(a['color']-b['color']),a['support']+b['support'],np.abs(a['support']-b['support']),np.eye(4)[ORIGINAL[ti]]].astype(np.float32))
   groups2.append(dict(period=t,hub=ji,split=-1,pair_indices=local,options=matchings(n),target_option=-1));armrecords[t].append((ji,aa))
 saved=np.load(ASSET/'joint/data/pairs.npz');mean=saved['mean'];std=saved['std'];rawpair=np.array(features,np.float32).reshape(-1,114);xx=(rawpair-mean)/std
 pair=PairHead(114);pair.load_state_dict(ck['pair']);pair.eval()
 with torch.inference_mode():
  pooled=torch.nn.functional.normalize(pool_groups(z,torch.tensor(armnodes,dtype=torch.int64),torch.tensor(armptr)),dim=1);f=torch.cat([(pooled[pa]-pooled[pb]).abs(),pooled[pa]*pooled[pb],torch.from_numpy(rawpair[:,96:])],1);f=(f-torch.from_numpy(mean))/torch.from_numpy(std);logit=pair(f).numpy()
 dest=WORK/'joint';(dest/'data').mkdir(parents=True,exist_ok=True);np.savez_compressed(dest/'data/pairs.npz',x=xx,raw=rawpair,mean=mean,std=std,target=np.full(len(xx),-1),split=np.full(len(xx),-1))
 with (dest/'data/topology.pkl').open('wb') as out:pickle.dump(dict(topos=top,groups=groups2,arms=armrecords),out)
 np.save(dest/'joint_pair_logits.npy',logit);np.savez_compressed(dest/'joint_inference.npz',h=h.numpy(),embedding=z.numpy(),connection=link.sigmoid().numpy(),features=f.numpy());shutil.copy2(ASSET/'joint/joint_best.pt',dest/'joint_best.pt');js(dest/'joint_training_results.json',dict(selected_epoch=78,geometry_weight=2.,assignment_confidence=.9));(WORK/'reference').mkdir(exist_ok=True);js(WORK/'reference/reference_provenance.json',dict(inference_only=True,manual_reference_labels_provided=False,position=os.environ['ROOT_REPRO_POSITION']))
 print('JOINT_FORWARD_COMPLETE',len(xx),'junction pairs',flush=True)
 for script in ['decode.py','branch_review.py','axis_consistency.py','junction_consistency.py']:
  subprocess.run([sys.executable,str(ROOT/'inference_core'/script)],check=True)
  if script=='branch_review.py':shutil.copytree(WORK/'branch/candidate_full',WORK/'branch/full',dirs_exist_ok=True)
 for t in PERIODS:
  a=np.array(Image.open(WORK/'junction/full'/(t+'_classes.png')));assert np.array_equal(a>0,gates[t])
 # Preserve final semantic maps/audits before removing regenerable scratch tensors.
 final_copy=WORK/'junction_persistent';shutil.copytree(WORK/'junction',final_copy,dirs_exist_ok=True)
 if (WORK/'junction').is_symlink():(WORK/'junction').unlink()
 final_copy.rename(WORK/'junction')
 for name in ['local','base','joint','branch','axis','reference']:
  if (WORK/name).is_symlink():(WORK/name).unlink()
 shutil.rmtree(scratch)
 js(WORK/'done.json',dict(actual_ConvLSTM_GAT_forward=True,actual_structural_decoding=True,new_manual_labels_or_IDs_used=False,B3_review_mask_applied=False,periods=PERIODS,seconds=time.monotonic()-start));print('TILE_DONE',round(time.monotonic()-start,1),flush=True)
if __name__=='__main__':main()
