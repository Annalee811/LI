import csv,hashlib,json,zipfile
from pathlib import Path
from collections import Counter
from PIL import Image
R=Path('/workspace/LI');OUT=R/'results/all_genotype_root_quantification_20261030';OUT.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
rows=list(csv.DictReader((R/'dataset/current/active_images.csv').open(encoding='utf-8-sig')));positions=list(csv.DictReader((R/'dataset/current/active_positions.csv').open(encoding='utf-8-sig')))
index={}
for base in [R/'results/microtube_registration/input/raw',OUT/'source_inputs']:
 for p in base.rglob('*'):
  if p.is_file() and p.suffix.lower() in ['.png','.jpg','.jpeg','.tif','.tiff']:index[sha(p)]=dict(path=str(p))
needed={r['original_SHA256'] for r in rows}-set(index)
zips=[]
for base in [Path('/workspace/attachments'),R/'results',Path('/workspace/shared/downloads')]:
 for p in base.rglob('*.zip'):
  if ('Q1' in p.name or p.name in ['V-.zip','V-变化.zip']) and p.stat().st_size>1000000:zips.append(p)
for p in zips:
 print('SCAN_ARCHIVE',p,flush=True)
 with zipfile.ZipFile(p) as z:
  for e in z.infolist():
   if Path(e.filename).suffix.lower() not in ['.png','.jpg','.jpeg','.tif','.tiff']:continue
   b=z.read(e);h=hashlib.sha256(b).hexdigest()
   if h in needed:
    dest=OUT/'source_inputs'/('source_'+h[:18]+Path(e.filename).suffix.lower());dest.parent.mkdir(exist_ok=True);dest.write_bytes(b);index[h]=dict(path=str(dest),archive=str(p),archive_entry=e.filename)
 needed={r['original_SHA256'] for r in rows}-set(index)
 if not needed:break
new=[]
for r in rows:
 h=r['original_SHA256'];item=dict(r,genotype=r['position_id'].split('-')[0],source=index.get(h))
 if item['source']:
  with Image.open(item['source']['path']) as im:item.update(native_width=im.width,native_height=im.height,embedded_dpi=[float(v) for v in im.info['dpi']] if 'dpi' in im.info else None,normalized_width=2550,normalized_height=round(2550*im.height/im.width))
 new.append(item)
missing=[dict(position=r['position_id'],period=r['period'],sha256=r['original_SHA256']) for r in new if r['source'] is None]
(OUT/'input_audit.json').write_text(json.dumps(dict(images=new,missing_source_files=missing,positions=positions,grouping='Six observation units per genotype, original tube/position retained; descriptive averaging only',calibration='Unresolved: embedded100dpi are export metadata',normalization='2550px complete width, aspect preserved; no physical conversion until calibration'),indent=2)+'\n')
print('IMAGES',len(rows),'FOUND',len(rows)-len(missing),'MISSING',json.dumps(missing),flush=True)
print('GENOTYPE_UNITS',Counter(p['position_id'].split('-')[0] for p in positions),flush=True)
