"""Apply the frozen temporal head and V90 modules to registered observation regions."""
import argparse,csv,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
import cv2,numpy as np
from PIL import Image
from skimage.morphology import skeletonize
import torch
R=Path('/workspace/LI');OUT=R/'results/all_genotype_root_quantification_20261030';HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'analysis-scripts'));from dataset_identity import require_active_position
sys.path.insert(0,'/workspace/Temporal-segmentation-model/03_temporal_V66/core')
from model import TemporalHead
import features
H,W=1108,2541

def js(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def positions(n,side,step):
 if n<=side:return [0]
 q=list(range(0,n-side+1,step))
 if q[-1]!=n-side:q.append(n-side)
 return q

def class_lengths(gate,classes):
 sk=skeletonize(gate);length=np.zeros(3,np.float64)
 for dy,dx in [(0,1),(1,0),(1,1),(1,-1)]:
  ys=slice(0,sk.shape[0]-dy) if dy else slice(None);yt=slice(dy,None) if dy else slice(None)
  if dx==1:xs,xt=slice(0,-1),slice(1,None)
  elif dx==-1:xs,xt=slice(1,None),slice(0,-1)
  else:xs,xt=slice(None),slice(None)
  use=sk[ys,xs]&sk[yt,xt]
  if dy and dx:
   if dx==1:use&=~(sk[:-1,1:]|sk[1:,:-1])
   else:use&=~(sk[:-1,:-1]|sk[1:,1:])
  a=classes[ys,xs][use];b=classes[yt,xt][use];assert np.isin(a,[1,2,3]).all() and np.isin(b,[1,2,3]).all()
  for c in [1,2,3]:length[c-1]+=.5*np.hypot(dx,dy)*((a==c).sum()+(b==c).sum())
 return length

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--positions',nargs='*');ap.add_argument('--max-units',type=int);a=ap.parse_args();torch.set_num_threads(2);torch.set_num_interop_threads(1);device=torch.device('cpu')
 checkpoint=Path('/workspace/Temporal-segmentation-model/03_temporal_V66/assets/weights/unet/best_temporal_head.pt');model=TemporalHead().to(memory_format=torch.channels_last);model.load_state_dict(torch.load(checkpoint,map_location='cpu',weights_only=True)['state_dict']);model.eval()
 audit=json.loads((OUT/'input_audit.json').read_text());bypos={}
 for r in audit['images']:bypos.setdefault(r['position_id'],[]).append(r)
 registry=json.loads((R/'roma-results/all-series-localization-v2/localization_registry.json').read_text());q=json.loads((R/'roma-results/0353-1/0353-1-Z2/root-guided-localization-v3/geometry_audit.json').read_text())
 registry['0353-1-Z2']=dict(position='Q1-1-Z2',periods=[1,2,3,4],regions=[dict(id='A',box=q['common_T1_box'],matrices=q['poses_T1_to_native'],review_required=True,source='Existing root-guided candidate; T2-to-T3 coarse unverified')])
 selected=list(bypos);selected.sort(key=lambda p:(p!='0353-2-B3',p))
 if a.positions:selected=[p for p in selected if p in a.positions]
 completed=0
 for pos in selected:
  require_active_position(pos);dest=OUT/'temporal'/pos;done=dest/'unit_complete.json'
  if done.exists():continue
  rows=sorted(bypos[pos],key=lambda r:r['period']);periods=[r['period'] for r in rows]
  if any(r['source'] is None or not (OUT/'binary'/pos/(r['period']+'_measurement.json')).exists() for r in rows):print('WAITING_SOURCE_OR_BINARY',pos,flush=True);continue
  entry=registry[rows[0]['legacy_source_id']];regions=entry['regions'];assert regions,pos
  images={};probs={};masks={};meta={}
  for r in rows:
   t=r['period'];images[t]=np.array(Image.open(r['source']['path']).convert('RGB'));probs[t]=np.load(OUT/'binary'/pos/(t+'_probability.npz'))['probability'].astype(np.float32);masks[t]=np.array(Image.open(OUT/'binary'/pos/(t+'_root_mask.png')))>0;meta[t]=r
  common_x0=max(v['box'][0] for v in regions);common_x1=min(v['box'][2] for v in regions);assert common_x1>common_x0;totals={t:np.zeros(3,np.float64) for t in periods[1:]};base_totals={t:np.zeros(3,np.float64) for t in periods[1:]};region_records=[]
  unit_start=time.monotonic();dest.mkdir(parents=True,exist_ok=True)
  for ri,region in enumerate(regions):
   box=[common_x0,region['box'][1],common_x1,region['box'][3]];x0,y0,x1,y1=box;rh,rw=y1-y0,x1-x0;yy,xx=np.mgrid[y0:y1,x0:x1].astype(np.float32);reg_rgb={};reg_p={};reg_m={};valid=np.ones((rh,rw),bool)
   for t in periods:
    mat=np.array(region['matrices'][t]);qx=mat[0,0]*xx+mat[0,1]*yy+mat[0,2];qy=mat[1,0]*xx+mat[1,1]*yy+mat[1,2];ih,iw=images[t].shape[:2];valid&=(qx>=0)&(qx<=iw-1)&(qy>=0)&(qy<=ih-1)
    reg_rgb[t]=cv2.remap(images[t],qx.astype(np.float32),qy.astype(np.float32),cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(255,255,255));nw,nh=meta[t]['normalized_width'],meta[t]['normalized_height'];mx=((qx+.5)*nw/iw-.5).astype(np.float32);my=((qy+.5)*nh/ih-.5).astype(np.float32)
    reg_p[t]=cv2.remap(probs[t],mx,my,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=0);reg_m[t]=cv2.remap(masks[t].astype(np.uint8),mx,my,cv2.INTER_NEAREST,borderMode=cv2.BORDER_CONSTANT,borderValue=0)>0
   for t in periods:reg_m[t]&=valid;reg_p[t][~valid]=0;reg_rgb[t][~valid]=255
   result={t:np.zeros((rh,rw),np.uint8) for t in periods};baseline={t:np.zeros((rh,rw),np.uint8) for t in periods};quality=np.full((rh,rw),-np.inf,np.float32)
   tile_indices=[(x,y) for y in positions(rh,H,H-128) for x in positions(rw,W,W-128)]
   for bi,(tx,ty) in enumerate(tile_indices):
    work=OUT/'work'/pos/(region['id']+'_'+str(bi));tile_done=work/'done.json';th,tw=min(H,rh-ty),min(W,rw-tx);s=np.s_[ty:ty+th,tx:tx+tw];payload={};tile_rgb={};tile_p={};tile_m={};tile_base={};tile_q={}
    for ti,t in enumerate(periods):
     rgb=np.full((H,W,3),255,np.uint8);rgb[:th,:tw]=reg_rgb[t][s];p=np.zeros((H,W),np.float32);p[:th,:tw]=reg_p[t][s];m=np.zeros((H,W),bool);m[:th,:tw]=reg_m[t][s];tile_rgb[t]=rgb;tile_p[t]=p;tile_m[t]=m
     if ti==0:q=np.full((3,H,W),1/3,np.float32);label=np.where(m,4,0).astype(np.uint8)
     else:
      prev=periods[ti-1];f=features.features(tile_rgb[prev],rgb,tile_p[prev],p,tile_m[prev],m).astype(np.float16);q=features.predict(model,f,device);del f;label=np.where(m,q.argmax(0)+1,0).astype(np.uint8)
     tile_base[t]=label;tile_q[t]=q;payload.update({t+'_RGB':rgb,t+'_root_probability':p.astype(np.float16),t+'_root_mask':m,t+'_temporal_probability':q.astype(np.float16),t+'_classes':label})
    work.mkdir(parents=True,exist_ok=True);np.savez_compressed(work/'input.npz',**payload);env=os.environ.copy();env['ROOT_REPRO_WORK']=str(work.resolve());env['ROOT_REPRO_PERIODS']=json.dumps(periods);env['ROOT_REPRO_POSITION']=pos
    print('TILE_START',pos,region['id'],bi+1,'/',len(tile_indices),periods,flush=True)
    with (work/'inference.log').open('a') as log:subprocess.run([sys.executable,str(HERE/'tile.py'),str(work)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    gy,gx=np.mgrid[:th,:tw];priority=np.minimum.reduce([gx+1,tw-gx,gy+1,th-gy]).astype(np.float32);take=priority>quality[s];quality[s][take]=priority[take]
    for t in periods:
     final=np.array(Image.open(work/'junction/full'/(t+'_classes.png')))[:th,:tw];result[t][s][take]=final[take];baseline[t][s][take]=tile_base[t][:th,:tw][take]
    # Intermediate graph/frame tensors are regenerated from released weights; retain final maps and audit only.
    keep=dest/'tile_audits'/(region['id']+'_'+str(bi));keep.mkdir(parents=True,exist_ok=True)
    for name in ['done.json','inference.log']:
     if (work/name).exists():shutil.copy2(work/name,keep/name)
    for name in ['consistency_verification.json','All_mixed_axis_decisions.csv']:
     if (work/'junction'/name).exists():shutil.copy2(work/'junction'/name,keep/name)
    shutil.rmtree(work)
   for t in periods:
    assert np.array_equal(result[t]>0,reg_m[t]);p=dest/'regions'/region['id'];p.mkdir(parents=True,exist_ok=True);Image.fromarray(result[t]).save(p/(t+'_classes.png'));Image.fromarray(baseline[t]).save(p/(t+'_baseline_classes.png'))
    pal=np.array([[255,255,255],[136,86,167],[0,158,115],[230,171,2],[0,114,178]],np.uint8);overlay=reg_rgb[t].copy();use=result[t]>0;overlay[use]=np.rint(.12*overlay[use]+.88*pal[result[t][use]]).astype(np.uint8);im=Image.fromarray(overlay);im.thumbnail((1100,1100));im.save(p/(t+'_overlay.jpg'),quality=92)
    if t!=periods[0]:totals[t]+=class_lengths(reg_m[t],result[t]);base_totals[t]+=class_lengths(reg_m[t],baseline[t])
   region_records.append(dict(region=region['id'],box_T1_xyxy=box,review_required=region['review_required'],valid_geometry_pixels=int(valid.sum()),tiles=len(tile_indices)))
  transitions=[]
  for a0,b0 in [('T1','T2'),('T2','T3'),('T3','T4')]:
   if a0 not in periods or b0 not in periods:transitions.append(dict(interval=a0+'-'+b0,status='missing_acquisition',lengths_px=None,rates_percent=None));continue
   v=totals[b0];total=float(v.sum());transitions.append(dict(interval=a0+'-'+b0,status='model_estimate_registration_review_required' if any(x['review_required'] for x in region_records) else 'model_estimate',lengths_px=dict(persistent=float(v[0]),new=float(v[1]),extension=float(v[2])),total_classified_root_length_px=total,rates_percent=dict(persistent=float(100*v[0]/total),new=float(100*v[1]/total),extension=float(100*v[2]/total)) if total>0 else None,baseline_lengths_px=base_totals[b0].tolist()))
  js(done,dict(genotype=pos.split('-')[0],observation_unit=pos,original_tube_id=rows[0]['tube_id'],periods=periods,regions=region_records,transitions=transitions,learned_ConvLSTM_GAT_applied=True,new_annotation_or_manual_ID_input=False,B3_manual_review_mask_applied=False,root_binary_model='V35 U-Net selected77',temporal_model='V66 head selected37 + frozen V90 local/joint/structural modules',reference_length_scale='T1 native pixels',seconds=time.monotonic()-unit_start));print('UNIT_DONE',pos,transitions,flush=True);completed+=1
  if a.max_units and completed>=a.max_units:break
 print('TEMPORAL_PASS_FINISHED',completed,flush=True)
if __name__=='__main__':main()
