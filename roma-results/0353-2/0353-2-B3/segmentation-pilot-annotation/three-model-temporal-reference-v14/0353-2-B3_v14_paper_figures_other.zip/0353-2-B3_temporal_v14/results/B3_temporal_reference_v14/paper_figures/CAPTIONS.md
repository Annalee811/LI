# Temporal reference v14 figure descriptions

All panels show 0353-2-B3, upper region only. Blue: T1 baseline; purple: persistent segment; green: newly observed root/side root; gold: tip growth. T2–T4 are each relative to the immediately previous period. No death classification is made. Root identity at crossings and occlusions is not independently established.

- Fig1: Four-period native RGB, original user labels, U-Net-derived reference, and the three two-stage model outputs. Yellow boxes locate the common zoom. Full images include fitting pixels and are qualitative.
- Fig2: The same comparisons in the fixed 600×600 native-pixel zoom; resizing for publication does not create additional biological detail.
- Fig3 / Fig4: Temporal classes with the background removed, complete upper region / common local window. Raw RGB-only root cutouts are also in each model result package.
- Fig5: Three temporal class Dice values on the 18 internal tile/date pairs, reported against both references. T1 is excluded from macro Dice. Revised-reference scores quantify agreement with the U-Net teacher, not independent manual accuracy.
- S1: Actual 24-epoch training objectives and measured validation macro Dice. Validation was evaluated every four epochs; points are connected without curve fitting. Decoder calibration occurs after these recorded trajectories.
- S2: Class Dice for T1→T2, T2→T3 and T3→T4 against the revised reference, pooling confusion counts within each transition rather than averaging ratios.
- S3: Skeleton pixel-count agreement for all typed roots, separately against original and revised references. Dashed line: identity. Solid line: OLS fit. Identity R², OLS R² and RMSE are distinct. There are no independent manual physical-length measurements.
- S4: Row-normalized four-class confusion matrices against the revised reference, including background errors from the frozen root detectors.
- S5: One-vs-rest class error maps on the test example containing the most revised-reference growth pixels. Green: true positive; pink: false positive; orange: false negative. Selection uses only reference content, not model performance.

These are same-position development results. The teacher previously used all upper-region human labels; historical warm starts may also have seen pixels under earlier splits. No independent external test image is available. Do not describe the results as an unbiased cross-tube test or biological root-identity validation.
