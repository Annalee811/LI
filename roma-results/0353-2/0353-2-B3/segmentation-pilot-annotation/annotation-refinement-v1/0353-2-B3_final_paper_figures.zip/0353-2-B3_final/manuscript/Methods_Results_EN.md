# Final three-model results against revised root references

## Methods

Only the four human-annotated upper RGB fields of0353-2-B3(2541x1108px)were used. The preceding fixed random allocation of36native256px base positions into25training,5validation and6internal-test positions was retained. Each training position received a second native256px view translated12px in x/y, inward at boundaries, yielding200training views,20validation and24internal-test images. All four dates at one coordinate share one split. Added windows exclude every held-out pixel; within-train views overlap and are not independent acquisitions. No easy-tile/root-density filtering was used.

Original human strokes were retained separately. Revised binary references supplement narrow/missing strokes using previous U-Net probability, bright tubular RGB support and elongated-component constraints. These are model-assisted revised references, not new independent human ground truth. Original RGB pixels and colors remain unchanged; annotations/visualizations are separate files. No temporal or death classifier is fitted here.

All three previous matching models were fine-tuned for20epochs,64augmented draws/epoch,batch2,initialLR0.00008. The models are ResNet18U-Net,the supplied original TensorFlow1.12ResNet-v2-50DeepLabV3+,andSegFormer-B0with nativeRGB refinement. Epoch0can be retained. Checkpoints and thresholds were selected using ORIGINAL validation labels, not the revised reporting references. Original retained-mask metrics remain in the audit table.

The requested final figures compare only these final trained models with revised references. Precision/Recall/Dice/IoU are revised-reference AGREEMENT, pooled over the24internal-test tile-date views. They are not independent manual accuracy. Root-length references are skeletons derived from revised masks, in pixels; they are not independent manual measurements. The teacher-influenced reference can favor U-Net. External independently annotated test images:0.

## Revised-reference internal-test agreement

|Model|Precision|Recall|Dice|IoU|
|---|---:|---:|---:|---:|
|U-Net|0.9448|0.8316|0.8846|0.7931|
|DeepLabV3+|0.7847|0.6882|0.7333|0.5789|
|SegFormer-B0|0.8132|0.6549|0.7255|0.5693|

Whole-upper images include fitted pixels and are qualitative. No inference dilation, root reconnection or test-chosen cleanup is applied. ForegroundRGB and black-root background-removed versions are both supplied.
