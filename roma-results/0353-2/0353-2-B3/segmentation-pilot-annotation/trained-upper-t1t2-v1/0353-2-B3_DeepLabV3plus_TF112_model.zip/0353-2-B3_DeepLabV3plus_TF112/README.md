# 上传的 TensorFlow DeepLabV3+：兼容环境与权重

本目录保留用户上传的原始仓库代码及MIT许可证。实际调用原始网络生成器，使用其支持的ResNet-v2-50、输出步幅16、256通道ASPP和原始解码器。类别数设为背景/根两类；没有替换成另一框架模型。

唯一源代码修改：未提供ImageNet预训练权重时，跳过原代码无条件的预训练检查点加载。网络结构不变。训练从随机初始化开始，BatchNorm衰减参数设置为0.90以适应小样本；归一化、标注、空间划分、主要增强与U-Net一致。优化器、学习率及训练预算详见config.json；这是首轮试训而非控制全部超参数的最终模型排名。

原始TensorFlow 1.12在Python3.5容器运行。为了CPU速度，使用PyPI官方intel-tensorflow==1.12.0构建，仍是TF1.12及同一网络。

权重：training/best_weights_fp16.npz。全部模型变量名在training/weight_names.json中；权重以FP16存储，载入TF原生FP32变量后再选阈值、评估与推理。不是空白或模拟权重。

推理（容器内示意，目录路径按实际解压位置调整）：

```bash
python source/infer_uploaded_deeplab_tf1.py --model-dir . --images RGB目录 --output predictions_new
```

重新训练需要数据与结果压缩包中的dataset目录，固定使用其manifest，不重新随机分组：

```bash
python source/train_uploaded_deeplab_tf1.py --dataset-run 数据与结果解压目录 --output training_new --vendor vendor --batch 4 --epochs 40 --patience 10
```

CPU优化构建Dockerfile及官方wheel校验值已保留。wheel只在构建时下载，避免将旧环境的大型二进制依赖塞入结果包。原始仓库README里的Pascal VOC成绩不适用于本次根系数据；本次真实指标仅见metrics.json和综合结果说明。

可在安装Docker的主机上运行 `python source/prepare_deeplab_runtime.py --context tf112_build --build`，自动下载并核验同版本官方wheel并构建CPU运行镜像。
