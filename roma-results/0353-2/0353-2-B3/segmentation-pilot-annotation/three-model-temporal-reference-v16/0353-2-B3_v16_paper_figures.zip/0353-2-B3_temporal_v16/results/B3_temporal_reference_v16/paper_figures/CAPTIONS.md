# U-Net-reference / whole-axis v16 figure descriptions

All panels show 0353-2-B3, upper region only. Blue: T1 baseline; purple: persistent segment; green: newly observed root/side root; gold: tip growth. T2–T4 are each relative to the immediately previous period. No death classification is made. Root identity at crossings and occlusions is not independently established.

- Integrated TIFF: Four-date 72-panel atlas of original RGB, U-Net-derived reference and all three outputs, with full/local overlays and background-removed temporal roots. Original RGB controls have the matching ROI boxes. See figure_protocol.json for the exact ROI and layout.
- Fig3 / Fig4: Temporal classes with the background removed, complete upper region / common local window. Raw RGB-only root cutouts are also in each model result package.
- Fig5: Three temporal class Dice values on the 18 internal tile/date pairs, reported against both references. T1 is excluded from macro Dice. Original human classes are retained separately; both morphology and temporal classes derive from the latest U-Net output.
- S1: Actual 24-epoch training objectives and measured validation macro Dice. Validation whole-axis outputs were evaluated at epoch zero and every four epochs; points are connected without curve fitting. Decoder calibration occurs after these recorded trajectories.
- S2: Class Dice for T1→T2, T2→T3 and T3→T4 against the revised reference, pooling confusion counts within each transition rather than averaging ratios.
- S3: Skeleton pixel-count agreement for all typed roots, separately against original and revised references. Dashed line: identity. Solid line: OLS fit. Identity R², OLS R² and RMSE are distinct. There are no independent manual physical-length measurements.
- S6: Row-normalized four-class confusion matrices against the revised reference, including background errors from the frozen root detectors.
- S5: One-vs-rest class error maps on the test example containing the most revised-reference growth pixels. Green: true positive; pink: false positive; orange: false negative. Selection uses only reference content, not model performance.

The revised reference includes both temporal classes and morphology from the starting v15 U-Net. U-Net agreement with its own reference is circular, not independent accuracy. Original human labels remain separate. These are same-position development results. The frozen root models and historical warm starts have prior same-field exposure. Whole-axis decoding also uses full-image prediction context across tile boundaries. No independent external test image is available. Do not describe the results as an unbiased cross-tube test or biological root-identity validation.

- Fig6: Original RGB, candidate root axes and final U-Net temporal output in the fixed local window. The longest six visible axes per period are colored; other routes are gray. Local axis numbers do not establish biological identity across dates. Double arrows show orientation, not growth polarity. Orange circles mark up to eight unresolved local crossings.
- S4 test-pair heterogeneity: All18same-field test pairs retained, grouped by model and colored by transition. MacroDice excludes undefined classes with no TP/FP/FN; dates at the same six locations are correlated, not independent plants.
- The confusion matrix is S6. The active decoder allows an all-growth continuation trace only when its endpoint extends outward from a real previous predicted root tip with matching direction and learned growth evidence; a lateral born on a prior shaft cannot use this exception.
