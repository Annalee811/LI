# 0353-2-B3 待人工标注图包

先阅读 annotation_protocol.md。解压后打开 annotate.html，选择 images 文件夹。原色图60张；训练36、验证12、空间留出测试12。当前没有人工真值、没有真实模型训练或指标。包含褐变、时序和疑似/确认死亡的可选独立属性；可见死亡根仍标为根系。图块来自同一位置，留出测试不代表不同位置独立测试。标注完成导出各图ZIP并解压到 labels。根长独立人工测量填写 manual_lengths.csv，缺少标尺先用T1像素。

RootPainter、U-Net、DeepLabV3+的实际比较需人工标注后开展。软件测试通过不代表已经取得本实验Dice或R²。
