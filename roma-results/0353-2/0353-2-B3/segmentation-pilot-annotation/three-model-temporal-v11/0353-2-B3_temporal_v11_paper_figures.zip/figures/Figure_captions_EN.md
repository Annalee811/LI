Fig1_four_period_three_model_final_fit: Final deployment heads fitted using all B3 upper annotations. These panels show fitted-position behavior, not held-out accuracy. Root support is exactly frozen v9 segmentation. T1 is baseline; T2/T3/T4 refer only to the immediately previous date. Missing root visibility does not establish death.

Fig2_spatial_validation_T2: C3 spatial validation visualization using evaluation heads fitted on C0–C2. C3 was used for checkpoint and class calibration selection. Unlabelled temporal root pixels are gray in human reference. Regions/date are shared across all model panels; this is not an external tube test.

Fig3_class_metrics_validation: Per-class strict native-pixel temporal metrics, including errors from frozen root detection. Fixed0–1 axes. No external independent labelled test images. C4 is a previously inspected same-position benchmark, not a fresh independent test.

Fig3_class_metrics_repeated_benchmark: Per-class strict native-pixel temporal metrics, including errors from frozen root detection. Fixed0–1 axes. No external independent labelled test images. C4 is a previously inspected same-position benchmark, not a fresh independent test.

Fig4_temporal_training_records: Actual three-head continuation records using frozen inherited v10 class multipliers. Dotted line marks the retained epoch0 baseline. Solid validation curves include missed/false roots; dashed curves measure classification only on correctly detected reference roots. Curves precede the subsequent C3-only pair-confusion decision calibration; final tables include it. All backbones and root masks remained frozen. Separate all-label final refits are in final_history.csv.

Fig5_validation_confusion: Row-normalized C3 end-to-end confusion matrices. Predicted background on a reference root is a miss; a background pixel assigned a root class is a false positive. Untyped root reference pixels are excluded.

Fig6_length_agreement_validation: All three models, total-root and class-specific length agreement. R²=1−SSE/SST relative to the identity line; negative values retained. Total-root length uses frozen v9 masks. References derive from human mask skeletons, not separate root-length measurements. Eight correlated spatial blocks repeated across dates;32 total-root pairs or24 class-date pairs; no biological independence or significance claim.

Fig6_length_agreement_repeated_benchmark: All three models, total-root and class-specific length agreement. R²=1−SSE/SST relative to the identity line; negative values retained. Total-root length uses frozen v9 masks. References derive from human mask skeletons, not separate root-length measurements. Eight correlated spatial blocks repeated across dates;32 total-root pairs or24 class-date pairs; no biological independence or significance claim.

Fig7_all_transitions_validation: All three adjacent transitions on the same C3 validation column. All predictions use previous and current predicted-root-only inputs; no preceding manual root masks at inference.

Fig8_validation_error_localization: Same C3/T2 field for all three models; green means correct temporal root class, vermilion means missed reference root, magenta means root detected but assigned wrong temporal class, blue means background classified as a root, and gray marks excluded temporal reference pixels. White is correctly predicted background. Native error maps for every scored transition are retained.

Fig9_before_after_validation: Same reference and frozen first-stage root masks for both versions. All three classes and all three models are shown, globally, within12px of a diagonal-corrected skeleton junction and within20px of a previous predicted tip. Fixed0–1 scales; reduced scores are retained. C3 selects checkpoints; C4 is a repeated same-position benchmark. Neither is an independent tube test.

Fig9_before_after_repeated_benchmark: Same reference and frozen first-stage root masks for both versions. All three classes and all three models are shown, globally, within12px of a diagonal-corrected skeleton junction and within20px of a previous predicted tip. Fixed0–1 scales; reduced scores are retained. C3 selects checkpoints; C4 is a repeated same-position benchmark. Neither is an independent tube test.

Fig10_fixed_junction_region: Same native256px C3 T2 region for all models and both versions. ROI chosen by maximum old-v10 U-Net error density only, before inspecting v11 output; coordinates and selection rule saved. These panels are error analysis, not an independent performance estimate. Persistent purple, new green, growth gold; excluded reference gray.
