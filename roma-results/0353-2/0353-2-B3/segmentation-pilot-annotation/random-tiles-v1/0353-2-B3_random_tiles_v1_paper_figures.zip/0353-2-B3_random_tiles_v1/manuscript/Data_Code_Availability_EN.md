Data and code availability

The annotated upper-field RGB images, unchanged human root masks, original annotation-progress JSON, fixed random tile allocation, trained model weights, prediction masks, evaluation tables and complete analysis scripts are available in Annalee811/LI, registration-results branch, under roma-results/0353-2/0353-2-B3/segmentation-pilot-annotation/random-tiles-v1. The immutable data commit and full-download SHA256 verification are recorded in public_download_verification.json; the individual ZIP checksums are listed in SHA256.json. The experiment uses four registered images from one annotated position; no independent external-position or external-tube test set is included.

Repository: https://github.com/Annalee811/LI
Before submission, insert the immutable data commit from the verification file into the citation. If the journal requires a DOI-bearing archive, deposit this fixed version in an appropriate long-term repository and cite its actual assigned DOI. Data ownership and licensing must be confirmed by the authors; no license or DOI is invented here.
