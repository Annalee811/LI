"""Package selected-position results without unrelated raw locations or weights."""
from pathlib import Path
import hashlib
import json
from zipfile import ZipFile, ZIP_STORED, ZIP_DEFLATED

root=Path(__file__).resolve().parent
validation=json.loads((root/'validation.json').read_text())
assert len(validation)==7 and all(x['status'].startswith('PASS') for x in validation)
rows=json.loads((root/'0353-2-B3/summary.json').read_text())
lines=['# 0353-2-B3 结果汇总','',
       '| 配准 | 可靠采样匹配/5000 | 有效面积 | 有效区域循环误差 P95（目标像素） |',
       '|---|---:|---:|---:|']
for m in sorted(rows,key=lambda x:(x['kind']=='cumulative',x['pair'])):
    n=m['reliable_sampled_matches'];e=m.get('cycle_error_effective_target_px',{}).get('p95')
    match=f'{n}/5000' if n is not None else '累计，无新匹配'
    error=f'{e:.3f}' if e is not None else '—'
    lines.append(f"| {m['pair']} | {match} | {100*m['effective_area_ratio']:.2f}% | {error} |")
lines+=['','T2→T3 使用相同图像的可靠匹配估计视野位移，进行推理用预对齐后重新运行稠密 RoMa。',
        '有效面积分母为后一期完整画布；双向置信度≥0.5，循环误差≤3目标像素，并排除局部翻折。',
        '累计 T1→T4 共同可靠区域较小，不能将全图变形用于根系变化定量。',
        '循环误差和置信度为内部一致性指标，未以人工标注真值验证，不能当作实际配准精度。',
        '无颜色校正，无裁剪；最终 RGB 从原始来源图像直接进行一次双线性重采样。',
        'T4 输出保持 5100×4547；T2/T3 输出保持 1327×1185、1330×1183。',
        '本轮仅运行 0353-2-B3，其他 18 个位置未运行。']
(root/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
shared=['README.md','RESULTS.md','register_roma.py','make_report.py','check_orientation.py',
        'package_results.py','prealign.json','batch_inventory.json','orientation_diagnostic.json',
        'orientation_check.jpg','0353-2-B3_preview.jpg','validation.json']
files=[root/p for p in shared]
files+=list((root/'0353-2-B3').rglob('*'))
files+=list((root/'input/raw/V-变化/0353-2-B3').iterdir())
files+=[root/'initial_without_prealignment/T2_to_T3'/p for p in ['metrics.json','sampled_matches.npz']]
full=root.parent/'0353-2-B3_RoMa_complete.zip'
with ZipFile(full,'w',compression=ZIP_STORED,allowZip64=True) as z:
    for p in files:
        if p.is_file():z.write(p,Path('microtube_registration')/p.relative_to(root))
with ZipFile(full) as z:
    assert z.testzip() is None
    assert sum(x.filename.endswith('dense_transform.npz') for x in z.infolist())==5
quick=root.parent/'0353-2-B3_RoMa_preview.zip'
with ZipFile(quick,'w',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for p in [root/n for n in shared]+list((root/'0353-2-B3').glob('*/metrics.json'))+[root/'0353-2-B3/summary.csv',root/'0353-2-B3/summary.json',root/'0353-2-B3/manifest.json']:
        z.write(p,p.relative_to(root))
with ZipFile(quick) as z:assert z.testzip() is None
digests={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in [full,quick]}
(root/'archive_sha256.json').write_text(json.dumps(digests,indent=2))
for p in [full,quick]:print(p,p.stat().st_size,'bytes')
print((root/'RESULTS.md').read_text())
