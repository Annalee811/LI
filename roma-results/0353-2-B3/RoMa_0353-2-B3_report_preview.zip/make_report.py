"""Validate saved outputs and build full-canvas/reliable diagnostic previews."""
import json
import hashlib
import sys
from pathlib import Path
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont
from register_roma import rgb, remap, inside, jacobian

root=Path(__file__).resolve().parent
result=root/'0353-2-B3'
manifest=json.loads((result/'manifest.json').read_text())
for filename,digest in manifest['input_sha256'].items():
    assert hashlib.file_digest(Path(filename).open('rb'),'sha256').hexdigest()==digest
rows=json.loads((result/'summary.json').read_text())
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
cellw,cellh=280,300
canvas=Image.new('RGB',(7*cellw,len(rows)*cellh),'white')
draw=ImageDraw.Draw(canvas)
checks=[]
for j,m in enumerate(rows):
    folder=result/m['pair']
    source=rgb(m['source_file']);target=rgb(m['target_file'])
    registered=rgb(folder/'registered_rgb.png')
    h,w=target.shape[:2]
    assert registered.shape==target.shape
    mask=np.array(Image.open(folder/'valid_overlap_mask.png'))>0
    geometric=np.array(Image.open(folder/'geometric_overlap_mask.png'))>0
    confidence=np.load(folder/'confidence_float32.npy')
    assert mask.shape==confidence.shape==(h,w)
    assert np.isfinite(confidence).all() and confidence.min()>=0 and confidence.max()<=1
    quantized=np.array(Image.open(folder/'confidence_16bit.png')).astype(np.float32)/65535
    assert np.max(np.abs(quantized-confidence)) <= 1/65535
    with np.load(folder/'dense_transform.npz') as fields:
        backward=fields['target_to_source_xy_px']
        np.testing.assert_array_equal(fields['valid_target'],mask)
        expected=remap(source,backward)
        expected[~inside(backward,(source.shape[1],source.shape[0]))]=0
        np.testing.assert_array_equal(registered,expected)
    del source,expected,backward
    assert abs(float(mask.mean())-m['effective_area_ratio'])<1e-10
    assert (confidence[mask]>=m['confidence_threshold']-1e-6).all()
    # Regenerate both views also for adjacent results reused from first pass.
    if '--skip-regenerate' not in sys.argv:
        overlay=target.copy()
        overlay[geometric]=np.rint((registered[geometric].astype(np.float32)+target[geometric])/2).astype(np.uint8)
        Image.fromarray(overlay).save(folder/'overlay_50pct.png')
        reliable=target.copy();reliable[mask]=overlay[mask]
        Image.fromarray(reliable).save(folder/'overlay_50pct_reliable.png')
        y,x=np.ogrid[:h,:w]
        tiles=(x//m['checker_tile_px']+y//m['checker_tile_px'])%2==0
        checker=target.copy();checker[tiles&geometric]=registered[tiles&geometric]
        Image.fromarray(checker).save(folder/'checkerboard.png')
        checker=target.copy();checker[tiles&mask]=registered[tiles&mask]
        Image.fromarray(checker).save(folder/'checkerboard_reliable.png')
    files=[Path(m['target_file']),folder/'registered_rgb.png',folder/'overlay_50pct.png',folder/'checkerboard.png',folder/'confidence_preview.png',folder/'valid_overlap_mask.png',folder/'dense_transform_preview.png']
    labels=['Original target RGB','Registered source RGB','50% overlay (full)','Checkerboard (full)','RoMa confidence','Reliable overlap mask','Dense field preview']
    title=f"{m['pair']} | reliable area {100*m['effective_area_ratio']:.2f}% | {w} x {h}"
    draw.text((5,j*cellh+3),title,fill='black',font=font)
    for i,(p,label) in enumerate(zip(files,labels)):
        im=Image.open(p).convert('RGB');im.thumbnail((cellw-8,cellh-55))
        canvas.paste(im,(i*cellw+4,j*cellh+48))
        draw.text((i*cellw+4,j*cellh+26),label,fill='black',font=font)
    checks.append({'pair':m['pair'],'size_wh':[w,h],'status':'PASS: original hashes, dimensions, saved RGB equals original-source pullback, field/mask agreement, confidence range and 16-bit precision'})
for previous,adjacent,cumulative in [
    ('T1_to_T2','T2_to_T3','T1_to_T3_cumulative'),
    ('T1_to_T3_cumulative','T3_to_T4','T1_to_T4_cumulative')]:
    with np.load(result/previous/'dense_transform.npz') as f:
        bp,cp,vp=f['target_to_source_xy_px'],f['confidence_target'],f['valid_target']
    with np.load(result/adjacent/'dense_transform.npz') as f:
        ba,ca,va=f['target_to_source_xy_px'],f['confidence_target'],f['valid_target']
    with np.load(result/cumulative/'dense_transform.npz') as f:
        bc,cc,vc=f['target_to_source_xy_px'],f['confidence_target'],f['valid_target']
        source_size=tuple(f['source_size_wh'])
    expected=remap(bp,ba,border=-1)
    assert float(np.max(np.abs(expected-bc)))<1e-5
    assert float(np.max(np.abs(np.minimum(ca,remap(cp,ba))-cc)))<1e-6
    expected_mask=(va & inside(ba,(bp.shape[1],bp.shape[0])) &
                   (remap(vp.astype(np.uint8),ba,nearest=True)>0) &
                   inside(bc,source_size) & (jacobian(bc)>0) & (cc>=.5))
    np.testing.assert_array_equal(vc,expected_mask)
    checks.append({'pair':cumulative,'status':'PASS: exact adjacent pullback composition, path-minimum confidence and propagated reliability mask'})
    del bp,cp,vp,ba,ca,va,bc,cc,vc,expected,expected_mask
canvas.save(root/'0353-2-B3_preview.jpg',quality=95)
(root/'validation.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print(json.dumps(checks,ensure_ascii=False,indent=2))
