"""Diagnostic only: compare orthogonal source orientations at 280/448.
No candidate is silently substituted into the main registration outputs.
"""
from pathlib import Path
import json
import numpy as np
import cv2
import torch
from PIL import Image
from register_roma import pixel_map, inside, remap, grid, jacobian
from romatch import roma_outdoor

torch.set_num_threads(4)
torch.set_float32_matmul_precision('highest')
device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
root=Path(__file__).resolve().parent
raw=root/'input/raw/V-变化/0353-2-B3'
model=roma_outdoor(device=device,coarse_res=280,upsample_res=448,symmetric=True,use_custom_corr=False)
a=np.array(Image.open(raw/'T2.png'))
b=Image.open(raw/'T3.png')
rows=[]
for k in range(4):
    rotated=Image.fromarray(np.rot90(a,k).copy())
    with torch.inference_mode():w,c=model.match(rotated,b,device=device)
    w=w[0].cpu().numpy();c=c[0].cpu().numpy();mid=w.shape[1]//2
    fw=pixel_map(w[:,:mid,2:],b.size,rotated.size)
    bw=pixel_map(w[:,mid:,:2],rotated.size,b.size)
    cf=cv2.resize(c[:,:mid],rotated.size)
    cb=cv2.resize(c[:,mid:],b.size)
    cycle=np.linalg.norm(remap(fw,bw,border=-1)-grid(b.size[1],b.size[0]),axis=-1)
    v=inside(bw,rotated.size)&(cb>=.5)&(remap(cf,bw)>=.5)&(cycle<=3)&(jacobian(bw)>0)
    rows.append({'source_ccw_degrees':90*k,'effective_area_ratio':float(v.mean()),'confidence_mean':float(cb.mean()),
                 'resolution':'280/448','note':'Diagnostic internal consistency; no independent ground truth.'})
    print(rows[-1],flush=True)
(root/'orientation_diagnostic.json').write_text(json.dumps(rows,indent=2))
