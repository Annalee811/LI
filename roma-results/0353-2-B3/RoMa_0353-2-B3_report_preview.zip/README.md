# 0353-2-B3 四期微根管 RGB 配准

数据来源：<https://github.com/Annalee811/LI/releases/tag/v-change-data>。
Release 附件 `V-.zip` 的 SHA256 已与 GitHub 提供的摘要核对：
`98c7aa632d160f7f89714da9f68d71dddc7f28c951102dac46d8a80951ff99d2`。
本次仅处理 `0353-2-B3`，其余位置在 `batch_inventory.json` 中记录。

## 运行

在 `/workspace/LI` 使用已安装的虚拟环境：

```bash
PYTHONPATH=/workspace/LI .venv/bin/python results/microtube_registration/register_roma.py --self-test
PYTHONPATH=/workspace/LI .venv/bin/python results/microtube_registration/register_roma.py \
  --input-dir 'results/microtube_registration/input/raw/V-变化/0353-2-B3' \
  --output-dir results/microtube_registration/0353-2-B3 \
  --prealign-json results/microtube_registration/prealign.json
PYTHONPATH=/workspace/LI .venv/bin/python results/microtube_registration/make_report.py
```

脚本自动检测 CUDA，无 CUDA 时使用 CPU。使用完整 `roma_outdoor` 权重，
双向匹配，coarse=560，upsample=864，原生 PyTorch 局部相关计算。
模型内部缩放与标准化仅用于推理；最终 RGB 从原始文件直接进行双线性重采样，
没有颜色校正、对比度增强、裁剪或目标画布缩放，也不进行 EXIF 自动旋转。
几何重采样必然插值，因此配准后的 RGB 像素数值并非逐像素复制原图。

### T2→T3 的视野移动与修正

原始直接 RoMa 结果只有 124/5000 个可靠采样匹配、1.73% 有效面积。
90°/180°/270° 方向假设的低分辨率诊断均没有可靠重叠，未采用旋转。
初始可靠对应点的 RANSAC 表明 T2→T3 主要沿竖直方向移动约 -721 像素。
最终对 T2 使用该单应性做**推理用**几何预对齐，再运行完整 RoMa 双向稠密匹配。
最终变换为 RoMa 残差映射与预对齐矩阵的复合，不是仅输出全局单应性。
最终 RGB 直接采样原始 T2，只有一次输出重采样。
没有修改目标图、放宽置信度/循环阈值或填充缺失视野。
该估计使用相同图像的内部匹配，不是外部独立配准真值。

`prealign.json` 保存完整矩阵；初始匹配和度量保存在
`initial_without_prealignment/T2_to_T3/`，可与最终结果比较。
可选 `--reuse-adjacent` 重用相同设置的其他相邻配准，但重新计算指定预对齐组。
`roma_raw_normalized.npz` 的坐标属于模型实际推理输入，T2→T3 的推理输入是
预对齐后的 T2；其中保存了 `inference_source_size_wh` 和
`prealignment_source_to_inference`。最终 `dense_transform.npz` 和
`sampled_matches.npz` 的坐标均已还原到**原始 T2/T3 像素坐标**。

## 输出方向和尺寸

| 目录 | 原始 RGB 来源 | 输出坐标系/尺寸（宽×高） |
|---|---|---|
| T1_to_T2 | T1 | T2，1327×1185 |
| T2_to_T3 | T2 | T3，1330×1183 |
| T3_to_T4 | T3 | T4，5100×4547 |
| T1_to_T3_cumulative | T1 | T3，1330×1183 |
| T1_to_T4_cumulative | T1 | T4，5100×4547 |

以 T1 为累计参考，但所有输出仍位于指定后一期的坐标系，并不是把所有后期图像
扭回 T1 画布。累计映射由相邻映射复合而来，直接对原始 T1 采样一次，
避免逐次重采样 RGB。累计结果会积累映射误差；没有进行额外 T1–T3/T4 直接推理。

每组结果：

- `registered_rgb.png`：前一期原始 RGB 在后一期画布上的配准结果。
  无来源的像素为黑色；低置信区域不伪造填充，使用掩膜决定可用范围。
- `dense_transform.npz`：float32 像素坐标映射，`target_to_source_xy_px`
  为 `(目标高,目标宽,2)`，每个目标像素记录应采样的原图 `(x,y)`。
  相邻配准还含 `source_to_target_xy_px`，位于原图原始网格。
  坐标为零起始像素中心，使用 RoMa 的 `align_corners=False` 转换。
  该映射不是直接相加的位移；不同原图尺寸时尤其不能把两者混淆。
- `dense_transform_preview.png`：相对于尺寸缩放基准的后向位移 HSV 可视化，
  色相表示方向，明度表示大小，99 分位截断仅用于可视化。
- `confidence_float32.npy` / `confidence_16bit.png`：目标网格置信度。
  16 位图除以 65535 对应 0–1；`confidence_preview.png` 为 8 位浏览图。
  相邻结果是 RoMa 输出插值，累计置信度为路径上各段最小值，不是额外预测。
- `overlay_50pct.png`：几何重叠范围内配准 RGB 与目标 RGB 各占 50%，
  范围外显示完整目标 RGB；包括低置信区域以便审查失败变形。
- `checkerboard.png`：128 像素棋盘格，几何重叠范围内交替显示配准 RGB 和目标 RGB。
  另提供 `overlay_50pct_reliable.png`、`checkerboard_reliable.png`，
  仅在严格有效掩膜内混合/替换，其余显示目标 RGB。
- `valid_overlap_mask.png`：255 可用、0 不可用。
- `geometric_overlap_mask.png`：仅检查来源坐标是否落在原图内的宽松几何掩膜。
- `metrics.json`：面积、置信度、匹配数及质量诊断；总表为 `summary.csv/json`。
- 相邻配准另保存 `roma_raw_normalized.npz` 和 `sampled_matches.npz`。

## 有效区域与质量含义

默认有效区域须同时满足：来源在原图边界内、双向置信度均 ≥0.5、
前后向循环误差 ≤3 个目标原始像素、后向映射的局部 Jacobian 行列式 >0。
累计掩膜为沿路径各段有效掩膜交集，并检查累计来源坐标及局部翻折。
有效面积比例的分母是**完整后一期画布面积**，不是裁剪后的 ROI。
T4 原始像素尺寸较大，同样 3 像素阈值更严格。

每组采样 5000 个 RoMa 对应点；可靠匹配数额外要求原始双向置信度及循环一致性。
采样值不代表独立特征数量，RoMa 稠密像素数另行报告。
最终采样点的全局单应性 RANSAC 用于诊断；初始 T2→T3 的矩阵用于
上述推理预对齐。两者都没有取代实际输出的 RoMa 稠密变换。
累计配准没有新采样对应点，表中匹配数量为空。

NCC、梯度 NCC、置信度及循环一致性均不是有真值验证的配准精度。
跨时期根系生长、消失、土壤遮挡和 RGB 光照差异会影响光度指标；
循环一致性也可能在双向都错误时通过。应结合叠加图、棋盘格和掩膜审阅，
不能将低置信或掩膜外的变形作为根系变化证据。

## 后续批处理规则

19 个位置已检查：18 个具有至少三期，`Q1-1-B3` 只有 T3/T4，跳过。
未来批处理按实际存在的时期顺序处理，例如缺 T3 时为 T1→T2→T4，
必须注明跨期，不能虚构缺失图像或匹配。本次未批量运行其余位置。
