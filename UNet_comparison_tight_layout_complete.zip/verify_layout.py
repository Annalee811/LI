from pathlib import Path
import json,csv,hashlib
import numpy as np
from PIL import Image
import fitz

r=Path(__file__).resolve().parent
verification=json.loads((r/'source_verification.json').read_text())
for entry in verification['checks']:assert hashlib.sha256((r/entry['file']).read_bytes()).hexdigest()==entry['sha256']
source=json.loads((r/'source_comparison.json').read_text());rows=list(csv.DictReader((r/'radial_metrics.csv').open(encoding='utf-8-sig')));assert len(rows)==24
for row in rows:
 original=next(q for q in source['classes'] if q['class_en']==row['Root_class']);prefix='V66' if row['Source_workflow']=='V66 U-Net' else 'V90'
 assert float(row['Score_percent'])==100*original[prefix+'_'+row['Metric']]
for t in ['T1','T2','T3','T4']:
 raw=np.array(Image.open(r/f'sources/RGB/{t}_RGB.png').convert('RGB'))[590:850,1530:1830]
 assert np.array_equal(raw,np.array(Image.open(r/f'exact_crops/{t}/Original_RGB.png')))
 for group in ['reference','V66','V90']:
  expected=np.array(Image.open(r/f'sources/{group}/{t}_classes.png'))[590:850,1530:1830]
  assert np.array_equal(expected,np.array(Image.open(r/f'exact_crops/{t}/{group}_classes.png')))
  assert np.any((expected>0)&(expected<255))
d=fitz.open(r/'UNet_comparison_tight_layout.pdf');assert len(d)==1
p=d[0];spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()]
assert all(s['color']==0 and p.rect.contains(fitz.Rect(s['bbox'])) for s in spans)
assert all(s['font'] in ['TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'] for s in spans)
assert min(s['size'] for s in spans)>=7.99
for macro in [s for s in spans if s['text'].startswith('Macro Dice')]:
 assert all(not fitz.Rect(macro['bbox']).intersects(fitz.Rect(q['bbox'])) for q in spans if q['text'] in ['Precision','Recall','Dice','IoU'])
images={}
for ext in ['jpg','png','tiff']:
 im=Image.open(r/f'UNet_comparison_tight_layout.{ext}');assert im.size==(4500,5811)
 assert all(abs(float(v)-600)<.1 for v in im.info['dpi']);images[ext]={'size':im.size,'dpi':[float(v) for v in im.info['dpi']]}
report={'source_assets_verified':len(verification['checks']),'pooled_metric_values_checked':24,'four_periods_preserved':True,'original_RGB_and_class_crop_arrays_unchanged':True,'pixel_ROI':[1530,590,1830,850],'image_matrix_column_gap_mm':2,'image_matrix_row_gap_mm':1,'figure_mm':[190.5,246],'font_range_pt':[min(s['size'] for s in spans),max(s['size'] for s in spans)],'fonts':sorted(set(s['font'] for s in spans)),'all_text_black_and_inside_page':True,'macro_labels_clear_of_metric_names':True,'raster_exports':images}
(r/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
p.get_pixmap(matrix=fitz.Matrix(1.7,1.7)).save(r/'preview.png')
