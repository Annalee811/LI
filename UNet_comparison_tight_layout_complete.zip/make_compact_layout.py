"""Tight scientific composition of radial metrics and unchanged four-period crops."""
from pathlib import Path
import argparse,csv,json,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch
from matplotlib.text import Text

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);args=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(args.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':8.5,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'svg.fonttype':'none','axes.linewidth':.5,'axes.unicode_minus':False})
source=json.loads((ROOT/'source_comparison.json').read_text());rows=source['classes']
W,H=190.5,246
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
GREEN,ORANGE,PURPLE,BLUE='#00B050','#F07800','#604A7B','#56B4E9'
ring_colors=[GREEN,'#E6AA75',PURPLE];bar_colors=[GREEN,ORANGE,PURPLE]
def text(x,y,s,size=8.5,ha='left',bold=False):
 return fig.text(x/W,1-y/H,s,ha=ha,va='center',fontsize=size,fontweight='bold' if bold else 'normal',color='black')
text(2.5,5,'A',12,bold=True)
data=[]
for k,(cx,prefix,key,title) in enumerate([(52,'V66','V66 U-Net','Original U-Net'),(138,'V90','V90 reviewed','Reviewed U-Net')]):
 text(cx,5,title,10.5,ha='center',bold=True);text(cx-42,12,'ab'[k],9.5,bold=True)
 cy=46;side=76
 ax=fig.add_axes([(cx-side/2)/W,1-(cy+side/2)/H,side/W,side/H],projection='polar');ax.set_theta_zero_location('N');ax.set_theta_direction(-1);ax.set_ylim(0,140);ax.set_axis_off()
 rr0,span=56,40;theta=np.linspace(0,2*np.pi,721)
 for r in [56,76,96]:ax.plot(theta,np.full_like(theta,r),lw=.45,color='#D9DFE2',ls='-' if r==56 else (0,(2,2)),zorder=0)
 for ci,row in enumerate(rows):
  for mi,metric in enumerate(['Precision','Recall','Dice','IoU']):
   degrees=[-48,72,192][ci]+12+24*mi;angle=np.deg2rad(degrees);value=100*row[prefix+'_'+metric];height=span*value/100
   ax.bar(angle,span,width=np.deg2rad(22.8),bottom=rr0,color=ring_colors[ci],alpha=.14,ec='white',lw=.5,zorder=1)
   ax.bar(angle,height,width=np.deg2rad(22.8),bottom=rr0,color=ring_colors[ci],ec='white',lw=.5,zorder=2)
   aa=degrees%360;rot=90-aa;align='left'
   if 180<aa<360:rot+=180;align='right'
   ax.text(angle,106,metric,rotation=rot,rotation_mode='anchor',ha=align,va='center',fontsize=8,zorder=5)
   rot=-aa
   if 90<aa<270:rot+=180
   ax.text(angle,rr0+height+4,f'{value:.1f}',rotation=rot,rotation_mode='anchor',ha='center',va='center',fontsize=8,zorder=5,bbox=dict(fc='white',ec='none',alpha=.85,pad=.1))
   data.append({'Display_name':title,'Source_workflow':key,'Root_class':row['class_en'],'Metric':metric,'Score_percent':value})
 for score in [0,50,100]:ax.text(np.deg2rad(70),rr0+span*score/100,str(score),fontsize=8,ha='center',va='center',zorder=6,bbox=dict(fc='white',ec='none',pad=.1))
 iw,ih=19,16
 inset=fig.add_axes([(cx+2-iw/2)/W,1-(cy+ih/2)/H,iw/W,ih/H],facecolor='white')
 vals=[100*r[prefix+'_Dice'] for r in rows];inset.bar(range(3),vals,color=bar_colors,width=.66,ec='white',lw=.4)
 for i,val in enumerate(vals):inset.text(i,val+3,f'{val:.1f}',fontsize=8,ha='center',va='bottom')
 inset.set(xlim=(-.6,2.6),ylim=(0,125));inset.set_xticks([0,1,2],['N','E','P']);inset.set_yticks([0,50,100]);inset.tick_params(labelsize=8,length=1.3,width=.5,pad=1)
 inset.spines[['top','right']].set_visible(False)
 for side in ['left','bottom']:inset.spines[side].set_color('black');inset.spines[side].set_linewidth(.5)
 inset.set_title('Dice (%)',fontsize=8.5,pad=1,fontweight='bold')
 text(cx+5,80,f'Macro Dice = {100*source["summaries"][key]["macro"]["Dice"]:.2f}%',8.5,ha='center')
legendA=[Patch(fc=c,ec='none',label=n) for c,n in zip(bar_colors,['Newly observed','Extending','Persistent'])]
fig.legend(handles=legendA,loc='center',bbox_to_anchor=(.52,1-85/H),ncol=3,frameon=False,fontsize=8.5,handlelength=1.1,columnspacing=1.7)
text(2.5,90,'B',12,bold=True)
LEFT,CW,GAP=13.5,40,2
for j,label in enumerate(['Original RGB','Reference annotation','Original U-Net','Reviewed U-Net']):text(LEFT+j*(CW+GAP)+CW/2,90,label,8.5,ha='center',bold=True)
# Class arrays stay untouched; colors reproduce the supplied categorical scheme.
palette=np.full((256,3),255,np.uint8)
for code,color in [(1,PURPLE),(2,GREEN),(3,ORANGE),(4,BLUE)]:palette[code]=np.array(matplotlib.colors.to_rgb(color))*255
ROI=(1530,590,1830,850);x0,y0,x1,y1=ROI;HH=CW*(y1-y0)/(x1-x0)
crop_records=[]
for i,t in enumerate(['T1','T2','T3','T4']):
 y=94+i*(HH+1);text(5.5,y+HH/2,t,8.5,ha='center',bold=True)
 rgb=np.array(Image.open(ROOT/f'sources/RGB/{t}_RGB.png').convert('RGB'))
 arrays=[rgb[y0:y1,x0:x1].copy()];record={'Period':t,'ROI_xyxy':ROI,'crop_shape':[260,300],'crop_hashes':{}}
 dest=ROOT/'exact_crops'/t;dest.mkdir(parents=True,exist_ok=True);Image.fromarray(arrays[0]).save(dest/'Original_RGB.png')
 record['crop_hashes']['Original_RGB']=hashlib.sha256(arrays[0].tobytes()).hexdigest()
 for group in ['reference','V66','V90']:
  labels=np.array(Image.open(ROOT/f'sources/{group}/{t}_classes.png'))[y0:y1,x0:x1].copy()
  assert labels.shape==(260,300) and set(np.unique(labels)).issubset({0,1,2,3,4,255})
  Image.fromarray(labels).save(dest/f'{group}_classes.png');image=palette[labels];Image.fromarray(image).save(dest/f'{group}_colored.png');arrays.append(image)
  record['crop_hashes'][group]=hashlib.sha256(labels.tobytes()).hexdigest()
 for j,image in enumerate(arrays):
  ax=fig.add_axes([(LEFT+j*(CW+GAP))/W,1-(y+HH)/H,CW/W,HH/H]);ax.imshow(image,interpolation='nearest');ax.set_xticks([]);ax.set_yticks([])
  for s in ax.spines.values():s.set_visible(False)
 crop_records.append(record)
legendB=[Patch(fc=c,ec='none',label=n) for c,n in [(BLUE,'Baseline'),(GREEN,'Newly observed'),(ORANGE,'Extending'),(PURPLE,'Persistent')]]
fig.legend(handles=legendB,loc='center',bbox_to_anchor=(.52,1-242/H),ncol=4,frameon=False,fontsize=8.5,handlelength=1.1,columnspacing=1.4)
for t in fig.findobj(match=Text):t.set_fontfamily('Times New Roman');t.set_color('black')
stem='UNet_comparison_tight_layout'
for ext in ['png','pdf']:fig.savefig(ROOT/f'{stem}.{ext}',dpi=600,facecolor='white')
fig.savefig(ROOT/f'{stem}.tiff',dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
Image.open(ROOT/f'{stem}.png').convert('RGB').save(ROOT/f'{stem}.jpg','JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
with (ROOT/'radial_metrics.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
(ROOT/'layout_metadata.json').write_text(json.dumps({'figure_mm':[W,H],'matrix_column_gap_mm':GAP,'matrix_row_gap_mm':1,'matrix_panel_mm':[CW,HH],'radial_centers_mm':[[52,46],[138,46]],'panel_titles':['Original U-Net','Reviewed U-Net'],'source_names':{'Original U-Net':'V66 U-Net','Reviewed U-Net':'V90 final reviewed/structured workflow; display name follows the supplied figure.'},'class_codes':{'0':'Background/white','1':'Persistent','2':'Newly observed','3':'Extending','4':'T1 baseline','255':'Ignored reference/white'},'crop_details':crop_records,'metric_values':'Exact prior pooled comparison-table values, unchanged.','label_arrays':'Exact archived source crops. No smoothing, dilation, erosion or relabeling.','source_plot_scope':'T2–T4 common frozen reference B, root pixels only; not a four-period independent accuracy evaluation.','T1':'Baseline only; not included in temporal metric means.','new_training_or_registration':False},indent=2))
print('Created tighter radial + four-period image matrix; source metrics and masks unchanged.')
