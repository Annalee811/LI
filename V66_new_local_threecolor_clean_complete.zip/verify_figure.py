"""Check raw curves, pooled metrics, identical local overlays, fonts and exports."""
from pathlib import Path
import json,csv,hashlib
import numpy as np
from PIL import Image
import fitz
ROOT=Path(__file__).resolve().parent
d=json.loads((ROOT/'data_manifest.json').read_text());m=json.loads((ROOT/'metrics.json').read_text());f=json.loads((ROOT/'figure_manifest.json').read_text());plots=json.loads((ROOT/'plot_data.json').read_text())
checks=json.loads((ROOT/'source_checks.json').read_text());full_checks=0
for r in checks['checks']:
 p=ROOT/r['file']
 if not p.exists():p=ROOT.parent/'V66_three_models_training_class_RGB_20261113'/r['file']
 if p.exists():assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'];full_checks+=1
arrays=np.load(ROOT/'evaluation_label_arrays.npz')
for key,r in d['evaluation_arrays'].items():
 assert list(arrays[key].shape)==r['shape'] and hashlib.sha256(arrays[key].tobytes()).hexdigest()==r['array_sha256']
for model in ['unet','deeplab','segformer']:
 cm=np.zeros((3,4),np.int64)
 for t in ['T2','T3','T4']:
  g=arrays['reference_'+t];p=arrays[model+'_'+t];v=(g>=1)&(g<=3);yy=g[v].astype(int)-1;zz=np.where(p[v]==0,3,p[v].astype(int)-1)
  cm+=np.bincount(yy*4+zz,minlength=12).reshape(3,4)
 assert cm.sum()==468203 and np.array_equal(cm,m['confusion_matrices'][model])
 for r in [q for q in m['class_metrics'] if q['model_key']==model]:
  i=r['class_code']-1;tp=int(cm[i,i]);fp=int(cm[:,i].sum()-tp);fn=int(cm[i,:].sum()-tp)
  assert (tp,fp,fn)==(r['TP'],r['FP'],r['FN'])
  for k,val in [('Precision',tp/(tp+fp)),('Recall',tp/(tp+fn)),('Dice',2*tp/(2*tp+fp+fn)),('IoU',tp/(tp+fp+fn))]:assert abs(r[k]-val)<1e-12
 log=next(r for r in d['training_logs'] if r['model']==model);path=ROOT/log['file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==log['sha256']
 rows=list(csv.DictReader(path.open(encoding='utf-8-sig')));assert len(rows)==100
 plotted=next(r for r in plots['curves'] if r['model']==model)
 assert plotted['epochs']==list(range(1,101))
 assert plotted['training_loss']==[float(r['training_loss']) for r in rows]
 assert plotted['validation_loss']==[float(r['validation_loss']) for r in rows]
 assert int(max(rows,key=lambda q:float(q['validation_macro_Dice']))['epoch'])==plotted['selected_epoch']==log['selected_epoch']
assert len(plots['scores'])==36
for r in plots['scores']:
 source=next(q for q in m['class_metrics'] if q['model_key']==r['model'] and q['class_code']==r['class_code'])
 assert abs(r['score_percent']/100-source[r['metric']])<1e-12
x0,y0,x1,y1=d['ROI_xyxy'];assert [x0,y0,x1,y1]==[850,650,1270,970]
for r in d['crop_records']:
 a=np.array(Image.open(ROOT/r['file']));assert a.shape[:2]==(320,420)
 assert hashlib.sha256(a.tobytes()).hexdigest()==r['array_sha256']
 if r['kind']!='RGB':assert np.array_equal(a,arrays[r['kind']+'_'+r['period']][y0:y1,x0:x1])
colors={int(c):np.array([int(v[i:i+2],16) for i in (1,3,5)],np.uint8) for c,v in f['colors'].items()}
for r in f['local_overlays']:
 rgb=np.array(Image.open(ROOT/f'local_crops/{r["period"]}_RGB.png'));labels=np.array(Image.open(ROOT/f'local_crops/{r["period"]}_{r["group"]}_classes.png'));expected=rgb.copy()
 for code,color in colors.items():expected[labels==code]=color
 a=np.array(Image.open(ROOT/r['file']));assert np.array_equal(a,expected) and np.array_equal(a[labels==0],rgb[labels==0])
 assert hashlib.sha256(a.tobytes()).hexdigest()==r['array_sha256']
assert not f['full_field_panels'] and f['same_ROI_four_periods']
assert f['shared_reference_columns']==['Original RGB','Human reference']
assert f['shared_RGB_panels']==4 and f['shared_human_reference_panels']==4
assert f['image_panels']==20 and len(f['model_blocks'])==3
assert sorted(b['column_index'] for b in f['model_blocks'])==[2,3,4]
for b in f['model_blocks']:assert b['model']==b['curve_model']==b['metric_model']==b['prediction_group'] and b['prediction_panels']==4
stem='V66_shared_new_local_threecolor_clean_SCI'
with fitz.open(ROOT/(stem+'.pdf')) as doc:
 assert len(doc)==1
 fonts={r[3].split('+')[-1] for r in doc[0].get_fonts()};assert fonts=={'TimesNewRomanPSMT','TimesNewRomanPS-BoldMT'}
 spans=[s for b in doc[0].get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
 assert all(s['color']==0 for s in spans) and min(s['size'] for s in spans)>=9.49
 for s in spans:
  r=fitz.Rect(s['bbox']);assert r.x0>=0 and r.y0>=0 and r.x1<=doc[0].rect.width and r.y1<=doc[0].rect.height
 font_range=[min(s['size'] for s in spans),max(s['size'] for s in spans)]
exports={}
for ext in ['png','jpg','tiff']:
 with Image.open(ROOT/(stem+'.'+ext)) as im:
  assert abs(im.width-round(225/25.4*600))<=1 and abs(im.height-round(240/25.4*600))<=1
  assert im.convert('RGB').getpixel((0,0))==(255,255,255)
  exports[ext]={'pixels':list(im.size),'dpi':[float(v) for v in im.info.get('dpi',(0,0))]}
report={'version':'V66 original three temporal heads, not V35 binary or V90 reviewed maps','source_assets_checked_locally':full_checks,'source_assets_in_release_manifest':26,'raw_training_curves':'3 × 100 original epochs, exact unsmoothed loss values','selected_epochs':f['selected_epochs'],'per_class_scores_verified':36,'common_evaluated_root_pixels':468203,'T1_in_temporal_scores':False,'reference_column_and_metrics_share_reference_B':True,'macro_Dice':{k:v['macro_Dice'] for k,v in m['summaries'].items()},'same_ROI_four_dates':[850,650,1270,970],'image_panels':20,'shared_RGB_columns':1,'shared_human_reference_columns':1,'model_curves_scores_predictions_column_aligned':True,'RGB_background_and_original_class_geometry_unchanged':True,'full_field_panels':False,'PDF_pages':1,'font_faces':sorted(fonts),'text_black':True,'font_range_pt':font_range,'all_text_within_page':True,'exports':exports,'new_training_registration_or_inference':False}
(ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
