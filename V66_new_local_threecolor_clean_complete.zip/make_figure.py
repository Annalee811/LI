"""Shared RGB/reference columns and model-aligned V66 curves, metrics and predictions."""
from pathlib import Path
import argparse,csv,json,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,patheffects
from matplotlib.lines import Line2D
from matplotlib.patches import Patch,Rectangle
import fitz
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);args=p.parse_args()
for n in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(args.fonts_dir/n))
plt.rcParams.update({'font.family':'Times New Roman','font.size':9.5,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'axes.linewidth':.6})
data=json.loads((ROOT/'data_manifest.json').read_text());metric=json.loads((ROOT/'metrics.json').read_text())
MODELS={'unet':'U-Net','deeplab':'DeepLabV3+','segformer':'SegFormer-B0'}
COLORS={1:'#3F75C4',2:'#E69F35',3:'#B64E8B',4:'#FFFFFF',255:'#808890'}
NAMES={1:'Persistent',2:'Newly emerged',3:'Elongating',4:'T1 baseline',255:'Ignored reference'}
RGB={c:(np.array(matplotlib.colors.to_rgb(h))*255).round().astype(np.uint8) for c,h in COLORS.items()}
W,H=225,240
LEFT,CW,GAP=10,39.5,2
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white')
def txt(x,y,s,size=9.5,ha='left',bold=False):
 return fig.text(x/W,1-y/H,s,ha=ha,va='center',fontsize=size,fontweight='bold' if bold else 'normal',color='black')
def rule(x0,x1,y,color='#223F52',lw=.85):fig.add_artist(Line2D([x0/W,x1/W],[1-y/H]*2,transform=fig.transFigure,color=color,lw=lw))

# Shared information occupies the space above the two shared image columns.
txt(LEFT,8,'V66',16,bold=True)
txt(LEFT,16,'Temporal root classification',11,bold=True)
for y,color,ls,label in [(29,'#234D6E','-','Training'),(35.5,'#963F3F','--','Validation')]:
 fig.add_artist(Line2D([LEFT/W,(LEFT+7)/W],[1-y/H]*2,transform=fig.transFigure,color=color,lw=1.25,ls=ls))
 txt(LEFT+10,y,label)
txt(91.5,65.8,'Class',9.5,'right',True)

curve_records=[];score_records=[];blocks=[]
for j,(model,name) in enumerate(MODELS.items()):
 x=LEFT+(j+2)*(CW+GAP);cx=x+CW/2
 txt(cx,8,name,12,'center',True);rule(x,x+CW,13,lw=1)
 rows=list(csv.DictReader((ROOT/f'training_logs/{model}.csv').open(encoding='utf-8-sig')))
 epochs=np.array([int(r['epoch']) for r in rows]);train=np.array([float(r['training_loss']) for r in rows]);val=np.array([float(r['validation_loss']) for r in rows]);assert len(rows)==100
 best=json.loads((ROOT/f'training_logs/{model}_parameters.json').read_text())['selected_epoch']
 ax=fig.add_axes([(x+3)/W,1-46/H,(CW-6)/W,26/H])
 ax.plot(epochs,train,color='#234D6E',lw=1.2);ax.plot(epochs,val,color='#963F3F',lw=1.2,ls=(0,(3,1.5)))
 ax.axvline(best,color='#6D7F8B',lw=.65,ls=(0,(2,2)),zorder=0)
 ax.text(.97,.96,f'Epoch {best}',ha='right',va='top',transform=ax.transAxes,fontsize=9.5,color='black',bbox={'fc':'white','ec':'none','alpha':.9,'pad':.3})
 ax.set(xlim=(0,100),ylim=(0,1.8));ax.set_xticks([0,50,100]);ax.set_yticks([0,.8,1.6]);ax.tick_params(labelsize=9.5,length=2,width=.6,pad=2,labelleft=j==0)
 ax.spines[['top','right']].set_visible(False)
 for s in ['left','bottom']:ax.spines[s].set_color('#566D7B')
 ax.grid(axis='y',color='#D8E0E5',lw=.55);ax.set_axisbelow(True)
 ax.set_xlabel('Epoch',fontsize=9.5,labelpad=1)
 if j==0:ax.set_ylabel('Loss',fontsize=9.5,labelpad=1)
 curve_records.append({'model':model,'epochs':epochs.tolist(),'training_loss':train.tolist(),'validation_loss':val.tolist(),'selected_epoch':best,'smoothing':'None'})

 txt(cx,59.8,'Class-wise evaluation (%)',9.5,'center',True)
 for k,label in enumerate(['Prec.','Recall','Dice','IoU']):txt(x+(k+.5)*CW/4,65.8,label,9.5,'center',label=='Dice')
 table=fig.add_axes([x/W,1-93/H,CW/W,24/H]);table.set(xlim=(-.5,3.5),ylim=(2.5,-.5));table.set_axis_off()
 for i,code in enumerate([2,3,1]):
  if j==0:
   txt(x-1.5,73+8*i,NAMES[code],9.5,'right',True)
   fig.add_artist(Rectangle(((x-27.5)/W,1-(74.2+8*i)/H),2/W,2.5/H,transform=fig.transFigure,fc=COLORS[code],ec='none'))
  row=next(r for r in metric['class_metrics'] if r['model_key']==model and r['class_code']==code)
  color=np.array(matplotlib.colors.to_rgb(COLORS[code]))
  for k,m in enumerate(['Precision','Recall','Dice','IoU']):
   value=100*row[m];a=.1+.58*value/100;shade=(1-a)*np.ones(3)+a*color
   table.add_patch(plt.Rectangle((k-.5,i-.5),1,1,fc=shade,ec='white',lw=.9))
   table.text(k,i,f'{value:.1f}',ha='center',va='center',fontsize=9.5,fontweight='bold' if m=='Dice' else 'normal',color='black')
   score_records.append({'class_code':code,'class':NAMES[code],'model':model,'metric':m,'score_percent':float(value)})
 txt(cx,98.5,f'Macro Dice: {100*metric["summaries"][model]["macro_Dice"]:.2f}%',9.5,'center',True)
 blocks.append({'model':model,'name':name,'column_index':j+2,'column_center_mm':cx,'curve_model':model,'metric_model':model,'prediction_group':model,'prediction_panels':4})

# One original RGB column and one human-reference column, shared by all models.
rule(LEFT,LEFT+5*CW+4*GAP,102.2,color='#9AAAB5',lw=.65)
for j,label in enumerate(['Original RGB','Human reference']+list(MODELS.values())):txt(LEFT+j*(CW+GAP)+CW/2,107,label,10,'center',True)
(ROOT/'local_overlays').mkdir(exist_ok=True);overlay_records=[]
PH=CW*320/420
for i,t in enumerate(['T1','T2','T3','T4']):
 yy=112+i*(PH+1.5);txt(4.8,yy+PH/2,t,10,'center',True)
 rgb=np.array(Image.open(ROOT/f'local_crops/{t}_RGB.png').convert('RGB'));images=[rgb]
 for group in ['reference']+list(MODELS):
  labels=np.array(Image.open(ROOT/f'local_crops/{t}_{group}_classes.png'));out=rgb.copy()
  for code,color in RGB.items():out[labels==code]=color
  assert np.array_equal(out[labels==0],rgb[labels==0])
  file=f'local_overlays/{t}_{group}_on_RGB.png';Image.fromarray(out).save(ROOT/file);images.append(out)
  overlay_records.append({'period':t,'group':group,'file':file,'ROI_xyxy':data['ROI_xyxy'],'array_sha256':hashlib.sha256(out.tobytes()).hexdigest(),'background_unchanged':True})
 for j,image in enumerate(images):
  aa=fig.add_axes([(LEFT+j*(CW+GAP))/W,1-(yy+PH)/H,CW/W,PH/H]);aa.imshow(image,interpolation='nearest');aa.set(xlim=(-.5,419.5),ylim=(319.5,-.5));aa.set_xticks([]);aa.set_yticks([])
  for s in aa.spines.values():s.set_visible(False)
  if j==0 and i==0:
   line,=aa.plot([16,116],[304,304],color='white',lw=1.5,solid_capstyle='butt');line.set_path_effects([patheffects.Stroke(linewidth=2.4,foreground='black'),patheffects.Normal()])
   aa.text(66,284,'100 px',fontsize=9.5,ha='center',va='bottom',color='black',bbox={'fc':'white','ec':'none','pad':.4})
stem='V66_shared_new_local_threecolor_clean_SCI'
for ext in ['png','pdf']:fig.savefig(ROOT/(stem+'.'+ext),dpi=600,facecolor='white')
fig.savefig(ROOT/(stem+'.tiff'),dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)
Image.open(ROOT/(stem+'.png')).convert('RGB').save(ROOT/(stem+'.jpg'),'JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
with fitz.open(ROOT/(stem+'.pdf')) as doc:doc[0].get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False).save(ROOT/'preview.png')
(ROOT/'plot_data.json').write_text(json.dumps({'curves':curve_records,'scores':score_records},indent=2)+'\n')
(ROOT/'figure_manifest.json').write_text(json.dumps({'figure_mm':[W,H],'raster_dpi':600,'version':'V66 original three temporal heads','layout':'Five aligned columns: one shared RGB, one shared human reference, then three model columns. Each model loss curve and class table sit directly above its prediction column.','model_blocks':blocks,'shared_reference_columns':['Original RGB','Human reference'],'shared_RGB_panels':4,'shared_human_reference_panels':4,'selected_epochs':{r['model']:r['selected_epoch'] for r in curve_records},'colors':{str(c):h for c,h in COLORS.items()},'class_names':{str(c):n for c,n in NAMES.items()},'score_scope':metric['scope'],'same_ROI_four_periods':True,'ROI_xyxy':data['ROI_xyxy'],'full_field_panels':False,'image_panels':20,'local_overlays':overlay_records,'reference_column':'Frozen set B, manual temporal labels plus pre-existing U-Net-assisted binary outlines','font':'Black Times New Roman regular/bold, 9.5–16 pt','legend_scope':'Training/Validation and a single three-class row-color key; other details in caption','foreground_geometry_unchanged':True,'new_training_registration_or_inference':False},indent=2)+'\n')
print('Rendered shared RGB/human columns, model-aligned analyses and larger dark-palette local views.')
