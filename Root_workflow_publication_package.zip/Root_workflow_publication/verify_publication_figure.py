from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
import fitz

ROOT=Path(__file__).resolve().parent
meta=json.loads((ROOT/'publication_composition.json').read_text());assets=json.loads((ROOT/'asset_verification.json').read_text())
assert len(meta['actual_scientific_raster_panels'])==13
for entry in meta['actual_scientific_raster_panels']:
 im=np.array(Image.open(ROOT/entry['file']).convert('RGB'))[:,20:280]
 assert list(im.shape)==entry['displayed_array_shape']
 assert hashlib.sha256(im.tobytes()).hexdigest()==entry['displayed_array_sha256']
source_checks=0
for entry in assets['checks']:
 p=Path(entry['file'])
 if p.exists():assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256'];source_checks+=1
assert round(assets['U-Net_binary_Dice'],4)==.8788
d=fitz.open(ROOT/'Root_workflow_real_images_TimesNewRoman_white.pdf');assert len(d)==1
p=d[0];spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for line in b['lines'] for s in line['spans'] if s['text'].strip()]
allowed={'TimesNewRomanPSMT','TimesNewRomanPS-BoldMT','TimesNewRomanPS-ItalicMT'}
assert {s['font'] for s in spans}==allowed
assert all(s['color']==0 and p.rect.contains(fitz.Rect(s['bbox'])) for s in spans)
assert min(s['size'] for s in spans)>=8.99
assert any(s['font']=='TimesNewRomanPS-ItalicMT' and 'Elymus sibiricus' in s['text'] for s in spans)
assert '0.8788' in p.get_text()
image_checks={}
for ext in ['png','jpg','tiff']:
 im=Image.open(ROOT/f'Root_workflow_real_images_TimesNewRoman_white.{ext}').convert('RGB')
 assert im.width==5669 and abs(im.height-meta['figure_mm'][1]/25.4*600)<1
 assert im.getpixel((0,0))==(255,255,255)
 image_checks[ext]={'pixels':im.size,'top_left_background_RGB':im.getpixel((0,0))}
report={'actual_scientific_panels_embedded':13,'exact_crop_arrays_match_local_source_assets':True,'full_archived_source_files_sha256_verified_locally':source_checks,'source_RGB_and_prediction_arrays_not_generated':True,'verified_existing_Dice_label':.8788,'fonts':sorted(allowed),'text_color':'All newly typeset text black','font_range_pt':[min(s['size'] for s in spans),max(s['size'] for s in spans)],'binomial_italic_author_roman':True,'all_vector_text_within_page':True,'PDF_page_count':1,'figure_mm':meta['figure_mm'],'image_exports':image_checks,'illustrative_base':'Edited from the supplied workflow; scientific photos/masks overlaid afterwards from exact archived data. The schematic panels are not prediction images.'}
(ROOT/'publication_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
p.get_pixmap(matrix=fitz.Matrix(2,2)).save(ROOT/'publication_preview.png')
