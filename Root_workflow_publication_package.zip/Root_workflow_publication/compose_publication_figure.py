"""Publication figure assembly: original scientific raster panels + true TNR text."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle,Circle,FancyBboxPatch
import fitz

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fonts-dir',type=Path,required=True);args=p.parse_args()
for name in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(args.fonts_dir/name))
italic=args.fonts_dir/'Times New Roman Italic.ttf'
if italic.exists():font_manager.fontManager.addfont(str(italic))
plt.rcParams.update({'font.family':'Times New Roman','text.color':'black','pdf.fonttype':42,'svg.fonttype':'none'})
base=np.array(Image.open(ROOT/'workflow_illustrative_base.png').convert('RGB'))
assert base.shape[:2]==(937,1678)
near_white=(base.min(axis=2)>=242)&((base.max(axis=2).astype(int)-base.min(axis=2).astype(int))<=18)
rgba=np.dstack([base,np.where(near_white,0,255).astype(np.uint8)])
W,H=240,240*937/1678
fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white');ax=fig.add_axes([0,0,1,1]);ax.set_xlim(0,1678);ax.set_ylim(937,0);ax.set_axis_off()
ax.imshow(rgba,extent=(0,1678,937,0),interpolation='nearest',zorder=0)
def white(rect):
 x0,y0,x1,y1=rect;ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,facecolor='white',edgecolor='none',zorder=5))
def label(rect,s,size=10.5,bold=False,align='center',italic=False):
 white(rect);x0,y0,x1,y1=rect
 ax.text((x0+x1)/2 if align=='center' else x0+2,(y0+y1)/2,s,fontsize=size,fontweight='bold' if bold else 'normal',fontstyle='italic' if italic else 'normal',fontfamily='Times New Roman',color='black',ha='center' if align=='center' else 'left',va='center',linespacing=1.05,zorder=8)

# Exact, already verified scientific panels. All square panels use the same
# central 260×260 window of the supplied 300×260 crops (full-field x=1550:1810).
placed=[]
def panel(file,rect,period,role,square=True,zorder=3):
 im=np.array(Image.open(ROOT/file).convert('RGB'))
 if square:im=im[:,20:280].copy()
 x0,y0,x1,y1=rect
 ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,facecolor='black',edgecolor='black',lw=.5,zorder=zorder))
 ax.imshow(im,extent=(x0+1,x1-1,y1-1,y0+1),interpolation='nearest',aspect='auto',zorder=zorder+.1)
 placed.append({'file':file,'period':period,'role':role,'frame_xyxy':rect,'source_crop':'1550:1810,590:850' if square else '1530:1830,590:850','displayed_array_shape':list(im.shape),'displayed_array_sha256':hashlib.sha256(im.tobytes()).hexdigest()})
for t,rect in zip(['T1','T2','T3','T4'],[(441,112,625,297),(638,112,822,297),(835,112,1019,297),(1031,112,1215,297)]):panel(f'{t}_actual_RGB.png',rect,t,'Top-stage actual RGB')
# Paint the stack in back-to-front order, preserving its illustration geometry.
for t,rect in [('T4',(152,681,347,766)),('T3',(112,662,319,780)),('T2',(70,642,278,795)),('T1',(24,622,230,816))]:panel(f'{t}_actual_RGB.png',rect,t,'Input stack actual RGB',zorder=3+(.2*(5-int(t[1]))))
panel('T2_actual_UNet_red_mask.png',(597,630,783,816),'T2','Main U-Net result')
for t,rect in zip(['T1','T2','T3','T4'],[(843,441,939,536),(843,548,939,643),(843,655,939,750),(843,761,939,857)]):panel(f'{t}_actual_UNet_red_mask.png',rect,t,'Actual temporal U-Net mask')

# Re-typeset existing wording using the real Times New Roman font. These text
# objects stay vector-based in PDF, independent of the illustrative raster base.
white((33,0,381,80))
ax.text(55,29,'Elymus sibiricus',fontsize=14,fontstyle='italic',fontfamily='Times New Roman',ha='left',va='center',color='black',zorder=8)
name_width=fitz.Font(fontfile=str(italic)).text_length('Elymus sibiricus',fontsize=14)*1678/(W/25.4*72)
ax.text(55+name_width+7,29,'L.',fontsize=14,fontfamily='Times New Roman',ha='left',va='center',color='black',zorder=8)
ax.text(198,61,'(perennial forage grass)',fontsize=12,fontfamily='Times New Roman',ha='center',va='center',color='black',zorder=8)
for s,rect in [('T1 (Seedling)',(445,78,622,106)),('T2 (Heading)',(641,78,820,106)),('T3 (Maturity)',(837,78,1017,106)),('T4 (Senescence)',(1030,78,1221,106))]:label(rect,s,10.5,True)
label((28,226,85,254),'Soil',10.5)
label((33,343,190,399),'Minirhizotron\nTube',10.5,False,'left')
label((271,360,375,417),'Miniature\nCamera',10.5)
label((216,515,308,545),'Camera',10.5)
label((1230,124,1347,181),'Temporal\nDynamics',11)
label((1373,44,1640,83),'Applications',13,True)
label((1364,190,1506,243),'Phenotyping\nGermplasms',10.5)
label((1510,190,1656,243),'Continuous\nMonitoring',10.5)
label((726,313,1001,349),'RoMa Alignment',12,True)
label((576,590,799,624),'U-Net (Dice: 0.8788)',10.5)
label((422,806,534,863),'Segment\nU-Net',11)
label((28,820,244,851),'Minirhizotron',10.5)
label((964,410,1213,447),'ConvLSTM + GAT',12,True)
for i,y in enumerate([484,591,699,805],1):label((799,y-16,836,y+16),f'T{i}',10.5)
label((1069,552,1203,590),'GAT Graph',11)
label((1379,342,1578,400),'T2: High\nNewly Emerged',10.5)
label((1548,277,1662,329),'T4: High\nPersistent',10.5)
for s,x in [('T1',1417),('T2',1483),('T3',1550),('T4',1616)]:label((x-20,457,x+20,484),s,10.5)
white((1500,755,1648,844))
for s,rect in [('Persistent',(1503,758,1647,786)),('Newly Emerged',(1503,787,1647,814)),('Elongating',(1503,815,1647,842))]:label(rect,s,9,False,'left')
white((0,874,1678,937))
for x0,x1 in [(8,355),(366,785),(794,1238),(1248,1670)]:
 ax.add_patch(FancyBboxPatch((x0,879),x1-x0,53,boxstyle='round,pad=0,rounding_size=10',facecolor='white',edgecolor='#416087',linewidth=.7,zorder=6))
for s,rect,size in [('Data Acquisition',(103,884,351,929),11),('Image Alignment &\nSegmentation',(449,880,779,932),10.5),('Spatiotemporal Classification',(851,883,1232,930),10.5),('Dynamics & Applications',(1305,883,1665,930),10.5)]:label(rect,s,size,True)
# Re-typeset stage numerals in clean circles at their existing footer locations.
for i,x in enumerate([78,413,827,1280],1):
 ax.add_patch(Circle((x,906),20,facecolor='white',edgecolor='black',linewidth=.8,zorder=7))
 ax.text(x,906,str(i),fontsize=11.5,fontfamily='Times New Roman',ha='center',va='center',color='black',zorder=8)

stem='Root_workflow_real_images_TimesNewRoman_white'
for ext in ['png','pdf']:fig.savefig(ROOT/f'{stem}.{ext}',dpi=600,facecolor='white')
fig.savefig(ROOT/f'{stem}.tiff',dpi=600,facecolor='white',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
Image.open(ROOT/f'{stem}.png').convert('RGB').save(ROOT/f'{stem}.jpg','JPEG',quality=98,subsampling=0,optimize=True,dpi=(600,600))
(ROOT/'publication_composition.json').write_text(json.dumps({'figure_mm':[W,H],'actual_scientific_raster_panels':placed,'font':'Real Times New Roman; vector text in PDF','canvas':'Pure white, with near-white illustrative backdrop made transparent. Scientific panels bypass background whitening.','illustrations':'White-background edited schematic base; plant, minirhizotron, camera, U-Net architecture, ConvLSTM/GAT, applications and final root illustration retained as schematics.','data_scope':'Image panels use archived B3 RGB and V35 U-Net masks, not synthetic generated predictions.','U-Net_Dice':0.8787985060232514,'display_Dice':'0.8788','new_training_or_registration':False},indent=2))
print('Composed publication figure with 13 exact real-data panels and embedded Times New Roman text.')
