"""Combine exact archived V35/V66 minirhizotron images; no inference or image editing."""
from pathlib import Path,PurePosixPath
import json,csv,hashlib,zipfile,io,shutil,sys
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent;S=R/'sources';O=R/'bundle';O.mkdir(exist_ok=True)
sys.path.insert(0,'/workspace/LI/analysis-scripts');from dataset_identity import require_active_position
frozen=Path('/workspace/work/root_traits_18_series_table_20261107');rows=json.loads((frozen/'extracted_values_full_precision.json').read_text());expected={(q['Observation unit'],q['Period']) for q in rows if q['Skeleton length (10³ px)'] is not None}
assert len(expected)==63
for pos,t in expected:require_active_position(pos)
manifest=json.loads((R/'source_download_manifest.json').read_text());index=[];filechecks=[];frames={'binary':set(),'temporal':set()};imagecounts={};masks={};classes={}
for rec in manifest['archives']:
 kind=rec['kind'];mat=rec['material'];stage='V35_binary' if kind=='binary' else 'V66_temporal';archive=S/Path(rec['url']).name
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==rec['SHA256']
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for inf in z.infolist():
   if inf.is_dir():continue
   parts=PurePosixPath(inf.filename).parts;assert '..' not in parts and not inf.filename.startswith('/')
   data=z.read(inf);is_position=len(parts)>=3 and parts[0]==mat
   dest=O/stage/inf.filename if is_position else O/'source_metadata'/stage/mat/inf.filename
   dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
   digest=hashlib.sha256(data).hexdigest();filechecks.append({'file':str(dest.relative_to(O)),'sha256':digest,'source_archive':archive.name,'source_member':inf.filename})
   if is_position and inf.filename.lower().endswith(('.png','.jpg','.jpeg','.tif','.tiff')):
    pos=parts[1];period=parts[-1].split('_')[0];require_active_position(pos)
    with Image.open(io.BytesIO(data)) as im:
     im.load();width,height=im.size
     if parts[-1].endswith('_root_mask.png'):masks[pos,period]=np.array(im)>0;frames['binary'].add((pos,period))
     if parts[-1].endswith('_classes.png'):classes[pos,period]=np.array(im);frames['temporal'].add((pos,period))
    index.append({'model_stage':stage,'material':mat,'position':pos,'period':period,'image_type':'_'.join(parts[-1].split('_')[1:]),'width':width,'height':height,'file':str(dest.relative_to(O)),'sha256':digest})
    imagecounts[stage+'/'+mat]=imagecounts.get(stage+'/'+mat,0)+1
assert frames['binary']==frames['temporal']==expected
for key in expected:
 assert masks[key].shape==classes[key].shape and np.array_equal(masks[key],classes[key]>0),key
with (O/'Image_index.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(index[0]));w.writeheader();w.writerows(index)
missing=[q for q in rows if q['Skeleton length (10³ px)'] is None]
with (O/'Missing_periods_and_sources.csv').open('w',encoding='utf-8-sig',newline='') as f:
 fields=['position','period','source_status'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for q in missing:w.writerow(dict(position=q['Observation unit'],period=q['Period'],source_status=q['Acquisition/processing status']))
with (O/'Frame_status.csv').open('w',encoding='utf-8-sig',newline='') as f:
 fields=['position','period','source_status','adjacent_status','registration_review','image_available'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for q in rows:w.writerow(dict(position=q['Observation unit'],period=q['Period'],source_status=q['Acquisition/processing status'],adjacent_status=q['Adjacent status'],registration_review=q['Registration review'],image_available=(q['Observation unit'],q['Period']) in expected))
sourcebook=frozen/'sources/All_microtube_root_traits.xlsx';assert hashlib.sha256(sourcebook.read_bytes()).hexdigest()=='ea74bf1853766e51fa3b30546d6893032e57e50ea991514c2735182a6fdb0e52'
shutil.copy2(sourcebook,O/'Corresponding_original_table.xlsx');shutil.copy2(R/'source_download_manifest.json',O/'source_download_manifest.json')
summary={'source_commit':manifest['commit'],'observation_sequences':18,'source_tubes':8,'possible_period_cells':72,'available_segmented_frames':63,'binary_frames_by_material':{m:sum(p.startswith(m+'-') for p,t in expected) for m in ['0353','A017','Q1']},'temporal_frames':63,'valid_adjacent_pairs':40,'missing_period_or_source_cells':9,'missing_acquisitions':6,'unavailable_sources':3,'image_files':len(index),'image_counts':imagecounts,'all_frame_sets_match_frozen_Excel':True,'all_temporal_foreground_equals_binary_mask':True,'all_archived_member_bytes_unchanged':True,'images_reencoded':False,'new_training_inference_registration':False,'models':'V35 U-Net epoch77 binary; V66 U-Net temporal head epoch37','not_V90':True,'files_copied':filechecks}
(O/'verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(R/'bundle_summary.json').write_text(json.dumps({k:v for k,v in summary.items() if k!='files_copied'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='files_copied'},ensure_ascii=False,indent=2))
# Read-back thumbnails are taken directly from an existing archive, without edits.
with zipfile.ZipFile(S/'0353_UNet_temporal_segmentation.zip') as z:
 n=next(i for i in z.namelist() if i.endswith('/T2_temporal_overlay.jpg'));(R/'example_temporal_overlay.jpg').write_bytes(z.read(n))
