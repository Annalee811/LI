"""Exactly three horizontally aligned axes: baselines, effects, prediction.

No new model inference, fitting or alteration of source measurements.
"""
from pathlib import Path
import argparse,csv,json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
W=Path(__file__).resolve().parent
def read(name):return list(csv.DictReader((W/name).open(encoding='utf-8-sig')))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--fonts',type=Path,default=Path('/workspace/work/root_workflow_real_assets_20261109/fonts'));a=ap.parse_args()
 for f in ['Times New Roman.ttf','Times New Roman Bold.ttf']:font_manager.fontManager.addfont(str(a.fonts/f))
 plt.rcParams.update({'font.family':'Times New Roman','font.size':8,'axes.labelsize':8,'axes.labelweight':'bold','axes.linewidth':.65,
  'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','xtick.labelsize':7.4,'ytick.labelsize':7.7,
  'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
 colors={'new':'#C58D31','existing':'#3F7091'};classes=read('Internal_two_class_classwise.csv');refs=read('Historical_two_class_references.csv')
 effects=read('Paired_module_two_class_effects.csv');decoder=read('Paired_decoder_two_class.csv');seeds=[20261123,20261124,20261125]
 fig=plt.figure(figsize=(190/25.4,100/25.4),facecolor='white')
 axa=fig.add_axes((.122,.30,.205,.50));axb=fig.add_axes((.435,.30,.205,.50));axc=fig.add_axes((.707,.245,.278,.598))
 assert len(fig.axes)==3
 for x,title,center,letter in [(.012,'Temporal baselines',.215,'A'),(.347,'Ablation & decoding',.522,'B'),(.668,'Independent prediction',.835,'C')]:
  fig.text(x,.935,letter,fontsize=12,fontweight='bold',va='center');fig.text(center,.935,title,fontsize=8.6,fontweight='bold',ha='center',va='center')
 audit=[]
 for i,(model,label)in enumerate([('current_only','Frame-only'),('V66_pairwise_frozen','V66 prior'),('no_temporal_relation','w/o joint'),('full','Full')]):
  for cl,offset,marker in [('existing',-.12,'s'),('new',.12,'o')]:
   r=[r for r in refs if r['model']==model and r['class_name']==cl]if model=='V66_pairwise_frozen'else[r for r in classes if r['variant']==model and r['class_name']==cl]
   x=np.array([float(r['Dice'])*100 for r in r]);mean=float(x.mean());sd=float(x.std(ddof=1))if len(x)>1 else None
   axa.errorbar(mean,i+offset,xerr=sd if sd is not None else 0,fmt=marker,color=colors[cl],ms=4.4,capsize=2,lw=1.1,zorder=4)
   axa.text(mean,i+(-.34 if cl=='existing'else .37),f'{mean:.1f}',ha='center',va='center',fontsize=7.3)
   audit.append(dict(panel='A',comparison=model,class_or_metric=cl,value=mean,SD=sd,unit='Dice (%)',reference='Common B3 held-out typed-root domain'))
 axa.set_yticks(range(4),['Frame-only','V66 prior','w/o joint','Full']);axa.set_ylim(3.65,-.65);axa.set_xlim(-5,108);axa.set_xticks([0,50,100]);axa.set_xlabel('Class Dice (%)',labelpad=4)
 axa.spines['left'].set_visible(False);axa.tick_params(axis='y',length=0,pad=4);axa.grid(axis='x',color='#E8ECEF',lw=.45);axa.set_axisbelow(True)
 # B is one forest, with explicitly different reference contexts for its two blocks.
 ys=[];labels=[]
 for i,(module,label)in enumerate([('ConvLSTM + GAT','ConvLSTM\n+ GAT'),('Learned identity gates','Gate')]):
  x=np.array([float(r['delta_macro_Dice_pp'])for r in effects if r['module']==module]);mean=x.mean();sd=x.std(ddof=1)
  axb.errorbar(mean,i,xerr=sd,fmt='o',color='#777F87',ms=4.1,capsize=2.5,lw=1.2,zorder=4)
  # Put labels in a dedicated value column, keeping small effects legible.
  axb.text(1.02,i,f'{mean:+.3f}',transform=axb.get_yaxis_transform(),ha='left',va='center',fontsize=7.0)
  ys.append(i);labels.append(label);audit.append(dict(panel='B',comparison=module,class_or_metric='two-class macro Dice',value=float(mean),SD=float(sd),unit='percentage points',reference='Full minus ablated; partition-isolated context'))
 for y,stage,before,label in [(3,'axis_constraints','raw_head','+ Axis'),(4,'axis_and_junction_constraints','axis_constraints','+ Junction')]:
  x=np.array([100*(float(next(r['macro_Dice']for r in decoder if r['stage']==stage and int(r['seed'])==seed))-float(next(r['macro_Dice']for r in decoder if r['stage']==before and int(r['seed'])==seed)))for seed in seeds])
  mean=x.mean();sd=x.std(ddof=1);axb.errorbar(mean,y,xerr=sd,fmt='s',color='#826071',ms=4.3,capsize=2.5,lw=1.2,zorder=4)
  axb.text(1.02,y,f'{mean:+.3f}',transform=axb.get_yaxis_transform(),ha='left',va='center',fontsize=7.0);ys.append(y);labels.append(label)
  audit.append(dict(panel='B',comparison=stage,class_or_metric='two-class macro Dice',value=float(mean),SD=float(sd),unit='percentage points',reference='After minus previous decoder stage; paired whole-field context'))
 axb.axvline(0,color='#777777',lw=.65,ls=(0,(3,3)));axb.axhline(2,color='#DDE2E6',lw=.6);axb.set_yticks(ys,labels);axb.set_ylim(4.6,-.65);axb.set_xlim(-.5,3.65);axb.set_xticks([0,1,2,3]);axb.set_xlabel('Δ macro Dice (pp)',labelpad=4)
 axb.spines['left'].set_visible(False);axb.tick_params(axis='y',length=0,pad=4);axb.grid(axis='x',color='#EEF0F2',lw=.4);axb.set_axisbelow(True)
 # C: one 2x2 image montage, all dates share the exact original RGB crop.
 d=np.load(W/'Independent_Q1-2-B3_image_cache.npz');size=256;gap=14;header=32;tileh=size+header
 canvas=np.full((tileh*2+gap,size*2+gap,3),255,np.uint8)
 for i,t in enumerate(['T1','T2','T3','T4']):
  row,col=divmod(i,2);x=col*(size+gap);y=row*(tileh+gap);rgb=d[t+'_RGB'];pred=d[t+'_prediction'];overlay=rgb.copy();assert rgb.shape==(size,size,3)and pred.shape==(size,size)
  for code,cl in [(1,'existing'),(2,'new')]:
   mask=pred==code;c=np.array([int(colors[cl][j:j+2],16)for j in [1,3,5]]);overlay[mask]=np.rint(.92*c+.08*rgb[mask]).astype(np.uint8)
  overlay[pred==255]=np.rint(.75*np.array([205,205,205])+.25*rgb[pred==255]).astype(np.uint8)
  assert np.array_equal(overlay[pred==0],rgb[pred==0]);canvas[y+header:y+header+size,x:x+size]=overlay
  axc.text(x+size/2,y+header/2,t+' (baseline)'if t=='T1'else t,ha='center',va='center',fontsize=7.8,fontweight='bold')
 axc.imshow(canvas);axc.set_xlim(-.5,canvas.shape[1]-.5);axc.set_ylim(canvas.shape[0]-.5,-.5);axc.set_axis_off()
 # One native-pixel scale bar, rendered as vector marks over the first image.
 axc.plot([12,62],[header+size-16]*2,color='white',lw=2)
 axc.text(12,header+size-28,'50 px',color='black',fontsize=6.9,bbox=dict(facecolor='white',edgecolor='none',alpha=.9,pad=.9))
 fig.text(.846,.875,'Q1-2-B3 · same RGB field',fontsize=7.5,ha='center')
 fig.text(.846,.205,'Full head · GT pending',fontsize=7.3,ha='center')
 handles=[Line2D([],[],color=colors['new'],marker='o',lw=1.3,ms=4,label='New roots'),Line2D([],[],color=colors['existing'],marker='s',lw=1.3,ms=4,label='Existing roots')]
 fig.legend(handles=handles,loc='center',bbox_to_anchor=(.50,.143),ncol=2,frameon=False,prop={'size':8,'weight':'bold'},columnspacing=2.2,handlelength=1.8)
 fig.text(.022,.078,'Joint module = ConvLSTM + GAT. B: module and decoder effects use separate reference contexts; mean ± optimization SD.',fontsize=7)
 fig.text(.022,.038,'C: actual two-class prediction, not independent accuracy. Existing = persistent + extension; gray baseline roots are unassigned.',fontsize=7)
 fig.canvas.draw();renderer=fig.canvas.get_renderer();bad=[]
 for txt in fig.findobj(matplotlib.text.Text):
  if not txt.get_visible()or not txt.get_text():continue
  bb=txt.get_window_extent(renderer)
  if bb.x0<-.5 or bb.y0<-.5 or bb.x1>fig.bbox.width+.5 or bb.y1>fig.bbox.height+.5:bad.append(txt.get_text())
 assert not bad,('Text clipped',bad)
 for ext in ['png','jpg','pdf','svg','tif']:
  kwargs=dict(dpi=600,facecolor='white')
  if ext=='jpg':kwargs['pil_kwargs']=dict(quality=98,subsampling=0)
  if ext=='tif':kwargs['pil_kwargs']=dict(compression='tiff_lzw')
  fig.savefig(W/('V90_joint_module_ABC.'+ext),**kwargs)
 fig.savefig(W/'ABC_preview.png',dpi=200,facecolor='white');plt.close(fig)
 with(W/'ABC_plot_values.csv').open('w',encoding='utf-8-sig',newline='')as f:wr=csv.DictWriter(f,fieldnames=list(audit[0]));wr.writeheader();wr.writerows(audit)
 (W/'ABC_layout_and_checks.json').write_text(json.dumps(dict(three_horizontally_aligned_axes=True,panel_letters=['A','B','C'],figure_mm=[190,100],raster_dpi=600,
  font='Times New Roman, black',classes=['new','existing'],B_module_reference='Full minus ablated, partition-isolated',B_decoder_reference='Each step minus preceding step, separate paired whole-field context',
  C_source_position='Q1-2-B3',C_source_model='Retrained Full raw neural head',C_seed=20261123,C_crops_unchanged_from_previous_figures=True,
  independent_accuracy_computed=False,models_retrained=True,new_joint_ablation_runs=3,original_model_values_changed=False,joint_module='ConvLSTM + GAT',all_text_within_canvas=True),indent=2))
 print('COMPACT_ABC_FIGURE_COMPLETE',flush=True)
if __name__=='__main__':main()
