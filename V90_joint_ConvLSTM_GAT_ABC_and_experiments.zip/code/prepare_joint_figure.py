"""Re-evaluate a joint ConvLSTM+GAT ablation and update the compact ABC figure."""
from pathlib import Path
import csv,json,shutil,hashlib
import numpy as np
from PIL import Image
W=Path(__file__).resolve().parents[1]
S=Path('/workspace/work/V90_validation_20261123')
P=Path('/workspace/work/V90_ABC_compact_20261123')
F=W/'figure';F.mkdir(exist_ok=True)
SEEDS=[20261123,20261124,20261125]
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='')as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def metrics(cm):
 out=[]
 for k,name in enumerate(['existing','new']):
  tp=int(cm[k,k]);fp=int(cm[:,k].sum()-tp);fn=int(cm[k].sum()-tp)
  out.append(dict(class_name=name,TP=tp,FP=fp,FN=fn,support=tp+fn,Precision=tp/(tp+fp)if tp+fp else None,Recall=tp/(tp+fn)if tp+fn else None,Dice=2*tp/(2*tp+fp+fn),IoU=tp/(tp+fp+fn)))
 return out
def main():
 for name in ['Historical_two_class_references.csv','Paired_decoder_two_class.csv','Independent_Q1-2-B3_image_cache.npz','Independent_evaluation_status.json','Source_independent_examples.json']:
  shutil.copy2(P/name,F/name)
 classwise=read(P/'Internal_two_class_classwise.csv');effects=[];results=[];confusions={}
 membership=np.array([[1,0],[0,1],[1,0]],np.int64)
 for seed in SEEDS:
  folder=W/'experiments/no_temporal_relation'/str(seed)
  status=json.loads((folder/'status.json').read_text());assert status['stage']=='complete'and status['epochs_completed']==100
  result=json.loads((folder/'result.json').read_text());cm=np.array(result['test']['confusion']);recalculated=np.zeros((3,3),np.int64)
  for t in ['T2','T3','T4']:
   q=np.load(W/'data'/f'{t}_pixels.npz');valid=q['split']==2;raw=np.array(Image.open(folder/'predictions'/f'{t}_classes.png'));pred=raw.ravel()[q['pixel'][valid]];truth=q['target'][valid]
   assert np.isin(pred,[1,2,3]).all();recalculated+=np.bincount(truth*3+pred-1,minlength=9).reshape(3,3)
  assert np.array_equal(cm,recalculated)
  grouped=membership.T@cm@membership;assert grouped.sum()==83478
  rows=metrics(grouped);macro=float(np.mean([r['Dice']for r in rows]));macro_iou=float(np.mean([r['IoU']for r in rows]))
  for row in rows:classwise.append(dict(variant='no_temporal_relation',seed=seed,**row))
  full=[r for r in classwise if r['variant']=='full'and int(r['seed'])==seed]
  fullmacro=float(np.mean([float(r['Dice'])for r in full]));fulliou=float(np.mean([float(r['IoU'])for r in full]))
  effects.append(dict(module='ConvLSTM + GAT',ablated_variant='no_temporal_relation',seed=seed,delta_macro_Dice_pp=100*(fullmacro-macro),delta_macro_IoU_pp=100*(fulliou-macro_iou)))
  results.append(dict(variant='no_temporal_relation',seed=seed,selected_epoch=result['selected_epoch'],macro_Dice=macro,macro_IoU=macro_iou,existing_Dice=rows[0]['Dice'],new_Dice=rows[1]['Dice'],pixels=int(grouped.sum()),checkpoint_SHA256=hashlib.sha256((folder/'best.pt').read_bytes()).hexdigest()))
  confusions[str(seed)]={'three_class':cm.tolist(),'two_class':grouped.tolist()}
 gate=[r for r in read(P/'Paired_module_two_class_effects.csv')if r['module']=='Learned identity gates'];effects.extend(gate)
 write(F/'Internal_two_class_classwise.csv',classwise);write(F/'Paired_module_two_class_effects.csv',effects);write(W/'reports/Joint_module_two_class_runs.csv',results)
 (W/'reports/Joint_module_confusions.json').write_text(json.dumps(confusions,indent=2))
 script=(P/'make_ABC_compact.py').read_text()
 script=script.replace("('no_gat','No GAT')","('no_temporal_relation','w/o joint')").replace("['Frame-only','V66 prior','No GAT','Full']","['Frame-only','V66 prior','w/o joint','Full']")
 script=script.replace("[('ConvLSTM','+ LSTM'),('GAT','+ GAT'),('Learned identity gates','+ Gate')]","[('ConvLSTM + GAT','ConvLSTM\\n+ GAT'),('Learned identity gates','Gate')]")
 script=script.replace("[(4,'axis_constraints','raw_head','+ Axis'),(5,'axis_and_junction_constraints','axis_constraints','+ Junction')]","[(3,'axis_constraints','raw_head','+ Axis'),(4,'axis_and_junction_constraints','axis_constraints','+ Junction')]")
 script=script.replace("axb.axhline(3,","axb.axhline(2,").replace("axb.set_ylim(5.6,-.65)","axb.set_ylim(4.6,-.65)")
 script=script.replace("V90_two_class_ABC_compact.","V90_joint_module_ABC.")
 script=script.replace("A: internal root-pixel evaluation. B: module and decoder effects use separate reference contexts; mean ± optimization SD.","Joint module = ConvLSTM + GAT. B: module and decoder effects use separate reference contexts; mean ± optimization SD.")
 script=script.replace("models_retrained=False,source_values_changed=False","models_retrained=True,new_joint_ablation_runs=3,original_model_values_changed=False,joint_module='ConvLSTM + GAT'")
 (F/'make_ABC_joint_module.py').write_text(script)
 summary={'joint_module':'ConvLSTM + GAT','seeds':3,'updates_per_seed':100,'joint_ablation_macro_Dice_mean_pct':100*float(np.mean([r['macro_Dice']for r in results])),'joint_ablation_existing_Dice_mean_pct':100*float(np.mean([r['existing_Dice']for r in results])),'joint_ablation_new_Dice_mean_pct':100*float(np.mean([r['new_Dice']for r in results])),'paired_joint_effect_macro_Dice_pp_mean':float(np.mean([r['delta_macro_Dice_pp']for r in effects if r['module']=='ConvLSTM + GAT'])),'paired_joint_effect_macro_Dice_pp_SD':float(np.std([r['delta_macro_Dice_pp']for r in effects if r['module']=='ConvLSTM + GAT'],ddof=1)),'pixel_confusions_verified_against_saved_predictions':True,'original_full_checkpoints_unchanged':True,'C_predictions_unchanged':True}
 for seed,info in json.loads((W/'Joint_module_protocol.json').read_text())['full_comparators'].items():assert hashlib.sha256(Path(info['full_checkpoint']).read_bytes()).hexdigest()==info['sha256']
 (W/'reports/Joint_module_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
if __name__=='__main__':main()
