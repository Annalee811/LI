from pathlib import Path
import json,csv
W=Path(__file__).resolve().parents[1]
def main():
 s=json.loads((W/'reports/Joint_module_summary.json').read_text())
 caption='''Figure. Joint ConvLSTM-GAT module, structural decoding and independent-position prediction.

(A) Dice for new and existing roots from a frame-only negative control, a frozen historical V66 prior, the model without the joint ConvLSTM-GAT module, and the Full model. Existing roots are the pixel-level union of persistent and extending segments. Three newly trained joint-ablation runs were compared with the original three matched Full runs; training settings and checkpoint selection were retained. The historical V66 result is one reference, not three seed replicates. Error bars denote sample optimization SD, not biological variability. Scores cover 83,478 common held-out typed-root pixels within B3; background is not evaluated.

(B) The ConvLSTM-GAT module is treated as one component. Its effect is Full minus the model with both recurrent memory and both GAT layers removed. Gate is Full minus the model without learned attention-edge identity gating. Both comparisons are conditional on their specified component boundaries, not a sequence of additions; when GAT is removed its attention-edge gating also has no aggregation path, although the auxiliary connection head is retained. Removing the joint module retains the frame CNN, node encoder, frozen upstream priors, historical features and auxiliary heads. It therefore does not remove all temporal information. Axis and Junction denote paired increments from the raw head to axis decoding, and from axis decoding to axis-plus-junction decoding. Those two decoder rows use a separate whole-field inference context and must not be summed with neural-module effects. Values are changes in two-class macro Dice (percentage points), with paired optimization SD across three seeds.

(C) The same 256 x 256-pixel original RGB field in Q1-2-B3 at T1-T4, overlaid with unchanged predictions from the Full raw neural head, seed identifier 20261123. Gold: new roots; blue: existing roots; gray: baseline roots without a preceding observation and without an assigned temporal class. The bar is 50 native pixels. These predictions do not include the external axis/junction decoder. No human temporal ground truth is available at this position; independent accuracy is not estimated. There was prior unlabeled image exposure and a prepared feature adapter with documented approximations, so this is not prospective blind-image validation.

Reproducibility note. The three new ablation runs use 100 full-graph optimization updates each, sampling up to 8192 training pixels per update; this is not 100 full-data epochs. The original three-class training objective and validation macro-Dice checkpoint criterion are unchanged to match the existing Full comparator. Two-class metrics are recalculated by merging truth and prediction categories before scoring, not by averaging old category metrics. This is not new two-class-objective training. Current results concern conditional temporal classification, not full-background end-to-end segmentation or proof of correct root-instance attribution. Existing image files, labels, model weights and prior results were preserved.
'''
 (W/'figure/Figure_caption_EN.txt').write_text(caption)
 note=f'''联合模块定义：ConvLSTM + GAT

ConvLSTM负责跨时期特征记忆，GAT负责根段邻接关系的信息传播。两者作为一个联合模块进行主消融：同时移除循环记忆单元和两层GAT，其他可比输入、帧CNN、节点编码器、冻结先验、辅助任务及训练设置保留。不能将此前两个单独消融的差值相加来替代本次联合实验。

新实验：3个固定随机种子，每个100次整图优化，每步最多8192个训练根像素。沿用原三类训练目标及验证检查点标准，以保持与已有完整模型一致；展示指标将持续与延伸合并为既有根后，在真值和预测两侧重新计算。评估域为B3内部共同的83,478个已标注根像素，不含背景。

去掉联合模块后，新生根Dice均值为{s['joint_ablation_new_Dice_mean_pct']:.4f}%，既有根为{s['joint_ablation_existing_Dice_mean_pct']:.4f}%，两类宏平均为{s['joint_ablation_macro_Dice_mean_pct']:.4f}%。完整模型的相应指标约为81.6268%、96.7907%和89.2088%。联合模块的配对宏平均Dice效应为{s['paired_joint_effect_macro_Dice_pp_mean']:+.4f} ± {s['paired_joint_effect_macro_Dice_pp_SD']:.4f}个百分点（随机优化标准差）。不得把小幅变化写成显著提升；没有以独立生物学重复为单位的显著性证据。

ABC版式：A时序基线的两类Dice；B联合模块、门控与结构解码的关键配对效应；C独立管位的四期同视野原图叠加预测。B的神经模块与结构解码部分采用不同参考设置，不能相加。C保持原预测及原始RGB不变，尚无人工时序真值，不报告独立准确率。

结构边界说明：身份门控作用于GAT注意力边，移除GAT后该传播路径随之消失，辅助连接头仍保留。因此联合消融估计的是完整模块块级移除的效应，并不能精确分离模块内部每一种机制。单独门控消融是在联合模块存在的条件下进行的。
'''
 (W/'figure/联合模块说明与结果.txt').write_text(note)
 readme='''Joint ConvLSTM + GAT ablation and compact ABC figure
Date: 2026-11-23

The original study and original Full checkpoints remain unchanged.
Three actual joint-ablation runs were added in experiments/no_temporal_relation.
The prior single-component LSTM/GAT runs are preserved in the earlier release but are not shown as separate components in the revised compact plot.

Figure files: figure/V90_joint_module_ABC.{jpg,png,tif,pdf,svg}
Resolution: 190 x 100 mm, 600 dpi; Times New Roman, black text, white background.
Panel A: two-class Dice; B: joint-module and decoder effects; C: same-field T1-T4 RGB predictions.
Independent accuracy remains unavailable without human temporal ground truth.

Replot from the supplied CSVs and RGB/mask cache:
python figure/make_ABC_joint_module.py --fonts /path/to/fonts
Requires numpy, matplotlib, Times New Roman.ttf and Times New Roman Bold.ttf.
Font files are not redistributed.

code/study_model.py and code/train_study.py are the exact code used for the new training runs.
Training inputs are reused from /workspace/work/V90_validation_20261123/data; data is linked locally and is not duplicated in this figure/experiment supplement.
Original data, complete Full comparators and the broader study are available in the prior release referenced in Joint_module_protocol.json and the source release below. The training script retains original project asset paths, so this supplement alone is not a standalone raw-RGB deployment bundle.

Source figure release: https://github.com/Annalee811/LI/tree/c91f8c354a129338b69efb6d691d5a72fc726324
Source two-class study release: https://github.com/Annalee811/LI/tree/3839df9feaa49ecd30ffeec5f1d6593d205686d5
Source complete training study: https://github.com/Annalee811/LI/tree/4a4e61a9e14ece88f6c8ac5bb3bc044a9170a01e

Each new run includes weights, optimizer resume state, history, configuration and predictions. Reports verify source checkpoint preservation and confusion matrices against saved predictions. See English caption and Chinese notes for evaluation boundaries and limitations.
'''
 (W/'README.txt').write_text(readme)
 print(note)
if __name__=='__main__':main()
