"""Reuse immutable labeled inputs; derive structure supervision without pseudo-GT."""
from pathlib import Path
import numpy as np,json,hashlib,shutil,sys
W=Path(__file__).resolve().parents[1]
S=Path('/workspace/work/V90_validation_20261123')
A=Path('/workspace/work/V90_all_microtubes_20261118/model_source/assets')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 sys.path.insert(0,'/workspace/LI/analysis-scripts')
 from dataset_identity import require_active_position
 require_active_position('0353-2-B3')
 data=W/'data';data.mkdir(exist_ok=True);source_hashes={}
 for p in (S/'data').rglob('*'):
  if p.is_file():
   rel=p.relative_to(S/'data');dest=data/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);source_hashes[str(p)]=sha(p)
 g=dict(np.load(data/'graph.npz'));original=dict(np.load(A/'local/data/unet/graph.npz'));N=len(g['x']);rid=original['root_target'][g['old_node_ids']].copy();parts=g['part'];hist=np.zeros((N,2),np.int64);total=np.zeros(N,np.int64);agree=np.zeros(N,np.int64)
 for t in ['T2','T3','T4']:
  p=np.load(data/f'{t}_pixels.npz');y=(p['target']==1).astype(np.int64)
  for k in [0,1]:np.add.at(hist[:,k],p['node'][y==k],1)
  known=p['rid']>=0;np.add.at(total,p['node'][known],1);same=known&(p['rid']==rid[p['node']]);np.add.at(agree,p['node'][same],1)
 # Identity supervision is withheld where released node IDs conflict with pixel IDs.
 compatible=(rid>=0)&((total==0)|(agree>=.95*total));rid[~compatible]=-1
 nclass=np.argmax(hist,axis=1);purity=hist.max(1)/hist.sum(1).clip(1);node_ok=(hist.sum(1)>=4)&(purity>=.95)
 # Derive within-period root groups only. Birth -> established across periods is allowed.
 nodes=[];ptr=[0];labels=[];split=[];keys=[]
 for part in [0,1,2]:
  for phase in range(1,4):
   ids=np.flatnonzero((parts==part)&(g['phase']==phase)&node_ok&(rid>=0))
   for root in np.unique(rid[ids]):
    ix=ids[rid[ids]==root];h=hist[ix].sum(0)
    if len(ix)<2 or h.max()<.95*h.sum():continue
    nodes.extend(ix.tolist());ptr.append(len(nodes));labels.append(int(h.argmax()));split.append(part);keys.append([part,phase,int(root)])
 # A temporal no-rebirth target is imposed only where the actual class annotations support it.
 keymap={tuple(k):i for i,k in enumerate(keys)};temporal=[]
 for i,(part,phase,root)in enumerate(keys):
  previous=keymap.get((part,phase-1,root))
  if previous is not None and labels[i]==0:temporal.append([previous,i])
 a,b=g['pairs'].T;edge_known=(rid[a]>=0)&(rid[b]>=0);edge_y=np.where(edge_known,(rid[a]==rid[b]).astype(np.int64),-1);edge_split=np.where(edge_known,parts[a],-1)
 assert np.all(parts[a]==parts[b]);samephase=g['phase'][a]==g['phase'][b]
 np.savez_compressed(data/'structural_targets.npz',node_rid=rid,node_class=nclass,node_class_valid=node_ok,node_purity=purity,
  edge_target=edge_y,edge_split=edge_split,same_phase=samephase,axis_nodes=np.array(nodes,np.int64),axis_ptr=np.array(ptr,np.int64),axis_class=np.array(labels,np.int64),axis_split=np.array(split,np.int64),axis_keys=np.array(keys,np.int64),temporal_pairs=np.array(temporal,np.int64).reshape(-1,2))
 # Junction geometry and candidate options are model inputs; targets remain separate.
 j=dict(np.load(data/'junctions.npz'));groups=json.loads((data/'junction_groups.json').read_text());max_options=max(len(v['options'])for v in groups);max_pairs=max(len(o)for v in groups for o in v['options']);idx=np.zeros((len(groups),max_options,max_pairs),np.int64);mask=np.zeros(idx.shape,np.float32);arm_split=np.full(len(j['ptr'])-1,-1,np.int64)
 for arm in range(len(arm_split)):
  ni=j['nodes'][j['ptr'][arm]:j['ptr'][arm+1]];assert len(np.unique(parts[ni]))==1;arm_split[arm]=parts[ni][0]
 for gi,group in enumerate(groups):
  for oi,option in enumerate(group['options']):
   for pi,(u,v)in enumerate(option):idx[gi,oi,pi]=group['pair_indices'][str(u)+','+str(v)];mask[gi,oi,pi]=1
 np.savez_compressed(data/'junction_options.npz',index=idx,mask=mask,split=np.array([v['split']for v in groups],np.int64),target=np.array([v['target_option']for v in groups],np.int64),arm_split=arm_split)
 shutil.copy2(S/'reports/data_audit.json',W/'reports/original_data_audit.json')
 audit={'position':'0353-2-B3','foreground_conditioned':True,'class_map':{'existing':[1,3],'new':[2]},'nodes':N,'node_identity_conflicts_excluded':int(((original['root_target'][g['old_node_ids']]>=0)&~compatible).sum()),'known_identity_edges':int(edge_known.sum()),'identity_edges_by_split':{str(k):int((edge_split==k).sum())for k in [0,1,2]},'axes_by_split':{str(k):int((np.array(split)==k).sum())for k in [0,1,2]},'junction_groups_by_split':{str(k):sum(v['split']==k for v in groups)for k in [0,1,2]},'no_rebirth_pairs':len(temporal),'normalization_train_only':True,'nodes_or_edges_cross_partitions':False,'class_truth':'Unchanged original current-reference class masks; grouped at loading','identity_truth':'Released manual root identities; conflicting/unknown node identities excluded from new axis supervision','junction_truth':'Unchanged released manually supervised candidate options','human_annotations_modified':False,'pseudo_labels_used':False,'independent_GT':False,'upstream_prior_historical_B3_exposure':True,'source_hashes':source_hashes}
 (W/'reports/data_audit.json').write_text(json.dumps(audit,indent=2))
 print(json.dumps({k:v for k,v in audit.items()if k!='source_hashes'},indent=2),flush=True)
if __name__=='__main__':main()
