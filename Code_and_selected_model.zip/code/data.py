from pathlib import Path
import numpy as np,torch
def load(work):
 work=Path(work);g=dict(np.load(work/'data/graph.npz'))
 d={k:torch.from_numpy(g[k])for k in ['x','extra','pairs','attrs','phase','centers','part','frames','partition_frame_masks']};d.update(native_width=2541,native_height=1108)
 # Only geometry, graph membership and candidate options enter the model.
 rawj=dict(np.load(work/'data/junctions.npz'));j={k:torch.from_numpy(rawj[k])for k in ['nodes','ptr','a','b','fixed']}
 rawo=dict(np.load(work/'data/junction_options.npz'));o={k:torch.from_numpy(rawo[k])for k in ['index','mask']}
 target={k:torch.from_numpy(v)for k,v in dict(np.load(work/'data/structural_targets.npz')).items()}
 target.update(junction_target=torch.from_numpy(rawj['target']),junction_split=torch.from_numpy(rawj['split']),option_target=torch.from_numpy(rawo['target']),option_split=torch.from_numpy(rawo['split']))
 pixels={t:dict(np.load(work/'data'/f'{t}_pixels.npz'))for t in ['T2','T3','T4']};allp={k:torch.from_numpy(np.concatenate([v[k]for v in pixels.values()]))for k in ['node','pf','target','split']};allp['target']=(allp['target']==1).long()
 return g,d,j,o,target,pixels,allp
