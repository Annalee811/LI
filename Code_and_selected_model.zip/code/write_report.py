from pathlib import Path
import csv,json
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.oxml.ns import qn
W=Path(__file__).resolve().parents[1]
def read(name):return list(csv.DictReader((W/'reports'/name).open(encoding='utf-8-sig')))
def main():
 summary=read('Mean_SD_metrics.csv');by={r['variant']:r for r in summary};f=by['joint_full'];b=by['neural_only'];paired=read('Paired_effects.csv');delta=np.array([float(r['macro_Dice_delta_pp'])for r in paired if r['reference']=='neural_only']);mean=lambda k:100*float(f[k+'_mean']);sd=lambda k:100*float(f[k+'_SD'])
 selection=json.loads((W/'selected_model/Selection.json').read_text())
 paragraphs=[
 'V90联合结构学习版：重新训练与内部评价',
 '本次将ConvLSTM＋GAT（内部使用Gate）、可微根轴细化、可微交叉配对细化及两类预测头放入同一个训练计算图。输出头实际包含既有根与新生根两个通道；既有根训练标签由原持续根和原根轴延伸段合并。上游U-Net根区和冻结V66时序先验复用，未重新训练，因此本次是时序结构网络的联合训练，不表述为从原始RGB起重新训练全部上游模型。',
 'Axis细化使用学习式身份关联分数，在同一时期节点间进行两轮加权特征传播；Junction细化将候选连接方案的softmax概率转换为软配对边，并把配对信息传回节点特征。最终类别直接由网络预测，不运行旧Axis/Junction类别修正规则。仅使用分类交叉熵即可对ConvLSTM、GAT及两个结构细化模块产生非零梯度，详见Implementation_checks.json。模型前向接口不接收类别真值、人工根ID或目标配对方案。',
 '训练使用B3现有冻结特征与人工监督，不重新配准或改变原标注。14,915个划分纯净节点中，训练/验证/内部测试分别为10,710、980和3,225个；跨划分图边移除，帧上下文分别遮罩，新增归一化仅由训练节点拟合。30个像素身份与节点身份不一致的节点仅从新增根轴监督中排除，原始文件不变。根轴损失只在同一时期同一人工根ID的类别一致节点组上施加；跨期项在标签支持时抑制重复出生，不强迫同一根跨期一直保持新生。交叉监督来自已有人工配对方案。',
 '四种配置为完整联合模型、普通网络对照、移除可学习Axis细化、移除可学习Junction细化；各用三个固定优化种子，共12组。每组100次整图优化更新，每次抽取最多8,192个训练根像素，这不是100轮完整像素遍历。各配置初始参数、划分和采样规则匹配。AdamW初始学习率3×10⁻⁴、权重衰减10⁻⁴、余弦学习率下限10⁻⁶、梯度范数上限5，CPU运行。检查点及完整模型部署种子仅按两类验证宏平均Dice选择。',
 '实际损失：L = L_CE + 0.5 L_Dice + 0.15 L_node + 0.1 L_identity + 0.1 L_pair + 0.1 L_option + 0.2 L_axis + 0.1 L_junction-state。Axis项包含根组状态、组内一致性、标签支持的跨期状态约束及身份嵌入对比项。普通网络对照保留共同身份和配对辅助监督，关闭结构细化及对应额外一致性项。两种消融分别关闭对应细化与一致性项，因此效应包含路径及相应损失的变化。不同配置总损失绝对值不宜直接比较。',
 '类别测试限定于T2—T4共同的83,478个已标注根像素，其中既有根70,907个、新生根12,571个，背景不参与。结构测试包含10,818个有效身份候选边、142个交叉配对事件及140个类别一致根组。全部来自B3，且冻结先验存在历史B3暴露，属于内部条件分类评价，不是独立微根管泛化准确率。低置信度预测未从类别计分中移除。',
 f"完整模型宏平均Dice为{mean('macro_Dice'):.2f} ± {sd('macro_Dice'):.2f}%，新生根Dice为{mean('new_Dice'):.2f} ± {sd('new_Dice'):.2f}%，既有根Dice为{mean('existing_Dice'):.2f} ± {sd('existing_Dice'):.2f}%。新生根精确率为{mean('new_Precision'):.2f}%，召回率为{mean('new_Recall'):.2f}%。标准差来自三次优化，不是生物学独立重复的置信区间。",
 f"普通网络对照宏平均Dice为{100*float(b['macro_Dice_mean']):.2f}%。完整模型减去对照的配对变化为{delta.mean():+.3f} ± {delta.std(ddof=1):.3f}个百分点。"+('本轮未显示完整模型在两类Dice上优于对照。'if delta.mean()<=0 else'本轮观察到正向平均变化，但不据此宣称显著性或独立泛化提升。'),
 f"完整模型身份关联F1为{mean('identity_link_F1'):.2f}%，交叉配对准确率为{mean('junction_accuracy'):.2f}%。这些分数不能证明完整根实例身份已完全正确，仍可能存在断裂、错误连接和不确定归属。",
 ]
 for variant,label in [('without_axis','移除可学习Axis细化'),('without_junction','移除可学习Junction细化')]:
  difference=np.array([float(r['macro_Dice_delta_pp'])for r in paired if r['reference']==variant]);paragraphs.append(f"{label}的宏平均Dice为{100*float(by[variant]['macro_Dice_mean']):.2f}%；完整模型相对它的配对变化为{difference.mean():+.3f} ± {difference.std(ddof=1):.3f}个百分点。")
 diagnostic=read('Identity_edge_diagnostics.csv');dr=[r for r in diagnostic if r['variant']=='joint_full'];value=lambda key:100*np.mean([float(r[key])for r in dr])
 paragraphs.append(f"身份候选边的同根正类占{value('positive_fraction'):.2f}%；将全部候选边均连为同根的参考F1为{value('all_linked_F1'):.2f}%，因此不能仅凭身份F1认定模型具有优势。完整模型的身份关联精确率、召回率和平衡准确率分别为{value('Precision'):.2f}%、{value('Recall'):.2f}%和{value('balanced_accuracy'):.2f}%。平衡准确率同时考虑同根与异根，常量预测的该指标为50%。根轴状态准确率衡量类别状态，不等同于根实例归属准确率。")
 paragraphs.extend([f"选定完整模型权重来自种子{selection['seed']}，验证宏平均Dice为{selection['validation_macro_Dice']*100:.2f}%。它是完整模型架构内的验证最优检查点，不是依测试结果选出的全配置最优模型。",'18个位置、66幅影像的输入准备与批量预测按用户要求暂停。已生成缓存及部分预测在本地保留，不纳入本次训练交付；本次仅交付模型训练、B3内部评价和可视化。其他微根管缺少人工时序真值，不计算独立准确率，也不自动恢复批量预测。','结论：本轮完成了结构约束参与梯度更新的真实两类联合训练。是否带来性能收益以对照和消融的实际结果为准，旧规则后处理的提升不能作为本次训练效果。'])
 (W/'reports/Training_results_CN.txt').write_text('\n\n'.join(paragraphs))
 english=f'''Jointly learned two-class temporal root model. The upstream segmentation and temporal priors are frozen. Differentiable axis propagation and soft junction matching are optimized jointly with the ConvLSTM/GAT backbone and two-channel classifier. No legacy Axis/Junction class-repainting rules are used. Four matched variants x three seeds x 100 full-graph updates; up to 8192 training pixels/update. AdamW lr 3e-4, weight decay 1e-4, cosine minimum 1e-6, gradient clipping 5. Checkpoint selection: two-class validation macro Dice only. Evaluation: 83478 eligible held-out typed-root pixels inside B3; background excluded; frozen upstream features have historical B3 exposure. Full macro Dice {mean('macro_Dice'):.4f} ± {sd('macro_Dice'):.4f}%; new Dice {mean('new_Dice'):.4f}%; existing Dice {mean('existing_Dice'):.4f}%. Paired Full minus neural baseline macro Dice {delta.mean():+.4f} ± {delta.std(ddof=1):.4f} percentage points. Identity-link F1 {mean('identity_link_F1'):.4f}%; junction assignment accuracy {mean('junction_accuracy'):.4f}%. SD describes optimization variability, not biological replication. Independent batch prediction is paused at the user's request. No independent accuracy is available. This is not evidence of perfect biological instance attribution.'''
 english+=f"\nIdentity-edge prevalence is {value('positive_fraction'):.4f}%; an all-linked reference has F1 {value('all_linked_F1'):.4f}%. Full-model mean identity precision/recall/balanced accuracy are {value('Precision'):.4f}% / {value('Recall'):.4f}% / {value('balanced_accuracy'):.4f}%. Constant predictions have 50% balanced accuracy. Axis-state accuracy is not biological instance-attribution accuracy.\n"
 (W/'reports/Methods_results_EN.txt').write_text(english)
 wb=Workbook();wb.remove(wb.active)
 for name,title in [('Per_run_metrics.csv','Runs'),('Mean_SD_metrics.csv','Mean_SD'),('Paired_effects.csv','Paired_effects'),('Per_class_metrics.csv','Class_confusions'),('Identity_edge_diagnostics.csv','Identity_diagnostics')]:
  rr=read(name);ws=wb.create_sheet(title);keys=list(rr[0]);ws.append(keys)
  for row in rr:
   values=[]
   for key in keys:
    value=row[key]
    try:value=float(value)if any(v in value for v in '.eE')else int(value)
    except(ValueError,TypeError):pass
    values.append(value)
   ws.append(values)
  ws.freeze_panes='C2';ws.auto_filter.ref=ws.dimensions
  for row in ws:
   for cell in row:cell.font=Font(name='Times New Roman',size=11,bold=cell.row==1,color='000000')
  for cell in ws[1]:cell.fill=PatternFill('solid',fgColor='EEF1F3')
  from openpyxl.utils import get_column_letter
  for i,key in enumerate(keys,1):
   ws.column_dimensions[get_column_letter(i)].width=25
   if any(v in key for v in ['Dice','IoU','Precision','Recall','F1','accuracy']):
    for cell in ws[get_column_letter(i)][1:]:cell.number_format='0.000'if key.endswith('_pp')else'0.00%'
 wb.save(W/'reports/Joint_training_metrics.xlsx')
 doc=Document();section=doc.sections[0];section.left_margin=section.right_margin=Cm(1.8);style=doc.styles['Normal'];style.font.name='Times New Roman';style.font.size=Pt(10.5);style.font.color.rgb=RGBColor(0,0,0);style.element.rPr.rFonts.set(qn('w:eastAsia'),'宋体')
 for paragraph in paragraphs:doc.add_paragraph(paragraph)
 doc.add_picture(str(W/'figures/Joint_learned_structure_ABC.jpg'),width=Cm(17.2));doc.add_paragraph('A两类Dice；B结构指标；C验证学习曲线。均值与标准差来自三个优化随机种子。');doc.save(W/'reports/Joint_training_report.docx')
 print('TRAINING_REPORTS_COMPLETE',flush=True)
if __name__=='__main__':main()
