"""Variable-graph deployment. Forward accepts only prepared RGB-derived inputs."""
from pathlib import Path
import argparse,json,pickle,hashlib,csv,time
import numpy as np,torch
from PIL import Image
from model import JointRootNet
from geometry_output import TrackRenderer
def load_inputs(folder):
 folder=Path(folder);meta=json.loads((folder/'complete.json').read_text());g=dict(np.load(folder/'graph_inputs.npz'));d={k:torch.from_numpy(v)for k,v in g.items()};d.update(part=torch.zeros(len(g['x']),dtype=torch.int64),partition_frame_masks=torch.ones((1,*g['frames'].shape[-2:])),native_width=meta['native_width'],native_height=meta['native_height'])
 raw=dict(np.load(folder/'junction_inputs.npz'));j={k:torch.from_numpy(raw[k])for k in ['nodes','ptr','a','b','fixed']};o={k:torch.from_numpy(raw[k])for k in ['index','mask']};return meta,g,d,j,o
def predict(checkpoint,folder,output):
 checkpoint=Path(checkpoint);folder=Path(folder);output=Path(output);output.mkdir(parents=True,exist_ok=True);ck=torch.load(checkpoint,map_location='cpu',weights_only=False);model=JointRootNet(ck['config']['variant']);model.load_state_dict(ck['model']);model.eval();meta,g,d,j,o=load_inputs(folder);start=time.monotonic()
 with torch.inference_mode():result=model(d,j,o)
 arrays={k:v.numpy()for k,v in result.items()if k in ['node_logits','link_logits','option_logits','pair_logits']};np.savez_compressed(output/'learned_structure_scores.npz',**arrays)
 geometry=pickle.load(open(folder/'geometry.pkl','rb'));owners=dict(np.load(folder/'geometry_ownership.npz'));renderer=TrackRenderer(g,geometry,owners,arrays);artifacts=[]
 for ti,t in enumerate(meta['periods']):
  q=dict(np.load(folder/f'{t}_pixels.npz'));shape=tuple(q['shape']);mask=np.zeros(shape,np.uint8);confidence=np.zeros(shape,np.float16)
  if ti==0:mask.ravel()[q['pixel']]=255
  else:
   with torch.inference_mode():
    for k in range(0,len(q['node']),32768):
     sl=slice(k,k+32768);p=model.pixel_logits(result,torch.from_numpy(q['node'][sl]),torch.from_numpy(q['pf'][sl])).softmax(-1).numpy();mask.ravel()[q['pixel'][sl]]=p.argmax(1).astype(np.uint8)+1;confidence.ravel()[q['pixel'][sl]]=p.max(1).astype(np.float16)
  foreground=np.zeros(shape,bool);foreground.ravel()[q['pixel']]=True;assert np.array_equal(mask>0,foreground)
  axis,track,uncertain,records=renderer.render(t,ti,foreground);uncertain|=(foreground&(confidence<.75))if ti else False
  Image.fromarray(mask).save(output/f'{t}_two_classes.png');Image.fromarray(axis.astype(np.int32)).save(output/f'{t}_axis_ids.tif',compression='tiff_lzw');Image.fromarray(track.astype(np.int32)).save(output/f'{t}_root_track_ids.tif',compression='tiff_lzw');Image.fromarray(uncertain.astype(np.uint8)*255).save(output/f'{t}_uncertainty.png');np.savez_compressed(output/f'{t}_confidence.npz',confidence=confidence)
  rgbpath=Path(meta['RGB_root'])/f'{t}_RGB.png';rgb=np.array(Image.open(rgbpath).convert('RGB'));assert rgb.shape[:2]==shape;overlay=rgb.copy()
  for code,color in [(1,[63,112,145]),(2,[197,141,49]),(255,[205,205,205])]:
   take=mask==code;overlay[take]=np.rint(.9*np.array(color)+.1*rgb[take]).astype(np.uint8)
  assert np.array_equal(overlay[~foreground],rgb[~foreground]);Image.fromarray(overlay).save(output/f'{t}_RGB_overlay.png',compress_level=4);Image.fromarray(overlay).save(output/f'{t}_RGB_overlay.jpg',quality=95,subsampling=0)
  artifacts.append({'position':meta['position'],'period':t,'baseline':ti==0,'foreground_pixels':int(foreground.sum()),'new_pixels':int((mask==2).sum())if ti else None,'existing_pixels':int((mask==1).sum())if ti else None,'uncertain_pixels':int((foreground&uncertain).sum()),'RGB_SHA256':hashlib.sha256(rgbpath.read_bytes()).hexdigest(),'coarse_registration':meta['coarse_registration'],'accuracy':None,'predictions_changed_by_geometry_rendering':False})
 if renderer.rows:
  with(output/'Root_axis_tracks.csv').open('w',encoding='utf-8-sig',newline='')as f:w=csv.DictWriter(f,fieldnames=list(renderer.rows[0]));w.writeheader();w.writerows(renderer.rows)
 report={'position':meta['position'],'periods':meta['periods'],'checkpoint_SHA256':hashlib.sha256(checkpoint.read_bytes()).hexdigest(),'seed':ck['config']['seed'],'model_variant':ck['config']['variant'],'node_count':len(g['x']),'prediction_records':artifacts,'no_manual_targets_used_at_prediction':True,'fixed_legacy_Axis_or_Junction_class_rewriting':False,'discrete_ID_rendering':'Only learned option/link scores; one-to-one temporal assignment; ambiguous instance ownership flagged separately; no class repainting','ID_thresholds':{'option':.7,'temporal':.75,'temporal_margin':.1},'missing_periods_filled':False,'seconds':time.monotonic()-start,'independent_accuracy':None,'adapter_notes':meta['known_adapter_approximations']}
 (output/'Prediction_provenance.json').write_text(json.dumps(report,indent=2));print('PREDICTED',meta['position'],len(meta['periods']),len(g['x']),round(report['seconds'],1),flush=True);return report
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--checkpoint',type=Path,required=True);ap.add_argument('--input',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1);predict(a.checkpoint,a.input,a.output)
if __name__=='__main__':main()
