"""Prepare arbitrary-size, label-free graph inputs from the existing RGB adapter.

No new registration, segmentation, manual annotation or old-output modification.
"""
from pathlib import Path
import csv,json,pickle,hashlib,sys
import numpy as np
from scipy import ndimage as ndi
from PIL import Image
W=Path(__file__).resolve().parents[1]
OLD=Path('/workspace/work/V90_all_microtubes_20261118')
def cue(mask):
 from skimage.morphology import skeletonize
 sk=skeletonize(mask);degree=ndi.convolve(sk.astype(np.uint8),np.ones((3,3),np.uint8),mode='constant')-sk
 def f(p):return np.exp(-ndi.distance_transform_edt(~p)**2/128).astype(np.float32)if p.any()else np.zeros(mask.shape,np.float32)
 return f(sk&(degree==1)),f(sk&(degree>=3))
def prepare(position,periods):
 out=W/'prepared_inputs'/position;out.mkdir(parents=True,exist_ok=True)
 if(out/'complete.json').exists():return json.loads((out/'complete.json').read_text())
 src=OLD/'model_source/assets'if position=='0353-2-B3'else OLD/'transfer_candidates'/position
 g=dict(np.load(src/'local/data/unet/graph.npz'));extra=np.load(src/'local/data/unet/extra.npz')['geometry'];frames=np.load(src/'local/data/unet/frames.npz')['frames'].astype(np.float32);owners=dict(np.load(src/'local/data/unet/ownership.npz'));norm=np.load(W/'data/train_only_normalization.npz');meta=json.loads((OLD/'transfer_candidates'/position/'adapter_provenance.json').read_text())
 assert frames.shape[0]==len(periods)and g['phase'].max()<len(periods)
 np.savez_compressed(out/'graph_inputs.npz',x=((g['x']-norm['x_mean'])/norm['x_std']).astype(np.float32),extra=((extra-norm['geometry_mean'])/norm['geometry_std']).astype(np.float32),pairs=g['pairs'],attrs=g['attrs'],phase=g['phase'],centers=g['centers'].astype(np.float32),frames=frames)
 top=pickle.load(open(src/'joint/data/topology.pkl','rb'));pd=np.load(src/'joint/data/pairs.npz');jnorm=np.load(W/'data/junctions.npz');nodes=[];ptr=[0];aa=np.zeros(len(pd['raw']),np.int64);bb=aa.copy();groups=top['groups'];lookup={(q['period'],q['hub']):q for q in groups}
 for t,items in top['arms'].items():
  for hub,arms in items:
   group=lookup.get((t,hub))
   if group is None:continue
   ids=[]
   for arm in arms:ids.append(len(ptr)-1);nodes.extend(arm['nodes']);ptr.append(len(nodes))
   for key,k in group['pair_indices'].items():a,b=map(int,key.split(','));aa[k]=ids[a];bb[k]=ids[b]
 index=np.zeros((len(groups),3,2),np.int64);mask=np.zeros(index.shape,np.float32)
 for gi,group in enumerate(groups):
  for oi,option in enumerate(group['options']):
   for pi,(a,b)in enumerate(option):index[gi,oi,pi]=group['pair_indices'][str(a)+','+str(b)];mask[gi,oi,pi]=1
 fixed=((pd['raw'][:,96:]-jnorm['fixed_mean'])/jnorm['fixed_std']).astype(np.float32)
 np.savez_compressed(out/'junction_inputs.npz',nodes=np.array(nodes,np.int64),ptr=np.array(ptr,np.int64),a=aa,b=bb,fixed=fixed,index=index,mask=mask)
 clean_groups=[{k:v for k,v in q.items()if k in ['period','hub','options','pair_indices']}for q in groups]
 with(out/'geometry.pkl').open('wb')as f:pickle.dump({'topos':top['topos'],'groups':clean_groups},f)
 np.savez_compressed(out/'geometry_ownership.npz',**owners)
 previous=None
 for t in periods:
  rgbpath=src/f'base/data/upper/{t}_RGB.png';rgb=np.array(Image.open(rgbpath).convert('RGB')).astype(np.float32)/255;foreground=np.array(Image.open(src/f'base/unet/full/{t}_classes.png'))>0;end,junction=cue(foreground)
  if position=='0353-2-B3':
   old=np.load(src/f'local/data/unet/{t}_pixels.npz');q={k:old[k]for k in ['pixel','node','pf']};q['shape']=np.array(foreground.shape)
  else:
   y,x=np.where(foreground);node=owners[t][y,x];center=g['centers'][node];prob=np.load(OLD/'inputs_t045'/position/f'{t}_prior_probability.npz')['probability'].astype(np.float32);delta=np.zeros_like(rgb)if previous is None else rgb-previous[0];distance=np.zeros(foreground.shape,np.float32)if previous is None else ndi.distance_transform_edt(~previous[1]).astype(np.float32)/32;previous_end=end if previous is None else previous[2]
   features=np.c_[np.log(prob[:,y,x].T.clip(1e-6)),(x-center[:,0])/12,(y-center[:,1])/12,rgb[y,x],delta[y,x],np.minimum(distance[y,x],1),previous_end[y,x],end[y,x],junction[y,x]].astype(np.float32);q={'pixel':y*foreground.shape[1]+x,'node':node,'pf':features,'shape':np.array(foreground.shape)}
  np.savez_compressed(out/f'{t}_pixels.npz',**q);previous=(rgb,foreground,end)
 report={'position':position,'periods':periods,'nodes':len(g['x']),'edges':len(g['pairs']),'junction_groups':len(groups),'native_width':meta['native_width'],'native_height':meta['native_height'],'RGB_root':str(src/'base/data/upper'),'no_manual_targets_in_prepared_inputs':True,'observed_dates_only':True,'coarse_registration':position=='Q1-1-Z2','adapter_exact_training_geometry':position=='0353-2-B3','known_adapter_approximations':[]if position=='0353-2-B3'else meta['known_departures'],'source_kind':'Existing original B3 model inputs'if position=='0353-2-B3'else'Existing frozen transfer graph adapter'}
 (out/'complete.json').write_text(json.dumps(report,indent=2));return report
def main():
 if(W/'BATCH_PREDICTION_PAUSED.json').exists():
  print('PAUSED_BY_USER: no further multi-position input preparation.',flush=True);return
 sys.path.insert(0,'/workspace/LI/analysis-scripts');from dataset_identity import require_active_position
 rows=list(csv.DictReader(open('/workspace/LI/dataset/current/active_images.csv',encoding='utf-8-sig')));positions=list(dict.fromkeys(r['position_id']for r in rows));done=[]
 for pos in positions:
  require_active_position(pos);periods=[r['period']for r in rows if r['position_id']==pos];report=prepare(pos,periods);done.append(report);(W/'reports/Prepared_input_index.json').write_text(json.dumps(done,indent=2));print('PREPARED',pos,len(periods),report['nodes'],flush=True)
 print('ALL_INPUTS_PREPARED',len(done),sum(len(v['periods'])for v in done),flush=True)
if __name__=='__main__':main()
