from pathlib import Path
import json,shutil,torch
from predict import predict
W=Path(__file__).resolve().parents[1]
def main():
 if(W/'BATCH_PREDICTION_PAUSED.json').exists():
  print('PAUSED_BY_USER: no multi-position batch prediction.',flush=True);return
 torch.set_num_threads(1);torch.set_num_interop_threads(1);seeds=[20261124,20261125,20261126];candidates=[]
 for seed in seeds:
  folder=W/'experiments/joint_full'/str(seed);status=json.loads((folder/'status.json').read_text());assert status['stage']=='complete';ck=torch.load(folder/'best.pt',weights_only=False,map_location='cpu');candidates.append((ck['validation']['macro_Dice'],seed,folder/'best.pt'))
 val,seed,path=max(candidates,key=lambda v:(v[0],-v[1]));selected=W/'selected_model';selected.mkdir(exist_ok=True);shutil.copy2(path,selected/'best.pt');(selected/'Selection.json').write_text(json.dumps({'seed':seed,'validation_macro_Dice':val,'selection':'Highest two-class validation macro Dice among prespecified full-model seeds; no test scores used','source':str(path),'fixed_rule_decoding':False},indent=2));print('SELECTED',seed,val,flush=True)
 index=json.loads((W/'reports/Prepared_input_index.json').read_text());done=[]
 for item in index:
  pos=item['position'];output=W/'predictions'/pos
  if(output/'Prediction_provenance.json').exists():report=json.loads((output/'Prediction_provenance.json').read_text())
  else:report=predict(selected/'best.pt',W/'prepared_inputs'/pos,output)
  done.append(report);(W/'reports/Prediction_index.json').write_text(json.dumps(done,indent=2))
 report={'positions':len(done),'frames':sum(len(r['periods'])for r in done),'selected_seed':seed,'upstream_segmentation_reused':True,'network_forward_on_every_position':True,'fixed_legacy_class_rules':False,'manual_truth_at_inference':False,'independent_accuracy':None}
 (W/'PREDICTIONS_COMPLETE.json').write_text(json.dumps(report,indent=2));print('ALL_PREDICTIONS_COMPLETE',report,flush=True)
if __name__=='__main__':main()
