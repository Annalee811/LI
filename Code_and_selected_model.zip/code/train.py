from pathlib import Path
import argparse,csv,hashlib,json,random,time
import numpy as np,torch
from model import initialize,VARIANTS
from data import load
from losses import compute
from backbone import pool
W=Path(__file__).resolve().parents[1]
def js(p,v):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(v,indent=2,allow_nan=False));q.replace(p)
def save(p,v):q=p.with_suffix('.tmp');torch.save(v,q);q.replace(p)
def csvwrite(p,rows):
 q=p.with_suffix('.tmp')
 with q.open('w',encoding='utf-8-sig',newline='')as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 q.replace(p)
def metrics(cm):
 rows=[]
 for k,name in enumerate(['existing','new']):
  tp=int(cm[k,k]);fp=int(cm[:,k].sum()-tp);fn=int(cm[k].sum()-tp)
  rows.append(dict(class_name=name,TP=tp,FP=fp,FN=fn,support=tp+fn,Precision=tp/(tp+fp)if tp+fp else None,Recall=tp/(tp+fn)if tp+fn else None,Dice=2*tp/(2*tp+fp+fn)if 2*tp+fp+fn else None,IoU=tp/(tp+fp+fn)if tp+fp+fn else None))
 return dict(classes=rows,macro_Dice=float(np.mean([r['Dice']for r in rows])),macro_IoU=float(np.mean([r['IoU']for r in rows])),confusion=cm.tolist(),pixels=int(cm.sum()))
def evaluate(model,result,pixels,split,targets,d):
 cm=np.zeros((2,2),np.int64)
 for t,q in pixels.items():
  ids=np.flatnonzero(q['split']==split)
  for start in range(0,len(ids),32768):
   ix=ids[start:start+32768];pred=model.pixel_logits(result,torch.from_numpy(q['node'][ix]),torch.from_numpy(q['pf'][ix])).argmax(1).numpy();truth=(q['target'][ix]==1).astype(np.int64);cm+=np.bincount(2*truth+pred,minlength=4).reshape(2,2)
 out=metrics(cm);known=targets['edge_split']==split;pr=result['link_logits'][known].sigmoid().numpy()>=.5;gt=targets['edge_target'][known].numpy()>0;tp=int((pr & gt).sum());fp=int((pr & ~gt).sum());fn=int((~pr & gt).sum());out['identity_links']={'TP':tp,'FP':fp,'FN':fn,'F1':2*tp/max(2*tp+fp+fn,1),'pairs':int(known.sum())}
 take=targets['option_split']==split;guess=result['option_logits'][take].argmax(1);out['junctions']={'correct':int((guess==targets['option_target'][take]).sum()),'total':int(take.sum()),'accuracy':float((guess==targets['option_target'][take]).float().mean())}
 state=pool(result['node_logits'][:,None],targets['axis_nodes'],targets['axis_ptr'])[:,0];take=targets['axis_split']==split;pred=state[take].sigmoid()>=.5;out['axis_states']={'groups':int(take.sum()),'accuracy':float((pred==targets['axis_class'][take]).float().mean())}
 return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--variant',choices=VARIANTS,required=True);ap.add_argument('--seed',type=int,required=True);ap.add_argument('--updates',type=int,default=100);ap.add_argument('--smoke',action='store_true');args=ap.parse_args()
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True);torch.manual_seed(args.seed);np.random.seed(args.seed);random.seed(args.seed)
 g,d,j,o,target,pixels,allp=load(W);model=initialize(args.seed,args.variant);folder=W/('smoke'if args.smoke else'experiments')/args.variant/str(args.seed);folder.mkdir(parents=True,exist_ok=True)
 ids=torch.nonzero(allp['split']==0).flatten();frequency=torch.bincount(allp['target'][ids],minlength=2).float();weights=(frequency.max()/frequency.clamp_min(1)).sqrt()
 optimizer=torch.optim.AdamW(model.parameters(),lr=3e-4,weight_decay=1e-4);scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,args.updates,eta_min=1e-6)
 config={'variant':args.variant,'seed':args.seed,'updates':args.updates,'samples_per_update':8192,'optimizer':'AdamW','lr':3e-4,'weight_decay':1e-4,'gradient_clip':5,'selection':'Maximum TWO-CLASS validation macro Dice only','fresh_initialization':True,'upstream_frozen':True,'actual_output_classes':['existing','new'],'learned_axis_decoder':model.axis_enabled,'learned_junction_decoder':model.junction_enabled,'fixed_legacy_axis_or_junction_rules':False,'loss_weights':{'pixel_CE':1,'pixel_Dice':.5,'node_state':.15,'identity':.1,'junction_pair':.1,'junction_option':.1,'axis':.2,'junction_state':.1},'code_SHA256':{name:hashlib.sha256((W/'code'/name).read_bytes()).hexdigest()for name in ['backbone.py','model.py','data.py','losses.py','train.py']},'scope':'B3 internal held-out typed-root pixels; frozen upstream features have historical B3 exposure'}
 js(folder/'config.json',config);first=1;best=-1.;history=[]
 if(folder/'resume.pt').exists():
  ck=torch.load(folder/'resume.pt',weights_only=False,map_location='cpu');assert ck['config']==config;model.load_state_dict(ck['model']);optimizer.load_state_dict(ck['optimizer']);scheduler.load_state_dict(ck['scheduler']);torch.set_rng_state(ck['rng']);first=ck['update']+1;history=ck['history'];best=ck['best']
 starttime=time.monotonic()
 for update in range(first,args.updates+1):
  start=time.monotonic();model.train();optimizer.zero_grad(set_to_none=True);result=model(d,j,o);rng=np.random.default_rng(args.seed+1009*update);sample=ids[torch.from_numpy(rng.choice(len(ids),min(8192,len(ids)),replace=False))];loss,components=compute(model,result,d,j,o,target,allp,sample,weights);assert torch.isfinite(loss);loss.backward();norm=torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);optimizer.step();scheduler.step();model.eval()
  with torch.inference_mode():validation_result=model(d,j,o);validation=evaluate(model,validation_result,pixels,1,target,d)
  row={'update':update,'loss':float(loss.detach()),**{k:float(v.detach())for k,v in components.items()},'validation_macro_Dice':validation['macro_Dice'],'validation_new_Dice':validation['classes'][1]['Dice'],'validation_identity_F1':validation['identity_links']['F1'],'validation_junction_accuracy':validation['junctions']['accuracy'],'gradient_norm':float(norm),'lr':optimizer.param_groups[0]['lr'],'seconds':time.monotonic()-start}
  if validation['macro_Dice']>best:
   best=validation['macro_Dice'];save(folder/'best.pt',{'model':model.state_dict(),'config':config,'update':update,'validation':validation})
  history.append(row);csvwrite(folder/'training_history.csv',history);save(folder/'resume.pt',{'model':model.state_dict(),'optimizer':optimizer.state_dict(),'scheduler':scheduler.state_dict(),'rng':torch.get_rng_state(),'config':config,'update':update,'best':best,'history':history});js(folder/'status.json',{'stage':'training','updates_completed':update,'updates_total':args.updates,'seconds_last_update':row['seconds']})
  if update==1 or update%10==0:print(args.variant,args.seed,'UPDATE',update,'VAL',round(best,6),'SEC',round(row['seconds'],2),flush=True)
 ck=torch.load(folder/'best.pt',weights_only=False,map_location='cpu');model.load_state_dict(ck['model']);model.eval()
 with torch.inference_mode():
  result=model(d,j,o);validation=evaluate(model,result,pixels,1,target,d);test=None if args.smoke else evaluate(model,result,pixels,2,target,d)
  # Node-level output caches contain no truth and work with variable graph sizes.
  np.savez_compressed(folder/'neural_output.npz',**{k:v.numpy()for k,v in result.items()if k in ['h','node_logits','link_logits','pair_logits','option_logits']})
  if not args.smoke:
   prediction=folder/'predictions';prediction.mkdir(exist_ok=True)
   for t,q in pixels.items():
    shape=(1108,2541);image=np.zeros(shape,np.uint8);confidence=np.zeros(shape,np.float32)
    for start in range(0,len(q['node']),32768):
     sl=slice(start,start+32768);prob=model.pixel_logits(result,torch.from_numpy(q['node'][sl]),torch.from_numpy(q['pf'][sl])).softmax(-1).numpy();image.ravel()[q['pixel'][sl]]=prob.argmax(1).astype(np.uint8)+1;confidence.ravel()[q['pixel'][sl]]=prob.max(1)
    from PIL import Image
    Image.fromarray(image).save(prediction/f'{t}_two_classes.png');np.savez_compressed(prediction/f'{t}_confidence.npz',confidence=confidence)
 report={'variant':args.variant,'seed':args.seed,'updates_completed':args.updates,'selected_update':ck['update'],'validation':validation,'test':test,'test_used_for_selection':False,'seconds':time.monotonic()-starttime,'two_class_training':True,'legacy_rule_decoding_used':False,'parameters':sum(p.numel()for p in model.parameters()),'prediction_scope':'Partition-isolated eligible pixels only; full-frame deployment is exported separately'}
 js(folder/'result.json',report);js(folder/'status.json',{'stage':'complete','updates_completed':args.updates,'test_evaluated_once':not args.smoke});print('RUN_COMPLETE',args.variant,args.seed,None if test is None else test['macro_Dice'],flush=True)
if __name__=='__main__':main()
