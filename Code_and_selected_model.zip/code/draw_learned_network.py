from pathlib import Path
import argparse
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
W=Path(__file__).resolve().parents[1]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--fonts',type=Path,default=Path('/workspace/work/root_workflow_real_assets_20261109/fonts'));a=ap.parse_args()
 if a.fonts.exists():
  for f in a.fonts.glob('*.ttf'):font_manager.fontManager.addfont(str(f))
 else:font_manager.findfont(font_manager.FontProperties(family='Times New Roman'),fallback_to_default=False)
 plt.rcParams.update({'font.family':'Times New Roman','font.size':8,'text.color':'black','pdf.fonttype':42,'svg.fonttype':'none'})
 out=W/'figures';out.mkdir(exist_ok=True);fig=plt.figure(figsize=(190/25.4,66/25.4));ax=fig.add_axes([0,0,1,1]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
 def box(x,y,w,h,color='#EEF4F7',edge='#3F7091',dashed=False):ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.003,rounding_size=0.012',fc=color,ec=edge,lw=.8,ls=(0,(3,2))if dashed else'-'))
 def arrow(a,b,dashed=False):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=8,lw=.8,color='#435B69',ls=(0,(3,2))if dashed else'-'))
 def text(x,y,s,bold=False,size=8):ax.text(x,y,s,ha='center',va='center',fontsize=size,fontweight='bold'if bold else'normal',linespacing=1.35)
 text(.5,.945,'Jointly learned temporal and structural root model',True,10)
 box(.020,.425,.158,.30,'#F3F4F5','#929CA4');text(.099,.64,'Frozen inputs',True);text(.099,.53,'Root masks\nTemporal priors\nRGB-derived graph',size=7.2)
 box(.215,.33,.765,.505,'white','#A7BDC9');text(.595,.791,'One differentiable network · jointly optimized',True,8.3)
 specs=[(.235,.190,'Temporal encoding','Frame CNN\nConvLSTM + GAT\nGate inside GAT'),(.470,.137,'Learned Axis','Identity-weighted\nnode propagation'),(.650,.137,'Learned Junction','Soft matching\nand feature feedback'),(.830,.130,'Two-class head','Existing roots\nNew roots')]
 for x,w,title,body in specs:
  box(x,.425,w,.29);text(x+w/2,.662,title,True,7.8);text(x+w/2,.54,body,size=7.3)
 arrow((.181,.575),(.230,.575))
 for a,b in [(.428,.466),(.610,.646),(.790,.826)]:arrow((a,.575),(b,.575))
 box(.235,.095,.725,.13,'white','#839BAA',True);text(.5975,.16,'Training losses: class + axis + junction + identity/state supervision',size=7.6)
 for x in [.33,.54,.718,.895]:arrow((x,.228),(x,.42),True)
 text(.5,.035,'Existing roots include persistent segments and elongation of existing root axes.',size=7)
 for ext in ['pdf','svg','jpg','png']:
  kw={'dpi':600,'facecolor':'white'}
  if ext=='jpg':kw['pil_kwargs']={'quality':98,'subsampling':0}
  fig.savefig(out/f'Learned_structure_network.{ext}',**kw)
 fig.savefig(out/'Network_preview.png',dpi=220,facecolor='white');plt.close(fig);print('LEARNED_NETWORK_DIAGRAM_COMPLETE',flush=True)
if __name__=='__main__':main()
