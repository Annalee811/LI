from pathlib import Path
import json,shutil,torch
W=Path(__file__).resolve().parents[1]
def main():
 protocol=json.loads((W/'Training_protocol.json').read_text());candidates=[]
 for seed in protocol['seeds']:
  p=W/'experiments/joint_full'/str(seed);assert json.loads((p/'status.json').read_text())['stage']=='complete';ck=torch.load(p/'best.pt',weights_only=False,map_location='cpu');candidates.append((ck['validation']['macro_Dice'],seed,p/'best.pt'))
 value,seed,source=max(candidates,key=lambda r:(r[0],-r[1]));dest=W/'selected_model';dest.mkdir(exist_ok=True);shutil.copy2(source,dest/'best.pt');(dest/'Selection.json').write_text(json.dumps({'seed':seed,'validation_macro_Dice':value,'selection':'Highest validation macro Dice among prespecified full-model seeds; no test scores used','source':str(source),'fixed_rule_decoding':False},indent=2));print('SELECTED_FULL_MODEL',seed,value,flush=True)
if __name__=='__main__':main()
