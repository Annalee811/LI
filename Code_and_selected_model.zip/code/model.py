"""Joint two-class temporal model with differentiable axis/junction decoding.

Targets and manual root IDs are never arguments to forward().
"""
import torch
from torch import nn
from torch.nn import functional as F
from backbone import Network,PairHead,pool

VARIANTS=['joint_full','neural_only','without_axis','without_junction']
class JointRootNet(nn.Module):
 def __init__(self,variant='joint_full'):
  super().__init__();assert variant in VARIANTS;self.variant=variant
  self.backbone=Network('full');self.pair=PairHead()
  self.axis_value=nn.Sequential(nn.Linear(64,64),nn.ELU(),nn.Linear(64,64));self.axis_norm=nn.LayerNorm(64);self.axis_strength=nn.Parameter(torch.tensor(-1.5))
  self.junction_value=nn.Sequential(nn.Linear(64,64),nn.ELU(),nn.Linear(64,64));self.junction_norm=nn.LayerNorm(64);self.junction_strength=nn.Parameter(torch.tensor(-1.5))
 @property
 def axis_enabled(self):return self.variant in ['joint_full','without_junction']
 @property
 def junction_enabled(self):return self.variant in ['joint_full','without_axis']
 def forward(self,d,j,options):
  h0,links,z=self.backbone(d);h=h0;a,b=d['pairs'].T
  if self.axis_enabled:
   same=d['phase'][a]==d['phase'][b];aa=a[same];bb=b[same];weights=links[same].sigmoid()
   # Within-date root continuity. Cross-date birth states are not smoothed together.
   index=torch.cat([aa,bb]);other=torch.cat([bb,aa]);weight=torch.cat([weights,weights]);degree=h.new_zeros(len(h)).index_add_(0,index,weight)
   for _ in range(2):
    msg=h.new_zeros(h.shape).index_add_(0,index,weight[:,None]*h[other]);mean=(msg+h)/(degree[:,None]+1)
    proposed=self.axis_norm(h+self.axis_strength.sigmoid()*self.axis_value(mean));h=torch.where((degree>0)[:,None],proposed,h)
  h_axis=h;arm=pool(h_axis,j['nodes'],j['ptr']);ident=F.normalize(self.backbone.identity(arm),dim=1)
  features=torch.cat([(ident[j['a']]-ident[j['b']]).abs(),ident[j['a']]*ident[j['b']],j['fixed']],1);pair_logits=self.pair(features)
  option_logits=(pair_logits[options['index']]*options['mask']).sum(-1);option_prob=option_logits.softmax(-1)
  marginal=pair_logits.new_zeros(len(pair_logits));marginal.index_add_(0,options['index'].flatten(),(option_prob[:,:,None]*options['mask']).flatten())
  if self.junction_enabled:
   a,b=j['a'],j['b'];index=torch.cat([a,b]);other=torch.cat([b,a]);weight=torch.cat([marginal,marginal]);degree=arm.new_zeros(len(arm)).index_add_(0,index,weight)
   message=arm.new_zeros(arm.shape).index_add_(0,index,weight[:,None]*arm[other]);message=message/degree.clamp_min(1)[:,None]
   arm_for_node=torch.repeat_interleave(torch.arange(len(arm),device=h.device),j['ptr'][1:]-j['ptr'][:-1]);counts=h.new_zeros(len(h)).index_add_(0,j['nodes'],h.new_ones(len(j['nodes'])))
   node_msg=h.new_zeros(h.shape).index_add_(0,j['nodes'],message[arm_for_node]);node_msg=node_msg/counts.clamp_min(1)[:,None]
   proposed=self.junction_norm(h_axis+self.junction_strength.sigmoid()*self.junction_value(node_msg));h=torch.where((counts>0)[:,None],proposed,h_axis)
  return {'h':h,'h_raw':h0,'h_axis':h_axis,'identity':z,'link_logits':links,'pair_logits':pair_logits,'option_logits':option_logits,'pair_marginal':marginal,'node_logits':self.backbone.root_state(h)[:,0]}
 def pixel_logits(self,result,node,pf):return self.backbone.pixel_logits(result['h'],node,pf)

def initialize(seed,variant):
 torch.manual_seed(seed);return JointRootNet(variant)
