from pathlib import Path
import torch,numpy as np,json,inspect
from model import initialize
from data import load
from torch.nn import functional as F
W=Path(__file__).resolve().parents[1]
def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);g,d,j,o,target,pixels,allp=load(W);net=initialize(20261124,'joint_full');net.eval()
 r=net(d,j,o);ix=torch.nonzero(allp['split']==0).flatten()[::17][:8192];ce=F.cross_entropy(net.pixel_logits(r,allp['node'][ix],allp['pf'][ix]),allp['target'][ix]);parameters=[net.axis_value[0].weight,net.junction_value[0].weight,net.pair.net[-1].weight,net.backbone.memory.gates.weight,net.backbone.layers[0].project.weight]
 grads=torch.autograd.grad(ce,parameters);names=['axis_decoder','junction_decoder','junction_pair_scores','ConvLSTM','GAT'];gradient={name:float(v.abs().sum())for name,v in zip(names,grads)};assert all(v>1e-10 for v in gradient.values()),gradient
 # The model sees no class labels, root IDs, or target options.
 assert list(inspect.signature(net.forward).parameters)==['d','j','options'];assert set(o)=={'index','mask'};assert set(j)=={'nodes','ptr','a','b','fixed'}
 with torch.inference_mode():
  r0=net(d,j,o);changed={k:(v.clone()if torch.is_tensor(v)else v)for k,v in d.items()};changed['x'][d['part']!=0]+=8;changed['extra'][d['part']!=0]-=8;outside=~d['partition_frame_masks'][0].bool();changed['frames'][:,:,outside]+=3;r1=net(changed,j,o)
 assert torch.equal(r0['h'][d['part']==0],r1['h'][d['part']==0]),'Partition leakage'
 # A genuinely different graph size confirms no learned B3-only node lookup.
 n=12;phase=torch.repeat_interleave(torch.arange(4),3);pairs=torch.stack([torch.arange(n-1),torch.arange(1,n)],1);small={'x':torch.randn(n,28),'extra':torch.randn(n,4),'pairs':pairs,'attrs':torch.randn(n-1,8),'phase':phase,'centers':torch.rand(n,2)*63,'part':torch.zeros(n,dtype=torch.long),'frames':torch.randn(4,8,8,8),'partition_frame_masks':torch.ones(1,8,8),'native_width':64,'native_height':64}
 sj={'nodes':torch.tensor([3,4,5]),'ptr':torch.tensor([0,1,2,3]),'a':torch.tensor([0,0,1]),'b':torch.tensor([1,2,2]),'fixed':torch.randn(3,18)};so={'index':torch.tensor([[[0],[1],[2]]]),'mask':torch.ones(1,3,1)}
 with torch.inference_mode():sr=net(small,sj,so)
 assert sr['h'].shape==(12,64)and torch.isfinite(sr['h']).all()
 # All configurations begin with exactly matching weights.
 baseline=initialize(20261124,'neural_only');assert all(torch.equal(v,baseline.state_dict()[k])for k,v in net.state_dict().items())
 report={'passed':True,'classification_loss_gradient_L1':gradient,'structural_decoders_receive_classification_gradients':True,'manual_targets_absent_from_forward':True,'train_partition_invariant_to_other_partition_features':True,'variable_node_count_forward_passed':True,'identical_matched_initialization':True,'binary_logits_shape':[len(ix),2],'legacy_rule_decoders_used':False}
 (W/'reports/Implementation_checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
