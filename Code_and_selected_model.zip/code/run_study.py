from pathlib import Path
import concurrent.futures,subprocess,sys,json,time
W=Path(__file__).resolve().parents[1]
def main():
 variants=['joint_full','neural_only','without_axis','without_junction'];seeds=[20261124,20261125,20261126]
 protocol={'version':'joint-learned-structure-v1','variants':variants,'seeds':seeds,'updates_per_run':100,'pixels_sampled_per_update':8192,'selection':'Two-class validation macro Dice only; no test-based model or seed selection','initialization':'Fresh matched parameters in all four variants','baseline':'Same two-class backbone and auxiliary heads, with differentiable structure refinement and explicit axis/junction consistency terms disabled','ablations':'without_axis or without_junction disables the corresponding learned refinement and corresponding consistency term; shared identity/pair auxiliary supervision is retained','network_output':['existing','new'],'upstream_root_segmentation_and_temporal_prior':'Frozen and reused; not retrained','legacy_axis_junction_postprocessing':False,'independent_GT':False,'parallel_runs':2,'threads_per_run':1,'compute_device':'CPU','planned_runs':12}
 (W/'Training_protocol.json').write_text(json.dumps(protocol,indent=2));jobs=[(v,s)for v in variants for s in seeds]
 def one(v,s):
  dest=W/'experiments'/v/str(s)
  if(dest/'status.json').exists()and json.loads((dest/'status.json').read_text())['stage']=='complete':return {'variant':v,'seed':s,'status':'existing_complete'}
  with(W/'logs'/f'{v}_{s}.log').open('a')as log:subprocess.run([sys.executable,str(W/'code/train.py'),'--variant',v,'--seed',str(s),'--updates','100'],stdout=log,stderr=subprocess.STDOUT,check=True)
  r=json.loads((dest/'result.json').read_text());return {'variant':v,'seed':s,'status':'complete','selected_update':r['selected_update'],'validation_macro_Dice':r['validation']['macro_Dice'],'test_macro_Dice':r['test']['macro_Dice'],'seconds':r['seconds']}
 done=[];start=time.monotonic()
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
  for future in concurrent.futures.as_completed([pool.submit(one,v,s)for v,s in jobs]):
   done.append(future.result());(W/'Training_progress.json').write_text(json.dumps({'completed':len(done),'planned':len(jobs),'runs':done},indent=2));print(done[-1],flush=True)
 (W/'TRAINING_COMPLETE.json').write_text(json.dumps({'completed':len(done),'runs':done,'seconds':time.monotonic()-start},indent=2))
 subprocess.run([sys.executable,str(W/'code/select_model.py')],check=True)
 print('ALL_JOINT_TRAINING_COMPLETE',flush=True)
if __name__=='__main__':main()
