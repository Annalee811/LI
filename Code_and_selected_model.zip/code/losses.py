import torch
from torch.nn import functional as F
from backbone import pool
def balanced_bce(logit,y):
 positive=(y>.5);negative=~positive;parts=[]
 if positive.any():parts.append(F.softplus(-logit[positive]).mean())
 if negative.any():parts.append(F.softplus(logit[negative]).mean())
 return torch.stack(parts).mean()if parts else logit.sum()*0
def compute(model,result,d,j,options,targets,pix,ii,weights):
 logits=model.pixel_logits(result,pix['node'][ii],pix['pf'][ii]);y=pix['target'][ii];p=logits.softmax(-1);truth=F.one_hot(y,2).float()
 ce=F.cross_entropy(logits,y,weight=weights);dice=1-((2*(p*truth).sum(0)+1)/(p.sum(0)+truth.sum(0)+1)).mean();cls=ce+.5*dice
 known=targets['edge_split']==0;identity=balanced_bce(result['link_logits'][known],targets['edge_target'][known].float())
 jm=targets['junction_split']==0;junction_pair=balanced_bce(result['pair_logits'][jm],targets['junction_target'][jm]);om=targets['option_split']==0;junction_option=F.cross_entropy(result['option_logits'][om],targets['option_target'][om])
 nm=(d['part']==0)&targets['node_class_valid'];node=balanced_bce(result['node_logits'][nm],targets['node_class'][nm].float())
 zero=cls*0;axis=zero;cross_state=zero
 if model.axis_enabled:
  # Ground-truth root groups appear in training losses only, never in forward.
  group=targets['axis_split']==0;state=pool(result['node_logits'][:,None],targets['axis_nodes'],targets['axis_ptr'])[:,0]
  axis=balanced_bce(state[group],targets['axis_class'][group].float())
  group_index=torch.repeat_interleave(torch.arange(len(state)),targets['axis_ptr'][1:]-targets['axis_ptr'][:-1]);valid_nodes=group[group_index];values=result['node_logits'][targets['axis_nodes']].sigmoid();variance=(values-state.sigmoid()[group_index]).square();axis=axis+.2*variance[valid_nodes].mean()
  pairs=targets['temporal_pairs'];take=(targets['axis_split'][pairs[:,0]]==0)&(targets['axis_split'][pairs[:,1]]==0)
  if take.any():
   q=pairs[take];axis=axis+.2*F.relu(state[q[:,1]].sigmoid()-state[q[:,0]].sigmoid()).square().mean()
  a,b=d['pairs'].T;known=(targets['edge_split']==0)&targets['same_phase'];sim=(result['identity'][a[known]]*result['identity'][b[known]]).sum(-1);positive=targets['edge_target'][known]>0
  axis=axis+.1*torch.where(positive,(1-sim).square(),F.relu(sim-.2).square()).mean()
 if model.junction_enabled:
  node_probability=result['node_logits'].sigmoid()[:,None];arm_probability=pool(node_probability,j['nodes'],j['ptr'])[:,0]
  paired=(targets['junction_split']==0)&(targets['junction_target']>.5)
  cross_state=(arm_probability[j['a'][paired]]-arm_probability[j['b'][paired]]).square().mean()
 total=cls+.15*node+.1*identity+.1*junction_pair+.1*junction_option+.2*axis+.1*cross_state
 return total,{'class':cls,'class_CE':ce,'class_Dice_loss':dice,'node':node,'identity':identity,'junction_pair':junction_pair,'junction_option':junction_option,'axis':axis,'junction_state':cross_state}
