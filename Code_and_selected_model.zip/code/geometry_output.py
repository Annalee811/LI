"""Discrete rendering of learned matching scores; never repaints temporal classes.

Uncertain contacts retain an uncertainty flag. No legacy Axis/Junction rules.
"""
import numpy as np
from scipy import ndimage as ndi
from scipy.optimize import linear_sum_assignment
def routes(topology,decisions):
 segments=topology['segments'];parent=np.arange(len(segments));links={}
 def find(k):
  while parent[k]!=k:parent[k]=parent[parent[k]];k=parent[k]
  return k
 for hub,pairs,confidence in sorted(decisions,key=lambda r:-r[2]):
  arms=topology['hubs'][hub]['arms']
  for a,b in pairs:
   u=(arms[a]['segment'],arms[a]['end']);v=(arms[b]['segment'],arms[b]['end']);ru,rv=find(u[0]),find(v[0])
   if u in links or v in links or ru==rv:continue
   links[u]=v;links[v]=u;parent[rv]=ru
 paths=[];used={i for i,s in enumerate(segments)if s.get('absorbed')}
 for start in range(len(segments)):
  if start in used:continue
  current=start;entry=0;walked=set()
  while(current,entry)in links and(current,entry)not in walked:
   walked.add((current,entry));current,other=links[(current,entry)];entry=1-other
  points=[]
  while current not in used:
   used.add(current);p=segments[current]['points'];points.extend(p if entry==0 else p[::-1]);exit=1-entry
   if(current,exit)not in links:break
   current,entry=links[(current,exit)]
  if points:paths.append(np.asarray(points,np.int32))
 return paths

class TrackRenderer:
 def __init__(self,graph,geometry,owners,result):
  self.graph=graph;self.geometry=geometry;self.owners=owners;self.result=result;self.node_track=np.zeros(len(graph['x']),np.int32);self.next_track=1;self.rows=[]
 def render(self,period,ti,foreground):
  option=self.result['option_logits'];groups=self.geometry['groups'];decisions=[];accepted=set()
  for k,g in enumerate(groups):
   if g['period']!=period:continue
   scores=option[k];p=np.exp(scores-scores.max());p/=p.sum();best=int(p.argmax())
   if p[best]>=.7:decisions.append((g['hub'],g['options'][best],float(p[best])));accepted.add(g['hub'])
  top=self.geometry['topos'][period];paths=routes(top,decisions);seed=np.zeros(foreground.shape,np.int32)
  for ai,p in enumerate(paths,1):seed[p[:,1],p[:,0]]=ai
  if not paths:return np.zeros_like(seed),np.zeros_like(seed),foreground.copy(),[]
  _,near=ndi.distance_transform_edt(seed==0,return_indices=True);axis=seed[tuple(near)];axis[~foreground]=0;uncertain=np.zeros(foreground.shape,bool)
  # Shared physical crossing pixels do not receive two simultaneous identities.
  for hubid,hub in enumerate(top['hubs']):
   if hub.get('disabled'):continue
   p=hub['points'];uncertain[p[:,1],p[:,0]]=True
  node_axis=np.zeros(len(self.graph['x']),np.int32);members=[]
  for ai,p in enumerate(paths,1):
   nodes=np.unique(self.owners[period][p[:,1],p[:,0]]);nodes=nodes[nodes>=0];members.append(nodes);unassigned=node_axis[nodes]==0;node_axis[nodes[unassigned]]=ai;node_axis[nodes[~unassigned]]=-1
  probabilities=1/(1+np.exp(-np.clip(self.result['node_logits'],-30,30)));a,b=self.graph['pairs'].T;phase=self.graph['phase'];swap=phase[a]>phase[b];a,b=np.where(swap,b,a),np.where(swap,a,b);relevant=(phase[b]==ti)&(phase[a]<ti)&(self.node_track[a]>0)&(node_axis[b]>0);ea=a[relevant];eb=b[relevant];scores=1/(1+np.exp(-np.clip(self.result['link_logits'][relevant],-30,30)))
  tracks=np.unique(self.node_track[ea]);matrix=np.zeros((len(paths),len(tracks)),np.float32)
  if len(tracks):
   for ai in range(1,len(paths)+1):
    take=node_axis[eb]==ai
    for track in np.unique(self.node_track[ea[take]]):
     v=scores[take&(self.node_track[ea]==track)]
     if len(v)>=2:matrix[ai-1,np.searchsorted(tracks,track)]=float(np.sort(v)[-min(5,len(v)):].mean())
  assignment={}
  if len(tracks):
   row,col=linear_sum_assignment(-matrix)
   for i,k in zip(row,col):
    runner=np.max(np.delete(matrix[i],k))if matrix.shape[1]>1 else 0.
    if matrix[i,k]>=.75 and matrix[i,k]-runner>=.1:assignment[int(i)]=int(tracks[k])
  trackmap=np.zeros(foreground.shape,np.int32);records=[]
  for i,(p,nodes)in enumerate(zip(paths,members)):
   birth=float(probabilities[nodes].mean())if len(nodes)else.5;track=assignment.get(i,0);reason='learned temporal identity association'
   if ti==0 or(track==0 and birth>=.75):track=self.next_track;self.next_track+=1;reason='baseline axis'if ti==0 else'predicted new-axis birth'
   if track==0:uncertain[axis==i+1]=True;reason='insufficient or ambiguous learned identity evidence'
   else:trackmap[axis==i+1]=track;valid=nodes[node_axis[nodes]==i+1];self.node_track[valid]=track
   records.append({'period':period,'axis_id':i+1,'root_track_id':track,'node_new_probability':birth,'skeleton_pixels':len(p),'reason':reason})
  trackmap[uncertain]=0;self.rows.extend(records)
  return axis,trackmap,uncertain,records
