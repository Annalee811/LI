from pathlib import Path
import json,csv,hashlib
import numpy as np
W=Path(__file__).resolve().parents[1]
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='')as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def main():
 protocol=json.loads((W/'Training_protocol.json').read_text());runs=[];classes=[];checks=[]
 for variant in protocol['variants']:
  for seed in protocol['seeds']:
   folder=W/'experiments'/variant/str(seed);r=json.loads((folder/'result.json').read_text());config=json.loads((folder/'config.json').read_text());history=list(csv.DictReader((folder/'training_history.csv').open(encoding='utf-8-sig')))
   assert len(history)==100 and r['updates_completed']==100 and not r['test_used_for_selection'];best=max(history,key=lambda x:float(x['validation_macro_Dice']));assert int(best['update'])==r['selected_update']
   for name,sha in config['code_SHA256'].items():assert hashlib.sha256((W/'code'/name).read_bytes()).hexdigest()==sha
   t=r['test'];existing,new=t['classes'];assert t['pixels']==83478 and existing['support']==70907 and new['support']==12571
   row={'variant':variant,'seed':seed,'selected_update':r['selected_update'],'validation_macro_Dice':r['validation']['macro_Dice'],'macro_Dice':t['macro_Dice'],'macro_IoU':t['macro_IoU'],'new_Precision':new['Precision'],'new_Recall':new['Recall'],'new_Dice':new['Dice'],'new_IoU':new['IoU'],'existing_Dice':existing['Dice'],'existing_IoU':existing['IoU'],'identity_link_F1':t['identity_links']['F1'],'identity_link_pairs':t['identity_links']['pairs'],'junction_accuracy':t['junctions']['accuracy'],'junction_groups':t['junctions']['total'],'axis_state_accuracy':t['axis_states']['accuracy'],'axis_groups':t['axis_states']['groups'],'parameters_allocated':r['parameters'],'seconds':r['seconds']};runs.append(row)
   for c in t['classes']:classes.append(dict(variant=variant,seed=seed,**c))
   cm=np.array(t['confusion']);assert cm.sum()==83478
   for k,c in enumerate(t['classes']):
    tp=int(cm[k,k]);fp=int(cm[:,k].sum()-tp);fn=int(cm[k].sum()-tp);assert abs(c['Dice']-2*tp/(2*tp+fp+fn))<1e-12
   checks.append({'variant':variant,'seed':seed,'validation_only_checkpoint_selection_verified':True,'100_updates_verified':True,'two_class_confusion_verified':True,'code_matches_trained_checkpoint':True,'checkpoint_SHA256':hashlib.sha256((folder/'best.pt').read_bytes()).hexdigest()})
 metrics=['macro_Dice','macro_IoU','new_Precision','new_Recall','new_Dice','new_IoU','existing_Dice','existing_IoU','identity_link_F1','junction_accuracy','axis_state_accuracy'];summary=[]
 for variant in protocol['variants']:
  rr=[r for r in runs if r['variant']==variant];row={'variant':variant,'seeds':len(rr)}
  for key in metrics:
   x=np.array([r[key]for r in rr]);row[key+'_mean']=float(x.mean());row[key+'_SD']=float(x.std(ddof=1))
  summary.append(row)
 paired=[]
 for ablated in ['neural_only','without_axis','without_junction']:
  for seed in protocol['seeds']:
   f=next(r for r in runs if r['variant']=='joint_full'and r['seed']==seed);a=next(r for r in runs if r['variant']==ablated and r['seed']==seed);paired.append({'reference':ablated,'seed':seed,**{k+'_delta_pp':100*(f[k]-a[k])for k in metrics}})
 write(W/'reports/Per_run_metrics.csv',runs);write(W/'reports/Per_class_metrics.csv',classes);write(W/'reports/Mean_SD_metrics.csv',summary);write(W/'reports/Paired_effects.csv',paired)
 audit=json.loads((W/'reports/data_audit.json').read_text())
 source_root=Path('/workspace/work/V90_validation_20261123/data')
 for name,sha in audit['source_hashes'].items():
  path=Path(name);path=path if path.exists()else W/'data'/path.relative_to(source_root)
  assert hashlib.sha256(path.read_bytes()).hexdigest()==sha
 verification={'all_12_runs_verified':True,'two_class_training_and_validation_selection':True,'source_files_unchanged':True,'legacy_fixed_class_rewrite_used':False,'implementation_gradient_checks':json.loads((W/'reports/Implementation_checks.json').read_text()),'run_checks':checks,'batch_prediction_paused_by_user':(W/'BATCH_PREDICTION_PAUSED.json').exists(),'internal_scope':'B3 fixed foreground, 83,478 common held-out typed-root pixels; frozen upstream prior has historical B3 exposure','independent_accuracy':None}
 (W/'reports/Training_verification.json').write_text(json.dumps(verification,indent=2));print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':main()
