from pathlib import Path
import csv,json,argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.backends.backend_pdf import PdfPages
W=Path(__file__).resolve().parents[1]
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--fonts',type=Path,default=Path('/workspace/work/root_workflow_real_assets_20261109/fonts'));args=ap.parse_args();fonts=args.fonts
 if fonts.exists():
  for path in fonts.glob('*.ttf'):font_manager.fontManager.addfont(str(path))
 else:font_manager.findfont(font_manager.FontProperties(family='Times New Roman'),fallback_to_default=False)
 plt.rcParams.update({'font.family':'Times New Roman','font.size':8,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','axes.labelweight':'bold','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6,'pdf.fonttype':42,'svg.fonttype':'none'})
 out=W/'figures';out.mkdir(exist_ok=True);protocol=json.loads((W/'Training_protocol.json').read_text());variants=protocol['variants'];colors=['#266574','#687680','#AC7742','#845D79'];names=['Joint learned','Neural baseline','w/o Axis','w/o Junction'];rows=read(W/'reports/Per_run_metrics.csv')
 fig=plt.figure(figsize=(190/25.4,88/25.4),facecolor='white');axes=[fig.add_axes([.067,.32,.245,.51]),fig.add_axes([.398,.32,.245,.51]),fig.add_axes([.735,.32,.25,.51])]
 for i,(ax,keys,labels)in enumerate([(axes[0],['new_Dice','existing_Dice','macro_Dice'],['New','Existing','Macro']),(axes[1],['identity_link_F1','junction_accuracy','axis_state_accuracy'],['Identity\nlinks','Junction\npairing','Axis\nstate'])]):
  for vi,variant in enumerate(variants):
   rr=[r for r in rows if r['variant']==variant];x=np.arange(3)+(vi-1.5)*.115;means=[100*np.mean([float(r[k])for r in rr])for k in keys];sd=[100*np.std([float(r[k])for r in rr],ddof=1)for k in keys]
   ax.errorbar(x,means,yerr=sd,fmt='o',ms=3.6,color=colors[vi],capsize=2,lw=.9,label=names[vi])
   if vi==0:
    for xx,yy in zip(x,means):ax.text(xx-.04,yy+1.3,f'{yy:.1f}',fontsize=6.7,ha='center')
  ax.set_xticks(range(3),labels);ax.set_xlim(-.5,2.45);ax.grid(axis='y',color='#E8ECEF',lw=.4);ax.set_axisbelow(True);ax.tick_params(labelsize=7)
 axes[0].set_ylim(78,101);axes[0].set_yticks([80,85,90,95,100]);axes[0].set_ylabel('Dice (%)',fontsize=8)
 axes[1].set_ylim(60,102);axes[1].set_yticks([60,70,80,90,100]);axes[1].set_ylabel('Score (%)',fontsize=8)
 histories={}
 for vi,variant in enumerate(variants):
  hh=[read(W/'experiments'/variant/str(s)/'training_history.csv')for s in protocol['seeds']];histories[variant]=hh;y=np.array([[100*float(r['validation_macro_Dice'])for r in h]for h in hh]);x=np.arange(1,101);axes[2].plot(x,y.mean(0),color=colors[vi],lw=1,label=names[vi]);axes[2].fill_between(x,y.mean(0)-y.std(0,ddof=1),y.mean(0)+y.std(0,ddof=1),color=colors[vi],alpha=.10,lw=0)
 axes[2].set_xlim(1,100);axes[2].set_xticks([1,25,50,75,100]);axes[2].set_ylim(87,97);axes[2].set_yticks([88,90,92,94,96]);axes[2].set_xlabel('Optimization update',fontsize=8);axes[2].set_ylabel('Validation macro Dice (%)',fontsize=8);axes[2].tick_params(labelsize=7);axes[2].grid(color='#E8ECEF',lw=.4)
 for x,center,title,letter in [(.012,.19,'Two-class performance','A'),(.343,.52,'Structural performance','B'),(.675,.86,'Learning curves','C')]:
  fig.text(x,.925,letter,fontsize=11.5,fontweight='bold');fig.text(center,.925,title,ha='center',fontsize=8.4,fontweight='bold')
 handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='center',bbox_to_anchor=(.5,.17),ncol=4,frameon=False,prop={'size':7.5,'weight':'bold'},columnspacing=1.4,handletextpad=.4)
 fig.text(.5,.076,'Three matched optimization seeds; mean ± SD. B3 internal evaluation on fixed root foreground.',ha='center',fontsize=7)
 fig.text(.5,.035,'Classification is conditional on root foreground; independent cross-tube accuracy is not estimated.',ha='center',fontsize=7)
 for ext in ['jpg','png','tif','pdf','svg']:
  kw={'dpi':600,'facecolor':'white'}
  if ext=='jpg':kw['pil_kwargs']={'quality':98,'subsampling':0}
  if ext=='tif':kw['pil_kwargs']={'compression':'tiff_lzw'}
  fig.savefig(out/f'Joint_learned_structure_ABC.{ext}',**kw)
 fig.savefig(out/'Summary_preview.png',dpi=220,facecolor='white');plt.close(fig)
 with PdfPages(out/'Training_loss_and_validation.pdf')as pdf:
  for vi,variant in enumerate(variants):
   fig,axs=plt.subplots(1,2,figsize=(7.48,3.4))
   for si,h in enumerate(histories[variant]):
    x=np.array([int(r['update'])for r in h]);axs[0].plot(x,[float(r['loss'])for r in h],lw=.85,label=str(protocol['seeds'][si]));axs[1].plot(x,[100*float(r['validation_macro_Dice'])for r in h],lw=.85)
   axs[0].set_ylabel('Training total loss');axs[1].set_ylabel('Validation macro Dice (%)')
   for ax in axs:ax.set_xlabel('Optimization update');ax.grid(color='#E8ECEF',lw=.4)
   axs[0].legend(frameon=False,fontsize=7);fig.suptitle(names[vi],fontweight='bold');fig.tight_layout();pdf.savefig(fig);plt.close(fig)
 print('TRAINING_FIGURES_COMPLETE',flush=True)
if __name__=='__main__':main()
