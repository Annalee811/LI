"""Derive balanced identity-edge diagnostics from the already recorded counts."""
from pathlib import Path
import json,csv
W=Path(__file__).resolve().parents[1]
def main():
 rows=[]
 for p in sorted((W/'experiments').glob('*/*/result.json')):
  r=json.loads(p.read_text());m=r['test']['identity_links'];tp,fp,fn,n=[m[k]for k in ['TP','FP','FN','pairs']];tn=n-tp-fp-fn
  rows.append({'variant':r['variant'],'seed':r['seed'],'TP':tp,'FP':fp,'FN':fn,'TN':tn,'Precision':tp/(tp+fp),'Recall':tp/(tp+fn),'Specificity':tn/(tn+fp),'balanced_accuracy':.5*(tp/(tp+fn)+tn/(tn+fp)),'F1':m['F1'],'positive_fraction':(tp+fn)/n,'all_linked_F1':2*(tp+fn)/(n+tp+fn)})
 with(W/'reports/Identity_edge_diagnostics.csv').open('w',encoding='utf-8-sig',newline='')as f:writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 print('IDENTITY_COUNT_DIAGNOSTICS_COMPLETE',flush=True)
if __name__=='__main__':main()
