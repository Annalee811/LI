V90 automatic output on 0353-2-B3. Original model weights and original frozen B3 inputs.
Manual annotation is used only to evaluate these files.
Full original-RGB grid;0 background,1 persistent,2 newly observed,3 extending,4 T1 baseline.
B3 developmental reference agreement only; not independent cross-tube validation.
